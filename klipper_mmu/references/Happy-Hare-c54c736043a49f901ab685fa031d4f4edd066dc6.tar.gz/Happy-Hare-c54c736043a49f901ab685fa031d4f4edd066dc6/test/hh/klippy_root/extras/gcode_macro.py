# Fake Klipper `klippy/extras/gcode_macro.py` for the Happy Hare test harness.
#
# Two distinct jobs:
#
# 1. load_template() must return a REAL jinja2-backed template. _ledEffect
#    requires it for its `layers` option (extras/mmu_led_effect.py:527), and the
#    rendered mmu.cfg ships 25 [mmu_led_effect] sections, so this is on the bootup
#    path for any profile with LEDs.
#
# 2. load_config_prefix() must give macros a real mutable `.variables` dict. HH reads
#    variables straight off them: _MMU_SEQUENCE_VARS['park_toolchange'] and
#    user_post_load_extension (extras/mmu/mmu_controller.py:205-207, 219-221) and
#    _BLOBIFIER_VARS (:461).
#
# Macro bodies are registered as recorded no-ops at this tier - running ~2000 lines
# of shipped Jinja macro is a later milestone, and HH reaches bootup without it. Callers may
# explicitly opt one macro into run_body(); make console does that for MMU_COLD_PULL only.
#
# A macro whose MOTION Happy Hare measures may instead receive a smaller modeled effect: see
# cmd() and printer.harness_macro_effects.
#
# This file may be distributed under the terms of the GNU GPLv3 license.

import json
import jinja2

# One Environment and one compiled-template cache for the whole PROCESS, not per boot.
# env.from_string(script) is a pure function of the literal script text: this Environment's
# config ('{%','%}','{','}', extensions=['jinja2.ext.do']) never varies, and everything that
# differs per render - printer state, gate, eventtime - is injected later via
# TemplateWrapper.render(context), never baked into the compiled template at from_string()
# time. That is what makes this safe to cache for the process's entire lifetime.
#
# Without this, every boot rebuilt a fresh Environment and recompiled every one of the ~360
# gcode_macro sections a rendered profile ships from scratch: measured at 23,603
# jinja2.environment.compile calls / 39.7s across 65-66 boots in test_mmu_console.py alone.
# Sharing the Environment and caching by script text cut one profile's boot() cost 5.9x
# (1.47s -> 0.25s). Only the compiled TEMPLATE is cached - printer/name/script stay
# per-instance below so error messages still reference the right session.
_ENV = jinja2.Environment('{%', '%}', '{', '}', extensions=['jinja2.ext.do'])
_TEMPLATE_CACHE = {}


class TemplateWrapper:
    def __init__(self, printer, env, name, script):
        self.printer = printer
        self.name = name
        self.script = script
        try:
            template = _TEMPLATE_CACHE.get(script)
            if template is None:
                # Only cache on SUCCESS: a compile failure must raise with THIS call's
                # printer/name below, not poison the cache with a partial/failed entry.
                template = env.from_string(script)
                _TEMPLATE_CACHE[script] = template
            self.template = template
        except Exception as e:
            raise printer.config_error("Error building template '%s': %s" % (name, e))

    def render(self, context=None):
        try:
            return str(self.template.render(context or {}))
        except Exception as e:
            raise self.printer.command_error(
                "Error evaluating template '%s': %s" % (self.name, e))

    def run_gcode_from_command(self, context=None):
        gcode = self.printer.lookup_object('gcode')
        gcode.run_script_from_command(self.render(context))


class PrinterGCodeMacro:
    def __init__(self, config):
        self.printer = config.get_printer()
        self.env = _ENV

    def load_template(self, config, option, default=None):
        name = "%s:%s" % (config.get_name(), option)
        if default is None:
            script = config.get(option)
        else:
            script = config.get(option, default)
        return TemplateWrapper(self.printer, self.env, name, script)

    def create_template_context(self, eventtime=None):
        return {
            'printer': _StatusWrapper(self.printer, eventtime),
            'action_emergency_stop': lambda msg='': None,
            'action_respond_info': lambda msg: None,
            'action_raise_error': self._action_raise_error,
            'action_call_remote_method': lambda method, **kw: None,
        }

    def _action_raise_error(self, msg):
        """Match Klipper's template helper when an opted-in macro rejects input."""
        raise self.printer.command_error(msg)


class _StatusWrapper:
    """Minimal printer.<obj>.<field> access for template rendering."""

    def __init__(self, printer, eventtime=None):
        self.printer = printer
        self.eventtime = eventtime

    def __getitem__(self, key):
        obj = self.printer.lookup_object(key, None)
        if obj is None or not hasattr(obj, 'get_status'):
            return {}
        et = self.eventtime
        if et is None:
            et = self.printer.get_reactor().monotonic()
        return obj.get_status(et)

    def __getattr__(self, key):
        return self[key]

    def __contains__(self, key):
        return self.printer.lookup_object(key, None) is not None

    def __iter__(self):
        # Klipper's status wrapper is iterable, which reporting macros such as
        # MMU_DUMP_VARS rely on to discover matching printer objects.
        return iter(name for name, _obj in self.printer.lookup_objects())


class GCodeMacro:
    def __init__(self, config):
        name = config.get_name().split()[-1]
        self.alias = name.upper()
        self.printer = printer = config.get_printer()
        gcode_macro = printer.load_object(config, 'gcode_macro')
        self.template = gcode_macro.load_template(config, 'gcode', '')
        self.gcode = printer.lookup_object('gcode')
        self.rename_existing = config.get('rename_existing', None)
        self.description = config.get('description', 'G-Code macro')
        self.variables = {}
        # Klipper parses `variable_<name>: <literal>` into .variables
        import ast
        for option in config.get_prefix_options('variable_'):
            try:
                literal = ast.literal_eval(config.get(option))
                json.dumps(literal, separators=(',', ':'))
                self.variables[option[len('variable_'):]] = literal
            except (SyntaxError, TypeError, ValueError) as e:
                raise config.error(
                    "Option '%s' in section '%s' is not a valid literal: %s" % (
                        option, config.get_name(), e))
        self.calls = []         # test assertion surface
        self.gcode.register_command(self.alias, self.cmd, desc=self.description)

    def cmd(self, gcmd):
        # Recorded, then OPTIONALLY given an effect. Bodies still do not run (see the module
        # docstring), but a handful of shipped macros are load-bearing for the physics rather
        # than merely for choreography: HH measures how far the extruder moved during
        # _MMU_FORM_TIP and refuses the unload if the answer is zero
        # (mmu_filament_movement.py:2477-2497, :2559-2568). A recorded no-op therefore reads to
        # HH as "the filament is stuck".
        #
        # Effects are supplied by the harness through printer.harness_macro_effects, keyed by
        # alias - the same printer.harness_* convention as harness_filament, so this tree still
        # imports nothing from test.hh.
        self.calls.append(gcmd.get_commandline())
        effect = (getattr(self.printer, 'harness_macro_effects', None) or {}).get(self.alias)
        if effect is not None:
            effect(self, gcmd)

    def run_body(self, gcmd):
        """Render and dispatch this macro body when the harness explicitly opts it in."""
        gcode_macro = self.printer.lookup_object('gcode_macro')
        context = gcode_macro.create_template_context()
        context['params'] = gcmd.get_command_parameters()
        context['rawparams'] = gcmd.get_raw_command_parameters()
        self.template.run_gcode_from_command(context)

    def get_status(self, eventtime=None):
        return dict(self.variables)


def load_config(config):
    return PrinterGCodeMacro(config)


def load_config_prefix(config):
    return GCodeMacro(config)
