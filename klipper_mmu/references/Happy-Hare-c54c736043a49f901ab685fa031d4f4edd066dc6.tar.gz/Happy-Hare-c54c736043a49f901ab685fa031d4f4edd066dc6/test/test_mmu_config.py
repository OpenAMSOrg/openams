# Happy Hare test harness - milestone A1.
#
# Pure strings: render the real shipped templates and assert the output is what the
# rest of the harness (and a real user) depends on. No fakes, no printer, no Klipper.
#
# This also stands as a direct regression test on the two installer/build.py
# functions the harness leans on (render_template, KConfig.as_dict), so a breaking
# change there fails fast and legibly here rather than surfacing later as a
# mysterious bootup failure.
#
# Requires jinja2 (installer/requirements.txt) - run with the repo venv:
#   ./venv/bin/python -m unittest test.test_mmu_config
#
# This file may be distributed under the terms of the GNU GPLv3 license.

import ast
import os
import re
import tempfile
import unittest

import jinja2

from test.hh import bootstrap, cfg, profiles

HARDWARE = 'config/base/mmu_hardware.cfg'
MMU = 'config/base/mmu.cfg'
PARAMS = 'config/base/mmu_parameters.cfg'
MACRO_VARS = 'config/base/mmu_macro_vars.cfg'


class TestKlipperTuningRender(unittest.TestCase):

    def test_shipped_defaults_and_custom_values_for_single_and_multi_unit(self):
        defaults = {
            'update_trsync': 0,
            'update_bit_max_time': 1,
            'update_aht10_commands': 0,
            'suppress_klipper_warnings': 0,
        }
        overrides = {
            'update_trsync': 1,
            'update_bit_max_time': 0,
            'update_aht10_commands': 1,
            'suppress_klipper_warnings': 1,
        }
        for name in ('boxturtle', 'ercf_vvd'):
            base = profiles.get(name)
            for label, expected in (('defaults', defaults), ('custom', overrides)):
                with self.subTest(profile=name, settings=label):
                    profile = base if label == 'defaults' else base.derive(
                        name + '_klipper_tuning',
                        syms={'PARAM_' + key.upper(): value
                              for key, value in expected.items()})
                    rendered = cfg.render(profile)
                    cfg.assert_sane(rendered)
                    params = cfg.assemble(rendered)['mmu_parameters']
                    self.assertNotIn('canbus_comms_retries', params)
                    for key, value in expected.items():
                        self.assertEqual(params.getint(key), value, key)


class TestBoxTurtleRender(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.rendered = cfg.render(profiles.get('boxturtle'))

    def test_no_silent_misrender(self):
        """
        Chip-less pins (':PD5' rather than 'unit0:PD5') and leftover template
        tokens are the two ways this pipeline produces wrong-but-parseable config.
        Neither raises on its own, so assert explicitly.
        """
        cfg.assert_sane(self.rendered)

    def test_hardware_sections(self):
        secs = cfg.sections(self.rendered[HARDWARE])
        for expected in ('mcu unit0', 'mmu_unit unit0', 'mmu_sensors unit0',
                         'mmu_espooler unit0', 'mmu_leds unit0', 'mmu_buffer unit0',
                         'neopixel _unit0_leds',
                         'tmc2209 mmu_stepper unit0_gear', 'mmu_stepper unit0_gear'):
            self.assertIn(expected, secs)
        # 4 gates -> gear + gear_1..gear_3, each with its own TMC section
        for i in ('', '_1', '_2', '_3'):
            self.assertIn('mmu_stepper unit0_gear%s' % i, secs)
            self.assertIn('tmc2209 mmu_stepper unit0_gear%s' % i, secs)

    def test_led_effect_defaults_are_preserved(self):
        leds = dict(cfg.assemble(self.rendered).items('mmu_leds unit0'))
        self.assertEqual(leds['exit_effect'], 'gate_status')
        self.assertEqual(leds['entry_effect'], 'filament_color')
        self.assertEqual(leds['status_effect'], 'filament_color')

    def test_led_effect_choices_remain_visible_for_empty_segments(self):
        with cfg._env(cfg._SINGLE_UNIT_ENV):
            kconfig = cfg._kconfig(
                'boxturtle_led_effect_visibility',
                profiles.get('boxturtle').syms)

        for choice in ('CHOICE_EXIT_EFFECT', 'CHOICE_ENTRY_EFFECT',
                       'CHOICE_STATUS_EFFECT'):
            self.assertGreater(kconfig.named_choices[choice].visibility, 0)

    def test_led_effect_choices_render_into_the_unit_config(self):
        profile = profiles.get('boxturtle').derive(
            'boxturtle_led_effect_choices',
            syms={
                'PARAM_ENTRY_LEDS': 'neopixel:_unit0_leds (5-8)',
                'PARAM_STATUS_LEDS': 'neopixel:_unit0_leds (9)',
                'CHOICE_EXIT_EFFECT_OFF': True,
                'CHOICE_ENTRY_EFFECT_GATE_STATUS': True,
                'CHOICE_STATUS_EFFECT_SLICER_COLOR': True,
            })
        with cfg._env(cfg._SINGLE_UNIT_ENV):
            kconfig = cfg._kconfig(profile.name, profile.syms)
        for choice in ('CHOICE_EXIT_EFFECT', 'CHOICE_ENTRY_EFFECT',
                       'CHOICE_STATUS_EFFECT'):
            self.assertGreater(kconfig.named_choices[choice].visibility, 0)

        leds = dict(cfg.assemble(cfg.render(profile)).items('mmu_leds unit0'))
        self.assertEqual(leds['exit_effect'], 'off')
        self.assertEqual(leds['entry_effect'], 'gate_status')
        self.assertEqual(leds['status_effect'], 'slicer_color')

    def test_serialized_config_home_does_not_quote_save_variables_path(self):
        env = dict(cfg._SINGLE_UNIT_ENV,
                   CONFIG_KLIPPER_CONFIG_HOME='"~/printer_data/config"')
        with cfg._env(env):
            kconfig = cfg._kconfig(
                'quoted_config_home', profiles.get('boxturtle').syms)

        self.assertEqual(kconfig.get('PARAM_MMU_VARS_CFG'),
                         '~/printer_data/config/mmu/mmu_vars.cfg')
        rendered = cfg._render_templates(
            (MACRO_VARS,), kconfig, {'PARAM_TOTAL_NUM_GATES': 4})
        self.assertIn(
            'filename: ~/printer_data/config/mmu/mmu_vars.cfg\n',
            rendered[MACRO_VARS])

    def test_mmu_sections(self):
        secs = cfg.sections(self.rendered[MMU])
        for expected in ('mmu_machine', 'mmu_parameters', 'mmu_toolhead default'):
            self.assertIn(expected, secs)
        # The LED effect palette the session-5 work renamed
        for effect in ('mmu_led_effect mmu_breathing_purple_slow',
                       'mmu_led_effect mmu_breathing_purple_fast',
                       'mmu_led_effect mmu_red_strobe',
                       'mmu_led_effect mmu_green_strobe_fast'):
            self.assertIn(effect, secs)

    def test_parameters_and_macro_var_sections(self):
        self.assertIn('mmu_unit_parameters unit0', cfg.sections(self.rendered[PARAMS]))
        parser = cfg.assemble(self.rendered)
        params = dict(parser.items('mmu_unit_parameters unit0'))
        self.assertEqual(params['gate_homing_endstop'], 'mmu_shared_exit')
        self.assertEqual(params['gate_homing_max'], '300')
        self.assertEqual(params['gate_parking_distance'], '-100')
        self.assertEqual(params['gate_preload_endstop'], 'mmu_exit')
        self.assertEqual(params['gate_preload_homing_max'], '200')
        self.assertEqual(params['gate_preload_parking_distance'], '10')

        secs = cfg.sections(self.rendered[MACRO_VARS])
        # HH reads .variables off these at connect/ready
        # (extras/mmu/mmu_controller.py:205-207, 219-221)
        for expected in ('save_variables', 'pause_resume', 'extruder',
                         'virtual_sdcard', 'display_status',
                         'gcode_macro _MMU_SEQUENCE_VARS'):
            self.assertIn(expected, secs)

    def test_sensorless_preload_choice_renders_none_and_one_attempt(self):
        profile = profiles.get('boxturtle').derive(
            'boxturtle_sensorless_preload',
            syms={'CHOICE_GATE_PRELOAD_ENDSTOP_NONE': True})
        rendered = cfg.render(profile)
        parser = cfg.assemble(rendered)
        params = dict(parser.items('mmu_unit_parameters unit0'))

        self.assertEqual(params['gate_preload_endstop'], 'none')
        # The prompt is hidden in this mode, but the typed symbol retains an explicit value.
        self.assertEqual(params['gate_preload_attempts'], '1')

    def test_every_rendered_macro_variable_is_a_valid_klipper_literal(self):
        """Real Klipper rejects the entire config if any variable is not a Python literal."""
        parser = cfg.assemble(self.rendered, macros=False)
        for section in parser.sections():
            if not section.startswith('gcode_macro '):
                continue
            for option, value in parser.items(section):
                if option.startswith('variable_'):
                    with self.subTest(section=section, option=option, value=value):
                        ast.literal_eval(value)

    def test_unit_topology_is_self_consistent(self):
        """
        The [mmu_unit] body drives the whole construction tree, so a template
        regression here would surface as a confusing failure much later.
        """
        parser = cfg.assemble(self.rendered)
        unit = dict(parser.items('mmu_unit unit0'))
        self.assertEqual(unit['selector_type'], 'VirtualSelector')
        gears = [g.strip() for g in unit['gear_steppers'].split(',')]
        self.assertEqual(gears, ['unit0_gear', 'unit0_gear_1',
                                 'unit0_gear_2', 'unit0_gear_3'])
        # num_gates is per-unit; [mmu_machine] only names the units
        self.assertEqual(int(unit['num_gates']), 4)
        machine = dict(parser.items('mmu_machine'))
        self.assertEqual([u.strip() for u in machine['units'].split(',')], ['unit0'])

    def test_happy_hare_version_is_substituted(self):
        """
        [mmu_machine] happy_hare_version comes from $HH_VERSION via the Kconfig.
        If the env var is unset it renders as the literal '$HH_VERSION', and
        extras/mmu_machine.py:44-47 then either raises "not installed correctly" or
        blows up comparing major.minor - so pin it to the canonical VERSION.
        """
        machine = dict(cfg.assemble(self.rendered).items('mmu_machine'))
        self.assertEqual(machine['happy_hare_version'], cfg.hh_version())
        self.assertNotIn('$', machine['happy_hare_version'])

    def test_section_order_is_load_bearing(self):
        """
        [mmu_machine] MUST be processed before [mmu_stepper unit0_gear].

        MmuUnit force-loads each gear stepper itself with force_rail=True
        (extras/mmu/mmu_unit.py:305-312). If Klipper's generic section loop reached
        [mmu_stepper unit0_gear] first - it has its own load_config_prefix
        (extras/mmu_stepper.py:1311) - the stepper would be built WITHOUT a rail and
        HH's subsequent add_object would collide. Production works only because the
        sorted glob of mmu/base/*.cfg puts mmu.cfg ahead of mmu_hardware.cfg.
        """
        parser = cfg.assemble(self.rendered)
        order = parser.sections()
        self.assertLess(order.index('mmu_machine'),
                        order.index('mmu_stepper unit0_gear'),
                        'mmu.cfg must sort before mmu_hardware.cfg - see '
                        'test/hh/cfg.py BASE_TEMPLATES')

    def test_assemble_tolerates_duplicate_extruder_section(self):
        """
        [extruder] appears in both the printer stub (stepper options, which
        MmuExtruderWrapper needs at extras/mmu/unit/mmu_extruder_wrapper.py:64-65)
        and mmu_macro_vars.cfg (extrude limits). RawConfigParser(strict=False) must
        merge rather than raise.
        """
        stub = ('[extruder]\n'
                'step_pin: mcu:PA1\n'
                'dir_pin: mcu:PA2\n'
                'enable_pin: !mcu:PA3\n'
                'rotation_distance: 22.0\n'
                'microsteps: 16\n'
                'full_steps_per_rotation: 200\n')
        parser = cfg.assemble(self.rendered, printer_stub=stub)
        extruder = dict(parser.items('extruder'))
        self.assertEqual(extruder['step_pin'], 'mcu:PA1')          # from the stub
        self.assertIn('max_extrude_only_distance', extruder)       # from the template


class TestConditionalMacroDefaults(unittest.TestCase):

    def test_hidden_feature_menus_keep_rendering_defaults_active(self):
        """Menu visibility must not turn required Jinja values into empty strings."""
        with cfg._env(cfg._SINGLE_UNIT_ENV):
            kc = cfg._kconfig('conditional_macro_defaults', {
                'INSTALL_CLIENT_MACROS': False,
                'MMU_HAS_TOOLHEAD_CUTTER': False,
                'MMU_HAS_BLOBIFIER': False,
                'MMU_HAS_SERVO_CUTTER': False,
            })

        expected = {
            'VAR_CLIENT_UNLOAD_TOOL_ON_CANCEL': 'False',
            'VAR_CUT_TIP_RESTORE_POSITION': 'False',
            'VAR_CUT_TIP_BLADE_POS': '37.5',
            'VAR_BLOBIFIER_PURGE_SPD': '400',
            'VAR_SERVO_CUTTER_SERVO_DURATION': '1.5',
        }
        for name, value in expected.items():
            with self.subTest(symbol=name):
                self.assertEqual(kc.syms[name].str_value, value)
                self.assertTrue(kc.syms[name].config_string)


class TestHardwareConfigurationWarnings(unittest.TestCase):

    @staticmethod
    def _kconfig(name, syms):
        with cfg._env(cfg._SINGLE_UNIT_ENV):
            return cfg._kconfig(name, syms)

    def test_missing_shared_heater_name_is_warned(self):
        syms = dict(profiles.get('qidi').syms, PARAM_FILAMENT_HEATER='')
        self.assertTrue(self._kconfig('missing_heater_name', syms).is_enabled('W13'))

        syms['PARAM_FILAMENT_HEATER'] = 'qidi_heater'
        self.assertFalse(self._kconfig('configured_heater_name', syms).is_enabled('W13'))

    def test_missing_shared_environment_sensor_name_is_warned(self):
        syms = dict(profiles.get('qidi').syms, PARAM_ENVIRONMENT_SENSOR='')
        self.assertTrue(self._kconfig('missing_environment_name', syms).is_enabled('W14'))

        syms['PARAM_ENVIRONMENT_SENSOR'] = 'qidi_environment'
        self.assertFalse(self._kconfig('configured_environment_name', syms).is_enabled('W14'))

    def test_missing_per_gate_environment_sensor_names_are_warned(self):
        syms = dict(profiles.get('emu').syms)
        syms.update({'PARAM_ENVIRONMENT_SENSOR_GATE_%d' % gate: False
                     for gate in range(5)})
        self.assertTrue(self._kconfig('missing_per_gate_environment_names', syms).is_enabled('W14'))
        self.assertFalse(self._kconfig(
            'configured_per_gate_environment_names', profiles.get('emu').syms
        ).is_enabled('W14'))


class TestCustomHardwareCapabilities(unittest.TestCase):

    def test_custom_nfc_capability_is_declared_with_the_other_custom_hardware(self):
        with cfg._env(cfg._SINGLE_UNIT_ENV):
            kconfig = cfg._kconfig('custom_nfc_capability', profiles.get('qidi').syms)
        self.assertTrue(any(
            node.filename.endswith('Kconfig.capabilities')
            for node in kconfig.syms['CUSTOM_NFC_READER_SETUP'].nodes
        ))

    def test_custom_nfc_setup_does_not_enable_nfc_without_the_capability(self):
        profile = profiles.get('qidi').derive(
            'custom_nfc_without_capability',
            syms={'MMU_HAS_NFC_READER': False},
            extra_params={'CUSTOM_NFC_READER_SETUP': True})
        rendered = cfg.render(profile)
        self.assertNotIn('nfc_deep_read', rendered[PARAMS])


class TestBlobifierFirmwareDetection(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        profile = profiles.get('boxturtle').derive(
            'blobifier_firmware_detection', syms={'MMU_HAS_BLOBIFIER': True})
        cls.parser = cfg.assemble(cfg.render(profile))
        env = jinja2.Environment('{%', '%}', '{', '}', undefined=jinja2.StrictUndefined)
        cls.template = env.from_string(
            cls.parser['gcode_macro _BLOBIFIER_HOME_STEPPER']['gcode'])

    def test_uses_runtime_firmware_and_preserves_initialization_guard(self):
        for kalico, syntax in ((0, 'try_home'), (1, '2')):
            for initialized in (0, 1):
                with self.subTest(kalico=kalico, initialized=initialized):
                    # No _BLOBIFIER_VARS.firmware: firmware selection must come from MMU status.
                    rendered = self.template.render(printer={
                        'mmu': {'kalico': kalico},
                        'gcode_macro BLOBIFIER': {'initialized': initialized},
                    })
                    commands = [line.strip() for line in rendered.splitlines()
                                if line.strip().startswith('MANUAL_STEPPER ')]
                    expected = [] if not initialized else [
                        'MANUAL_STEPPER STEPPER=stepper_blobifier ENABLE=1 SET_POSITION=30 SYNC=1',
                        'MANUAL_STEPPER STEPPER=stepper_blobifier MOVE=0 SPEED=20 STOP_ON_ENDSTOP=' + syntax,
                    ]
                    self.assertEqual(commands, expected)

    def test_generated_variables_do_not_require_firmware_selection(self):
        self.assertNotIn('variable_firmware', self.parser['gcode_macro _BLOBIFIER_VARS'])


class TestBlobifierHooksRender(unittest.TestCase):

    def test_defaults_custom_hooks_and_disabled_cleaning(self):
        defaults = {
            'user_pre_blobifier_extension': '',
            'clean_macro': 'BLOBIFIER_CLEAN',
            'user_post_purge_extension': '',
            'user_post_blobifier_extension': '',
        }
        custom = {
            'user_pre_blobifier_extension': 'MY_PARK',
            'clean_macro': 'MY_CLEAN PASSES=2',
            'user_post_purge_extension': 'RESPOND MSG="purge complete"',
            'user_post_blobifier_extension': 'MY_GANTRY_WIPE',
        }
        for name in ('boxturtle', 'ercf_vvd'):
            for label, enabled, expected in (
                    ('blobifier_disabled', False, defaults),
                    ('defaults', True, defaults),
                    ('custom', True, custom),
                    ('cleaning_disabled', True, dict(defaults, clean_macro=''))):
                with self.subTest(profile=name, settings=label):
                    syms = {'MMU_HAS_BLOBIFIER': enabled}
                    if label in ('custom', 'cleaning_disabled'):
                        syms.update({'VAR_BLOBIFIER_' + key.upper(): value
                                     for key, value in expected.items()})
                    profile = profiles.get(name).derive(
                        name + '_blobifier_hooks_' + label, syms=syms)
                    rendered = cfg.render(profile)
                    cfg.assert_sane(rendered)
                    parser = cfg.assemble(rendered, macros=False)
                    if not enabled:
                        self.assertNotIn('gcode_macro _BLOBIFIER_VARS', parser)
                        continue
                    variables = parser['gcode_macro _BLOBIFIER_VARS']
                    for key, value in expected.items():
                        self.assertEqual(ast.literal_eval(variables['variable_' + key]),
                                         value, key)


class TestMenuconfigMacroStrings(unittest.TestCase):

    def _pre_unload_value(self, configured, profile_name):
        profile = profiles.get('boxturtle').derive(
            profile_name,
            syms={'VAR_SEQUENCE_USER_PRE_UNLOAD_EXTENSION': configured})
        rendered = cfg.render(profile)
        parser = cfg.assemble(rendered, macros=False)
        raw = dict(parser.items('gcode_macro _MMU_SEQUENCE_VARS'))[
            'variable_user_pre_unload_extension']
        return raw, ast.literal_eval(raw)

    def test_plain_gcode_is_rendered_as_a_string_literal(self):
        raw, value = self._pre_unload_value('MY_PRE_UNLOAD', 'macro_string_plain')
        self.assertEqual(raw, '"MY_PRE_UNLOAD"')
        self.assertEqual(value, 'MY_PRE_UNLOAD')

    def test_empty_hook_is_an_empty_string_not_a_blank_value(self):
        raw, value = self._pre_unload_value('', 'macro_string_empty')
        self.assertEqual(raw, '""')
        self.assertEqual(value, '')

    def test_arbitrary_quotes_backslashes_and_newlines_survive_round_trip(self):
        configured = 'RESPOND MSG="can\'t unload" PATH=C:\\tmp\\tool\\nM117 done'
        raw, value = self._pre_unload_value(configured, 'macro_string_escaping')
        self.assertEqual(value, configured.replace('\\n', '\n'))
        self.assertIn('\\"', raw)
        self.assertIn('\\\\tmp', raw)
        self.assertIn('\\n', raw)

    def test_malformed_quoted_input_does_not_abort_jinja_rendering(self):
        configured = 'RESPOND MSG="unterminated'
        raw, value = self._pre_unload_value(configured, 'macro_string_malformed_quote')
        self.assertEqual(value, configured)
        self.assertTrue(raw.startswith('"'))

    def test_unexpected_internal_value_renders_invalid_sentinel_instead_of_raising(self):
        cfg._prepare_imports()
        from installer import build

        class Unstringable:
            def __str__(self):
                raise RuntimeError('cannot stringify')

        with self.assertLogs(level='ERROR'):
            rendered = build.klipper_string_literal(Unstringable())
        self.assertEqual(rendered, build.INVALID_KLIPPER_STRING_LITERAL)
        with self.assertRaises((SyntaxError, ValueError)):
            ast.literal_eval(rendered)

    def test_existing_manually_quoted_workaround_is_not_double_quoted(self):
        raw, value = self._pre_unload_value("'LEGACY_PRE_UNLOAD'",
                                            'macro_string_legacy_quotes')
        self.assertEqual(raw, '"LEGACY_PRE_UNLOAD"')
        self.assertEqual(value, 'LEGACY_PRE_UNLOAD')

    def test_optional_blobifier_fan_name_uses_the_same_encoding(self):
        profile = profiles.get('boxturtle').derive(
            'macro_string_blobifier',
            syms={'MMU_HAS_BLOBIFIER': True,
                  'VAR_BLOBIFIER_FAN_NAME': 'fan_generic fan0'})
        rendered = cfg.render(profile)
        parser = cfg.assemble(rendered, macros=False)
        raw = dict(parser.items('gcode_macro _BLOBIFIER_VARS'))['variable_fan_name']
        self.assertEqual(raw, '"fan_generic fan0"')
        self.assertEqual(ast.literal_eval(raw), 'fan_generic fan0')


class TestEnvironmentSensorReportTime(unittest.TestCase):

    def _single_sensor(self, name, choice):
        profile = profiles.get('boxturtle').derive(
            name,
            syms={
                'MMU_HAS_ENVIRONMENT_SENSOR': True,
                choice: True,
            })
        with cfg._env(cfg._SINGLE_UNIT_ENV):
            kc = cfg._kconfig(name, profile.syms)
        rendered = cfg.render(profile)
        parser = cfg.assemble(rendered, macros=False)
        sensor = dict(parser.items('temperature_sensor unit0_Env'))
        return kc, sensor

    def test_aht_sensor_uses_selected_report_time_parameter(self):
        kc, sensor = self._single_sensor(
            'environment_sensor_aht_report_time',
            'CHOICE_ENVIRONMENT_SENSOR_TYPE_AHT2X')

        self.assertEqual(kc.get('PARAM_SENSOR_REPORT_TIME_PARAM'),
                         'aht10_report_time')
        self.assertEqual(sensor['sensor_type'], 'AHT2X')
        self.assertEqual(sensor['aht10_report_time'], '60')

    def test_bme280_sensor_omits_unsupported_report_time_parameter(self):
        kc, sensor = self._single_sensor(
            'environment_sensor_bme_report_time',
            'CHOICE_ENVIRONMENT_SENSOR_TYPE_BME280')

        self.assertEqual(kc.get('PARAM_SENSOR_REPORT_TIME_PARAM'), '')
        self.assertEqual(sensor['sensor_type'], 'BME280')
        self.assertNotIn('aht10_report_time', sensor)
        self.assertNotIn('bme_report_time', sensor)
        self.assertNotIn('bme280_report_time', sensor)

    def test_mixed_per_gate_sensors_select_report_parameter_independently(self):
        env = dict(cfg._SINGLE_UNIT_ENV, F_PER_GATE_MCU='y')
        with cfg._env(env):
            kc = cfg._kconfig('environment_sensor_mixed_per_gate', {
                'MMU_TYPE_EMU_1_0': True,
                'MMU_HAS_PER_GATE_MCU': True,
                'CHOICE_ENVIRONMENT_SENSOR_TYPE_BME280_0': True,
                'CHOICE_ENVIRONMENT_SENSOR_TYPE_AHT1X_1': True,
            })

        rendered = cfg._render_templates(
            (HARDWARE,), kc,
            {'PARAM_TOTAL_NUM_GATES': kc.getint('PARAM_NUM_GATES')})
        parser = cfg.assemble(rendered, macros=False)
        bme = dict(parser.items('temperature_sensor unit0_Env0'))
        aht = dict(parser.items('temperature_sensor unit0_Env1'))

        self.assertEqual(kc.get('PARAM_SENSOR_REPORT_TIME_PARAM_0'), '')
        self.assertEqual(kc.get('PARAM_SENSOR_REPORT_TIME_PARAM_1'),
                         'aht10_report_time')
        self.assertEqual(bme['sensor_type'], 'BME280')
        self.assertNotIn('aht10_report_time', bme)
        self.assertNotIn('bme_report_time', bme)
        self.assertNotIn('bme280_report_time', bme)
        self.assertEqual(aht['sensor_type'], 'AHT1X')
        self.assertEqual(aht['aht10_report_time'], '60')


class TestOptionalBlobifierBucketSwitch(unittest.TestCase):

    def _render_mmu(self, name, syms):
        profile = profiles.get('boxturtle').derive(
            name,
            syms=dict({
                'MMU_HAS_BLOBIFIER': True,
                'PIN_BLOBIFIER_SERVO': 'unit0:PA1',
            }, **syms))
        return cfg.render(profile)[MMU]

    def test_blobifier_does_not_require_a_bucket_switch(self):
        mmu = self._render_mmu('blobifier_without_bucket_switch', {
            'MMU_HAS_BLOBIFIER_BUCKET_SWITCH': False,
        })
        self.assertNotIn('gcode_button bucket', cfg.sections(mmu))
        self.assertNotIn('gcode_macro _BLOBIFIER_BUCKET_SWITCH', cfg.sections(mmu))

    def test_bucket_switch_defaults_to_enabled(self):
        mmu = self._render_mmu('blobifier_default_bucket_switch', {})
        self.assertIn('gcode_button bucket', cfg.sections(mmu))

        with cfg._env(cfg._SINGLE_UNIT_ENV):
            kc = cfg._kconfig('no_blobifier_bucket_switch_warning', {
                'MMU_HAS_BLOBIFIER': False,
            })
        self.assertFalse(kc.is_enabled('SW4'))

    def test_bucket_switch_is_rendered_when_enabled(self):
        mmu = self._render_mmu('blobifier_with_bucket_switch', {
            'MMU_HAS_BLOBIFIER_BUCKET_SWITCH': True,
            'PIN_BLOBIFIER_BUCKET_SWITCH': '^unit0:PA2',
        })
        parser = cfg.assemble({MMU: mmu})
        self.assertEqual(
            dict(parser.items('gcode_button bucket'))['pin'],
            '^unit0:PA2')
        self.assertEqual(
            dict(parser.items('gcode_button bucket'))['debounce_delay'],
            '0.5')
        self.assertEqual(
            dict(parser.items('gcode_macro _BLOBIFIER_BUCKET_SWITCH'))['variable_armed'],
            '0')
        button_gcode = dict(parser.items('gcode_button bucket'))
        self.assertIn('RESPOND PREFIX="BLOBIFIER"', button_gcode['press_gcode'])
        self.assertIn('Bucket switch pressed', button_gcode['press_gcode'])
        self.assertIn('resetting count', button_gcode['release_gcode'])
        self.assertIn('reset ignored', button_gcode['release_gcode'])

    def test_enabled_bucket_switch_without_a_pin_is_rendered_and_warned(self):
        mmu = self._render_mmu('blobifier_bucket_switch_missing_pin', {
            'MMU_HAS_BLOBIFIER_BUCKET_SWITCH': True,
            'PIN_BLOBIFIER_BUCKET_SWITCH': '',
        })
        self.assertIn('gcode_button bucket', cfg.sections(mmu))

        with cfg._env(cfg._SINGLE_UNIT_ENV):
            kc = cfg._kconfig('blobifier_bucket_switch_missing_pin_warning', {
                'MMU_HAS_BLOBIFIER': True,
                'MMU_HAS_BLOBIFIER_BUCKET_SWITCH': True,
                'PIN_BLOBIFIER_BUCKET_SWITCH': '',
            })
        self.assertTrue(kc.is_enabled('SW4'))

# Deliberately TWO IDENTICAL BOXTURTLES rather than the real ercf_vvd profile. The point is
# to test the multi-unit RENDER PATH, so both units being the machine every other test
# already trusts means a failure here is the path and not an ERCF or ViViD quirk. It lives
# in this file rather than the PROFILES registry because it is a test fixture, not a machine
# anyone would run.
# Note there are NO shared syms. MULTI_UNIT, MULTI_UNIT_ENTRY_POINT and MMU_UNITS all have
# no prompt (Kconfig:146-162) - they are driven purely by env, so setting them here would warn
# and do nothing. Supplying `units` is the whole declaration; cfg.py derives the rest, which is
# why clone_across_units() needs to say so little.
TWO_UNIT = profiles.clone_across_units(
    'two_boxturtles', profiles.get('boxturtle'), ('unit0', 'unit1'),
    description='two BoxTurtles, for the multi-unit render path')


class TestMultiUnitRender(unittest.TestCase):
    """
    A multi-unit render is THREE Kconfig parses with different env, not one
    (install.sh:385-432). Everything here is a way for that plumbing to be silently wrong.
    """

    @classmethod
    def setUpClass(cls):
        cls.rendered = cfg.render(TWO_UNIT)

    def test_no_silent_misrender(self):
        """
        The cheapest and most specific check on the per-unit env: get MCU_NAME wrong and
        unit1's pins render as ':PD5' rather than 'unit1:PD5'.
        """
        cfg.assert_sane(self.rendered)

    def test_produces_the_installers_file_set_in_include_order(self):
        """
        Per-unit files carry a _<unit> suffix (Makefile:151-158) while mmu.cfg and
        mmu_macro_vars.cfg stay single. Insertion order IS include order for assemble(),
        and Klipper's glob is sorted.
        """
        self.assertEqual(list(self.rendered), [
            'config/base/mmu.cfg',
            'config/base/mmu_hardware_unit0.cfg',
            'config/base/mmu_hardware_unit1.cfg',
            'config/base/mmu_macro_vars.cfg',
            'config/base/mmu_parameters_unit0.cfg',
            'config/base/mmu_parameters_unit1.cfg',
        ])

    def test_each_unit_gets_its_own_mcu_pins(self):
        """
        THE test for per-parse env. kconfiglib expands $(MCU_NAME) into every board pin
        default at parse time, so if the second parse reused the first's env, unit1's
        hardware would be full of 'unit0:' pins - a valid-looking config wired to the wrong
        board.
        """
        for unit in ('unit0', 'unit1'):
            hw = self.rendered['config/base/mmu_hardware_%s.cfg' % unit]
            chips = {m.group(1) for m in re.finditer(r'[:!^~]?(unit\d+):', hw)}
            self.assertEqual(chips, {unit},
                             '%s references chips %s' % (unit, sorted(chips)))

    def test_units_are_declared_on_mmu_machine(self):
        parser = cfg.assemble(self.rendered)
        self.assertEqual(dict(parser.items('mmu_machine'))['units'], 'unit0,unit1')

    def test_gate_counts_are_per_unit_and_the_total_is_their_sum(self):
        """
        PARAM_TOTAL_NUM_GATES is the CROSS-UNIT SUM (build.py:481-492), not this unit's
        count. It drives the Tx macro wrappers, which are printer-wide - so a machine with
        4+4 gates needs T0..T7, and getting it wrong silently loses half the tools.
        """
        parser = cfg.assemble(self.rendered)
        for unit in ('unit0', 'unit1'):
            self.assertEqual(int(dict(parser.items('mmu_unit %s' % unit))['num_gates']), 4)
        tools = sorted(int(m.group(1)) for m in
                       (re.fullmatch(r'gcode_macro T(\d+)', s) for s in parser.sections())
                       if m)
        self.assertEqual(tools, list(range(8)),
                         'expected T0..T7 for a 4+4 gate machine')

    def test_a_multi_unit_render_does_not_leak_env_into_later_renders(self):
        """
        The env-leak guard, and the reason _env() restores rather than just assigns.

        ORDER IS LOAD-BEARING: the multi-unit render has to happen BETWEEN the two
        single-unit ones, because a leak only shows in a parse that follows it. A leaked
        MCU_NAME=unit1 would re-render boxturtle against unit1's MCU - wrong output, not an
        error, and assert_sane cannot see it because the pins are still well-formed.

        This also fails if the _render_cache key ever stops accounting for the units, since
        a stale cache would hand back the first render and hide a genuine leak.
        """
        before = cfg.render(profiles.get('boxturtle'))
        cfg.render(TWO_UNIT)
        # A distinct name so the cache cannot answer this from the first call
        again = cfg.render(profiles.Profile(
            'boxturtle_after_multi_unit',
            syms=dict(profiles.get('boxturtle').syms),
            description='env-leak guard'))

        self.assertEqual(sorted(before), sorted(again))
        for name in before:
            self.assertEqual(before[name], again[name],
                             '%s changed after an intervening multi-unit render - env '
                             'leaked out of _env()' % name)


class TestSelectorTypeChoice(unittest.TestCase):
    """
    The CHOICE_SELECTOR_TYPE menu (installer/Kconfig.selector_type, depends on MMU_CUSTOM) is
    not exercised by any Profile - every real machine picks its selector implicitly, through
    its own mmu_types/Kconfig.<vendor> defaults, never through this menu. So a broken choice
    here has no other test to catch it; hence going straight at kconfiglib rather than adding a
    whole custom-MMU profile just to reach one menu.

    LinearMultiGearSelector specifically had a typo'd symbol name (LINEAR_MUTLI_GEAR_SELECTOR)
    at the choice-option declaration, while the PARAM_SELECTOR_TYPE default (and
    Kconfig.speeds' depends on) used the correctly-spelled LINEAR_MULTI_GEAR_SELECTOR - a
    symbol that therefore never existed, so selecting this option in the installer silently
    fell through to the "VirtualSelector # Safety" catch-all instead.
    """

    def test_choosing_linear_multi_gear_selector_sets_the_matching_param(self):
        with cfg._env({}):
            kc = cfg._kconfig('linear-multi-gear-selector-choice', {
                'MMU_CUSTOM': True,
                'CHOICE_SELECTOR_TYPE_LINEAR_MULTI_GEAR_SELECTOR': True,
            })
        self.assertEqual(kc.syms['PARAM_SELECTOR_TYPE'].str_value, 'LinearMultiGearSelector')


class TestRenderKconfigReuse(unittest.TestCase):
    """Rendering reuses parse trees without leaking one profile's values into another."""

    def setUp(self):
        cfg._render_cache.clear()
        cfg._render_kconfig_cache.clear()

    def tearDown(self):
        cfg._render_cache.clear()
        cfg._render_kconfig_cache.clear()

    def test_single_unit_profiles_share_one_parse_and_reset_values(self):
        original = cfg._new_kconfig
        parses = []

        def counted(label):
            parses.append(label)
            return original(label)

        cfg._new_kconfig = counted
        self.addCleanup(setattr, cfg, '_new_kconfig', original)

        first = profiles.get('boxturtle').derive(
            'reuse_first', syms={'PARAM_GATE_PARKING_DISTANCE': -81})
        second = profiles.get('boxturtle').derive(
            'reuse_second', syms={'PARAM_GATE_PARKING_DISTANCE': -82})
        first_parser = cfg.assemble(cfg.render(first))
        second_parser = cfg.assemble(cfg.render(second))

        self.assertEqual(len(parses), 1)
        self.assertEqual(dict(first_parser.items('mmu_unit_parameters unit0'))[
            'gate_parking_distance'], '-81')
        self.assertEqual(dict(second_parser.items('mmu_unit_parameters unit0'))[
            'gate_parking_distance'], '-82')

    def test_multi_unit_environments_never_share_a_tree(self):
        original = cfg._new_kconfig
        parses = []

        def counted(label):
            parses.append(label)
            return original(label)

        cfg._new_kconfig = counted
        self.addCleanup(setattr, cfg, '_new_kconfig', original)

        cfg.render(TWO_UNIT)

        self.assertEqual(len(parses), 3)
        self.assertEqual(set(parses), {
            'two_boxturtles', 'two_boxturtles:unit0', 'two_boxturtles:unit1'})


class TestPreviousKconfigSelections(unittest.TestCase):
    """Unavailable dynamic devices remain selectable through a stable previous option."""

    KCONFIG_TEMPLATE = '''\
mainmenu "Previous selection test"

config CURRENT_AVAILABLE
  bool
  default %s

choice DEVICE_CHOICE
  prompt "Select device"
  default DEVICE_PREVIOUS if "$(saved-config-value,PARAM_DEVICE)" != ""
  default DEVICE_CURRENT if CURRENT_AVAILABLE

  config DEVICE_PREVIOUS
    bool "Previous selection: $(saved-config-value,PARAM_DEVICE)"
    depends on "$(saved-config-value,PARAM_DEVICE)" != ""

  config DEVICE_CURRENT
    bool "Current device"
    depends on CURRENT_AVAILABLE

  config DEVICE_OTHER
    bool "Other"
endchoice

config PARAM_DEVICE
  string
  default "$(saved-config-value,PARAM_DEVICE)" if DEVICE_PREVIOUS
  default "/dev/current" if DEVICE_CURRENT
  default "/dev/other" if DEVICE_OTHER
'''

    @classmethod
    def setUpClass(cls):
        cfg._prepare_imports()
        import kconfiglib
        cls.kconfiglib = kconfiglib

    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.kconfig_path = os.path.join(self.tmpdir.name, 'Kconfig')
        self.config_path = os.path.join(self.tmpdir.name, '.config')

    def tearDown(self):
        self.tmpdir.cleanup()

    def _parse(self, current_available):
        with open(self.kconfig_path, 'w') as f:
            f.write(self.KCONFIG_TEMPLATE % ('y' if current_available else 'n'))
        with cfg._env({'KCONFIG_CONFIG': self.config_path}):
            return self.kconfiglib.Kconfig(self.kconfig_path, warn=False)

    def test_previous_option_survives_discovery_changes_and_tracks_new_selection(self):
        kc = self._parse(current_available=True)
        self.assertEqual(kc.named_choices['DEVICE_CHOICE'].selection.name,
                         'DEVICE_CURRENT')
        kc.write_config(self.config_path, save_old=False)

        with open(self.config_path) as f:
            saved = f.read()
        self.assertIn('CONFIG_PARAM_DEVICE="/dev/current" #~DEFAULT~#', saved)

        kc = self._parse(current_available=False)
        kc.load_config(self.config_path)
        self.assertEqual(kc.named_choices['DEVICE_CHOICE'].selection.name,
                         'DEVICE_PREVIOUS')
        self.assertEqual(kc.syms['PARAM_DEVICE'].str_value, '/dev/current')
        self.assertEqual(kc.syms['DEVICE_PREVIOUS'].nodes[0].prompt[0],
                         'Previous selection: /dev/current')

        kc.syms['DEVICE_OTHER'].set_value(2)
        kc.write_config(self.config_path, save_old=False)
        kc = self._parse(current_available=False)
        kc.load_config(self.config_path)
        self.assertEqual(kc.named_choices['DEVICE_CHOICE'].selection.name,
                         'DEVICE_OTHER')
        self.assertEqual(kc.syms['PARAM_DEVICE'].str_value, '/dev/other')

    def test_canbus_discovery_aggregates_interfaces_and_splits_selection(self):
        klipper_home = os.path.join(self.tmpdir.name, 'klipper')
        python_path = os.path.join(self.tmpdir.name, 'klippy-env', 'bin', 'python')
        mock_bin = os.path.join(self.tmpdir.name, 'bin')
        os.makedirs(os.path.dirname(python_path))
        os.makedirs(mock_bin)
        os.makedirs(os.path.join(klipper_home, 'scripts'))
        ip_path = os.path.join(mock_bin, 'ip')
        with open(ip_path, 'w') as f:
            f.write('''#!/bin/sh
echo "2: can0: <NOARP,UP> mtu 16 qdisc pfifo_fast state UNKNOWN mode DEFAULT group default"
echo "3: vlan-1: <NOARP,UP> mtu 16 qdisc pfifo_fast state UNKNOWN mode DEFAULT group default"
echo "4: can1: <NOARP,UP> mtu 16 qdisc pfifo_fast state UNKNOWN mode DEFAULT group default"
''')
        os.chmod(ip_path, 0o755)
        with open(python_path, 'w') as f:
            f.write('''#!/bin/sh
case "$2" in
  can0) echo "Found canbus_uuid=aaa111aaa111" ;;
  vlan-1) echo "Found canbus_uuid=bbb222bbb222" ;;
  can1) echo "Found canbus_uuid=ccc333ccc333" ;;
esac
''')
        os.chmod(python_path, 0o755)

        syms = dict(profiles.get('boxturtle').syms)
        syms['CHOICE_MMU_CONNECTION_TYPE_SERIAL'] = False
        syms['CHOICE_MMU_CONNECTION_TYPE_CANBUS'] = True
        with cfg._env({'KLIPPER_HOME': klipper_home,
                       'PATH': mock_bin + os.pathsep + os.environ['PATH']}):
            kc = cfg._kconfig('multi-interface-canbus-discovery', syms)

        choice = kc.named_choices['CHOICE_MMU_CANBUS_CONNECTION']
        prompts = [node.prompt[0] for symbol in choice.syms
                   for node in symbol.nodes if node.prompt]
        self.assertIn('can0:aaa111aaa111', prompts)
        self.assertIn('vlan-1:bbb222bbb222', prompts)
        self.assertIn('can1:ccc333ccc333', prompts)

        kc.syms['CHOICE_MMU_CANBUS_UUID_VLAN_1_BBB222BBB222'].set_value(2)
        self.assertEqual(kc.syms['PARAM_MMU_CANBUS_UUID'].str_value,
                         'bbb222bbb222')
        self.assertEqual(kc.syms['PARAM_MMU_CANBUS_INTERFACE'].str_value,
                         'vlan-1')

    def test_canbus_discovery_uses_real_klipper_home_override(self):
        install_home = os.path.join(self.tmpdir.name, 'test-install', 'klipper')
        real_home = os.path.join(self.tmpdir.name, 'real', 'klipper')
        python_path = os.path.join(self.tmpdir.name, 'real', 'klippy-env',
                                   'bin', 'python')
        mock_bin = os.path.join(self.tmpdir.name, 'bin')
        os.makedirs(install_home)
        os.makedirs(os.path.dirname(python_path))
        os.makedirs(os.path.join(real_home, 'scripts'))
        os.makedirs(mock_bin)

        query_path = os.path.join(real_home, 'scripts', 'canbus_query.py')
        with open(query_path, 'w') as f:
            f.write('# mock canbus query\n')
        ip_path = os.path.join(mock_bin, 'ip')
        with open(ip_path, 'w') as f:
            f.write('#!/bin/sh\necho "2: can0: <NOARP,UP> mtu 16"\n')
        os.chmod(ip_path, 0o755)
        with open(python_path, 'w') as f:
            f.write('#!/bin/sh\n'
                    'echo "Found canbus_uuid=abc123abc123"\n')
        os.chmod(python_path, 0o755)

        syms = dict(profiles.get('boxturtle').syms)
        syms['CHOICE_MMU_CONNECTION_TYPE_SERIAL'] = False
        syms['CHOICE_MMU_CONNECTION_TYPE_CANBUS'] = True
        with cfg._env({'KLIPPER_HOME': install_home,
                       'REAL_KLIPPER_HOME': real_home,
                       'PATH': mock_bin + os.pathsep + os.environ['PATH']}):
            kc = cfg._kconfig('real-klipper-home-canbus-discovery', syms)

        choice = kc.named_choices['CHOICE_MMU_CANBUS_CONNECTION']
        prompts = [node.prompt[0] for symbol in choice.syms
                   for node in symbol.nodes if node.prompt]
        self.assertIn('can0:abc123abc123', prompts)

    def test_failed_canbus_queries_produce_no_discovered_choices(self):
        klipper_home = os.path.join(self.tmpdir.name, 'klipper')
        python_path = os.path.join(self.tmpdir.name, 'klippy-env', 'bin', 'python')
        mock_bin = os.path.join(self.tmpdir.name, 'bin')
        os.makedirs(os.path.dirname(python_path))
        os.makedirs(mock_bin)
        os.makedirs(os.path.join(klipper_home, 'scripts'))

        ip_path = os.path.join(mock_bin, 'ip')
        with open(ip_path, 'w') as f:
            f.write('#!/bin/sh\necho "2: vlan1: <NOARP,UP> mtu 16"\n')
        os.chmod(ip_path, 0o755)
        with open(python_path, 'w') as f:
            f.write('#!/bin/sh\necho "CAN query failed" >&2\nexit 1\n')
        os.chmod(python_path, 0o755)

        syms = dict(profiles.get('boxturtle').syms)
        syms['CHOICE_MMU_CONNECTION_TYPE_SERIAL'] = False
        syms['CHOICE_MMU_CONNECTION_TYPE_CANBUS'] = True
        with cfg._env({'KLIPPER_HOME': klipper_home,
                       'PATH': mock_bin + os.pathsep + os.environ['PATH']}):
            kc = cfg._kconfig('failed-canbus-query', syms)

        choice = kc.named_choices['CHOICE_MMU_CANBUS_CONNECTION']
        discovered = [node.prompt[0] for symbol in choice.syms
                      for node in symbol.nodes
                      if node.prompt and ':' in node.prompt[0]
                      and not node.prompt[0].startswith('Previous selection:')]
        self.assertEqual(discovered, [])
        self.assertEqual(choice.selection.name,
                         'CHOICE_MMU_CANBUS_UUID_OTHER')

    def test_all_real_connection_choices_expose_their_previous_values(self):
        values = {
            'PARAM_MMU_SERIAL_DEVICE': '/dev/previous-main',
            'PARAM_MMU_CANBUS_UUID': 'abc123def456',
            'PARAM_BUFFER_SERIAL_DEVICE': '/dev/previous-buffer',
            'PARAM_BUFFER_CANBUS_UUID': 'def456abc123',
            'PARAM_BUFFER_CANBUS_INTERFACE': 'can2',
        }
        for gate in range(5):
            values['PARAM_MMU_SERIAL_DEVICE_%d' % gate] = \
                '/dev/previous-gate-%d' % gate
            values['PARAM_MMU_CANBUS_UUID_%d' % gate] = \
                'abc123def4%02d' % gate
            values['PARAM_MMU_CANBUS_INTERFACE_%d' % gate] = \
                'can%d' % (gate % 3)
        with open(self.config_path, 'w') as f:
            for name, value in values.items():
                f.write('CONFIG_%s="%s" #~DEFAULT~#\n' % (name, value))

        env = {
            'KCONFIG_CONFIG': self.config_path,
            'F_PER_GATE_MCU': 'y',
            'UNIT_NAME': 'unit0',
            'MCU_NAME': 'unit0',
            'UNIT_INDEX': '0',
            'F_MULTI_UNIT': '',
            'F_MULTI_UNIT_ENTRY_POINT': '',
        }
        emu_syms = dict(profiles.get('emu').syms)
        emu_syms['CHOICE_MMU_CONNECTION_TYPE_SERIAL'] = True
        # Select the saved entries explicitly.  Board Kconfigs can prefer a currently
        # discovered MCU, and letting /dev/serial/by-id leak into this fixture makes the
        # result depend on whether the test happens to run on a live printer.
        for gate in range(5):
            emu_syms['CHOICE_MMU_SERIAL_DEVICE_PREVIOUS_%d' % gate] = True
        with cfg._env(env):
            kc = cfg._kconfig('previous-connection-selections', emu_syms)

        for gate in range(5):
            choice = kc.named_choices['CHOICE_MMU_SERIAL_CONNECTION_%d' % gate]
            self.assertEqual(choice.selection.name,
                             'CHOICE_MMU_SERIAL_DEVICE_PREVIOUS_%d' % gate)
            name = 'PARAM_MMU_SERIAL_DEVICE_%d' % gate
            self.assertEqual(kc.syms[name].str_value, values[name])
            canbus = kc.syms['CHOICE_MMU_CANBUS_UUID_PREVIOUS_%d' % gate]
            self.assertEqual(canbus.nodes[0].prompt[0],
                             'Previous selection: %s:%s' % (
                                 values['PARAM_MMU_CANBUS_INTERFACE_%d' % gate],
                                 values['PARAM_MMU_CANBUS_UUID_%d' % gate]))

        emu_canbus_syms = dict(profiles.get('emu').syms)
        emu_canbus_syms['CHOICE_MMU_CONNECTION_TYPE_SERIAL'] = False
        emu_canbus_syms['CHOICE_MMU_CONNECTION_TYPE_CANBUS'] = True
        with cfg._env(env):
            kc = cfg._kconfig('previous-canbus-gate-selections',
                              emu_canbus_syms)
        for gate in range(5):
            choice = kc.named_choices['CHOICE_MMU_CANBUS_CONNECTION_%d' % gate]
            self.assertEqual(choice.selection.name,
                             'CHOICE_MMU_CANBUS_UUID_PREVIOUS_%d' % gate)
            interface = 'PARAM_MMU_CANBUS_INTERFACE_%d' % gate
            self.assertEqual(kc.syms[interface].str_value, values[interface])

        vvd = profiles.get('ercf_vvd').units[1]
        buffer_env = {
            'KCONFIG_CONFIG': self.config_path,
            'F_PER_GATE_MCU': '',
            'UNIT_NAME': vvd.name,
            'MCU_NAME': vvd.mcu_name,
            'UNIT_INDEX': str(vvd.index),
            'F_MULTI_UNIT': 'y',
            'F_MULTI_UNIT_ENTRY_POINT': '',
        }
        buffer_syms = dict(vvd.syms)
        buffer_syms['CHOICE_BUFFER_CONNECTION_TYPE_SERIAL'] = True
        buffer_syms['CHOICE_BUFFER_SERIAL_DEVICE_PREVIOUS'] = True
        with cfg._env(buffer_env):
            kc = cfg._kconfig('previous-buffer-selection', buffer_syms)

        buffer_choice = kc.named_choices['CHOICE_BUFFER_SERIAL_CONNECTION']
        self.assertEqual(buffer_choice.selection.name,
                         'CHOICE_BUFFER_SERIAL_DEVICE_PREVIOUS')
        self.assertEqual(kc.syms['PARAM_BUFFER_SERIAL_DEVICE'].str_value,
                         values['PARAM_BUFFER_SERIAL_DEVICE'])
        buffer_canbus = kc.syms['CHOICE_BUFFER_CANBUS_UUID_PREVIOUS']
        self.assertEqual(buffer_canbus.nodes[0].prompt[0],
                         'Previous selection: %s:%s' % (
                             values['PARAM_BUFFER_CANBUS_INTERFACE'],
                             values['PARAM_BUFFER_CANBUS_UUID']))

        buffer_canbus_syms = dict(vvd.syms)
        buffer_canbus_syms['CHOICE_BUFFER_CONNECTION_TYPE_SERIAL'] = False
        buffer_canbus_syms['CHOICE_BUFFER_CONNECTION_TYPE_CANBUS'] = True
        with cfg._env(buffer_env):
            kc = cfg._kconfig('previous-buffer-canbus-selection',
                              buffer_canbus_syms)
        self.assertEqual(kc.syms['PARAM_BUFFER_CANBUS_INTERFACE'].str_value,
                         values['PARAM_BUFFER_CANBUS_INTERFACE'])

        base_env = dict(buffer_env)
        base_env.update({
            'UNIT_NAME': 'unit0',
            'MCU_NAME': 'unit0',
            'UNIT_INDEX': '0',
            'F_MULTI_UNIT': '',
        })
        base_syms = dict(profiles.get('boxturtle').syms)
        base_syms['CHOICE_MMU_CONNECTION_TYPE_CANBUS'] = True
        base_syms['CHOICE_MMU_CANBUS_UUID_PREVIOUS'] = True
        with cfg._env(base_env):
            kc = cfg._kconfig('previous-base-canbus-selection', base_syms)

        base_choice = kc.named_choices['CHOICE_MMU_CANBUS_CONNECTION']
        self.assertEqual(base_choice.selection.name,
                         'CHOICE_MMU_CANBUS_UUID_PREVIOUS')
        self.assertEqual(kc.syms['PARAM_MMU_CANBUS_UUID'].str_value,
                         values['PARAM_MMU_CANBUS_UUID'])
        self.assertEqual(kc.syms['PARAM_MMU_CANBUS_INTERFACE'].str_value,
                         'can0')
        self.assertEqual(base_choice.selection.nodes[0].prompt[0],
                         'Previous selection: can0:%s' %
                         values['PARAM_MMU_CANBUS_UUID'])
        base_serial = kc.syms['CHOICE_MMU_SERIAL_DEVICE_PREVIOUS']
        self.assertEqual(base_serial.nodes[0].prompt[0],
                         'Previous selection: %s' %
                         values['PARAM_MMU_SERIAL_DEVICE'])


# ---------------------------------------------------------------------------
# LED chain-name resolution - a render-level guard, because it must also cover
# machine types the harness does not boot.
#
# QuattroBox is a real shipped machine but is not wired up here (no board/gate-homing/
# NFC pin definitions), so it dies on empty pins at boot long before the LED load -
# the render path is the only place its generated config can be checked. These are
# inline fixtures rather than PROFILES-registry entries for that reason (see the note
# above TWO_UNIT).
# ---------------------------------------------------------------------------


def _quattro_box(version):
    """A QuattroBox profile for one version (version in {'1_0', '1_1', '2_0'})."""
    return profiles.Profile('quattro_box_%s' % version, syms={
        'MMU_FAMILY_QUATTRO_BOX': True,
        'MMU_TYPE_QUATTRO_BOX_%s' % version: True,
    })


def _vivid():
    # VVD otherwise only appears as the second unit of ercf_vvd; a single-unit render
    # fixture is the cleanest way to assert its chain names directly.
    return profiles.Profile('vivid', syms={
        'MMU_TYPE_VVD_1_0': True, 'BOARD_TYPE_VVD_1_0': True,
    })


class TestLedChainReferencesResolve(unittest.TestCase):
    """
    Every neopixel chain a [mmu_leds <unit>] segment references must be declared by a
    [neopixel ...] section (or be the user's cabinet chain, present in the printer stub).
    mmu_leds.py:42 loads each chain with printer.load_object() and raises "MMU LED chain
    ... cannot be loaded" for a name with no section - a config that renders fine but dies
    at klippy:ready, which only a boot would otherwise catch.

    The regression this guards: QuattroBox's LED defaults referenced neopixel:$(UNIT_NAME)
    _leds while mmu_hardware.cfg emits [neopixel _[[UNIT_NAME]]_leds] (leading underscore),
    so a stock QuattroBox loaded a phantom 1-LED chain and never started. ViViD is the
    deliberate contrast: it sets CUSTOM_LED_SETUP and declares its own underscore-less
    [neopixel <unit>_leds_1/2] on its custom board, so its underscore-less references are
    CORRECT and must keep resolving - the tests below pin that down so a well-intentioned
    "match the _<unit> convention" edit cannot silently break it.
    """

    SEGMENTS = ('exit_leds', 'entry_leds', 'status_leds', 'logo_leds')

    def _assembled(self, profile):
        return cfg.assemble(cfg.render(profile), printer_stub=bootstrap.PRINTER_STUB)

    def _unresolved(self, profile):
        """(section, segment, chain) for every referenced chain with no [neopixel] section."""
        parser = self._assembled(profile)
        declared = {s.split(' ', 1)[1] for s in parser.sections()
                    if s.startswith('neopixel ')}
        bad = []
        for sec in parser.sections():
            if not sec.startswith('mmu_leds '):
                continue
            items = dict(parser.items(sec))
            for seg in self.SEGMENTS:
                for part in items.get(seg, '').split(';'):
                    part = part.strip()
                    if part.startswith('neopixel:'):
                        chain = part.split()[0][len('neopixel:'):]
                        if chain not in declared:
                            bad.append('%s.%s -> %s' % (sec, seg, chain))
        return bad

    def test_quattro_box_segments_reference_the_generated_chain(self):
        """
        Fail-before/pass-after for the QuattroBox fix. The template emits
        [neopixel _unit0_leds] and QuattroBox is neither per-gate nor custom, so every
        segment must reference exactly that name - not the underscore-less unit0_leds the
        pre-fix defaults used.
        """
        for version in ('1_0', '1_1', '2_0'):
            profile = _quattro_box(version)
            parser = self._assembled(profile)
            self.assertIn('neopixel _unit0_leds', parser.sections(),
                          'quattro_box_%s must get the generated chain' % version)
            items_by_sec = {s: dict(parser.items(s))
                            for s in parser.sections() if s.startswith('mmu_leds ')}
            for sec, items in items_by_sec.items():
                for seg in self.SEGMENTS:
                    for part in items.get(seg, '').split(';'):
                        part = part.strip()
                        if not part:
                            continue
                        self.assertTrue(
                            part.startswith('neopixel:_unit0_leds'),
                            '%s %s = %r (expected neopixel:_unit0_leds ...)' % (version, seg, part))

    def test_every_led_chain_reference_resolves(self):
        """
        The invariant across every machine type that references a neopixel chain: the
        QuattroBox fix, ViViD's underscore-less-but-declared chains, the standard _<unit>
        machines, and the multi-unit ercf_vvd (whose unit0 also references the printer's
        cabinet_leds) must all have every referenced chain declared.
        """
        profiles_to_check = (
            ('quattro_box_1_0', _quattro_box('1_0')),
            ('quattro_box_1_1', _quattro_box('1_1')),
            ('quattro_box_2_0', _quattro_box('2_0')),
            ('vivid', _vivid()),
            ('boxturtle', profiles.get('boxturtle')),
            ('emu', profiles.get('emu')),
            ('ercf_vvd', profiles.get('ercf_vvd')),
        )
        for name, profile in profiles_to_check:
            with self.subTest(profile=name):
                self.assertEqual(
                    self._unresolved(profile), [],
                    '%s references a neopixel chain with no [neopixel] section: %s'
                    % (name, self._unresolved(profile)))

    def test_check_actually_catches_a_mismatch(self):
        """
        Guard against the resolver going vacuous: force the pre-fix underscore-less value
        back in on QuattroBox and _unresolved must flag all three segments. Without this,
        a silent bug in _unresolved would let test_every_led_chain_reference_resolves pass
        for the wrong reason.
        """
        profile = profiles.Profile('quattro_box_prefix', syms={
            'MMU_FAMILY_QUATTRO_BOX': True, 'MMU_TYPE_QUATTRO_BOX_1_0': True,
            'PARAM_EXIT_LEDS': 'neopixel:unit0_leds (1-4)',
            'PARAM_STATUS_LEDS': 'neopixel:unit0_leds (5-14)',
            'PARAM_LOGO_LEDS': 'neopixel:unit0_leds (15-32)',
        })
        self.assertEqual(len(self._unresolved(profile)), 3)


if __name__ == '__main__':
    unittest.main()
