# Happy Hare MMU Software
#
# Copyright (C) 2022-2026  moggieuk#6538 (discord)
#                          moggieuk@hotmail.com
#
# Implements MMU_TEST_LOAD command
#
#
# (\_/)
# ( *,*)
# (")_(") Happy Hare Ready
#
# This file may be distributed under the terms of the GNU GPLv3 license.
#

# Happy Hare imports
from ..mmu_constants   import *
from ..mmu_utils       import MmuError
from .mmu_base_command import *


class MmuTestLoadCommand(BaseCommand):
    """
    For quick testing filament loading from gate to the extruder
    """

    CMD = "MMU_TEST_LOAD"

    HELP_BRIEF = "For quick testing filament loading from gate to the extruder"
    HELP_PARAMS = (
        f"{CMD}: {HELP_BRIEF}\n"
        + "FULL   = [0|1]\n"
        + "LENGTH = #(float) Bowden move length (when FULL=0)\n"
    )
    HELP_SUPPLEMENT = (
        "Examples:\n"
        + f"{CMD}           ...Test load a short default distance from the gate\n"
        + f"{CMD} LENGTH=50 ...Test load 50mm of bowden movement from the gate\n"
        + f"{CMD} FULL=1    ...Test a full load from gate to the extruder\n"
    )

    def __init__(self, mmu):
        super().__init__(mmu)
        self.register(
            name=self.CMD,
            handler=self._run,
            help_brief=self.HELP_BRIEF,
            help_params=self.HELP_PARAMS,
            help_supplement=self.HELP_SUPPLEMENT,
            category=CATEGORY_TESTING
        )

    def _run(self, gcmd):
        # BaseCommand wrapper already logs commandline + handles HELP=1.
        mmu = self.mmu

        if self.check_if_disabled(): return
        if self.check_if_bypass(): return
        if self.check_if_loaded(): return
        if self.check_if_not_calibrated(CALIBRATED_ESSENTIAL, check_gates=[mmu.gate_selected]): return

        full = gcmd.get_int('FULL', 0, minval=0, maxval=1)

        try:
            with mmu.wrap_sync_gear_to_extruder():
                if full:
                    mmu.load_sequence(skip_extruder=True)
                else:
                    length = gcmd.get_float(
                        'LENGTH',
                        100.,
                        minval=10.,
                        maxval=mmu.mmu_unit().calibrator.get_bowden_length()
                    )
                    mmu.load_sequence(bowden_move=length, skip_extruder=True)

        except MmuError as ee:
            mmu.handle_mmu_error("Load test failed: %s" % str(ee))
