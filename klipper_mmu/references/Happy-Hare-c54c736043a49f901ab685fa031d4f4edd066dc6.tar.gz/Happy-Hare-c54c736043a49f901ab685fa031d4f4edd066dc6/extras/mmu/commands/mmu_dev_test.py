# Happy Hare MMU Software
#
# Copyright (C) 2022-2026  moggieuk#6538 (discord)
#                          moggieuk@hotmail.com
#
# Goal: Define internal test operations to aid development. Note these tests are "raw"
#
# (\_/)
# ( *,*)
# (")_(") Happy Hare Ready
#
# This file may be distributed under the terms of the GNU GPLv3 license.
#
import random, logging, math, ast

# Happy Hare imports
from ...mmu_stepper     import MmuGenericRail
from ..mmu_constants    import *
from ..mmu_utils        import MmuError, PurgeVolCalculator, DebugStepperMovement
from ..mmu_sensor_utils import MmuSensorFactory
from .mmu_base_command  import *


class SyncStateTest(object):
    '''
    This class describes what a sync_state test case is and offers methods to manipulate them.
    '''
    def __init__(self, compression_sensor, tension_sensor, compression_state, tension_state, toggle_compression, toggle_tension, triggered_sensor, id):
        self.compression_sensor = compression_sensor.runout_helper.sensor_enabled
        self.tension_sensor = tension_sensor.runout_helper.sensor_enabled
        self.compression_state = compression_state
        self.tension_state = tension_state
        self.toggle_compression = toggle_compression
        self.toggle_tension = toggle_tension
        self.expected = None
        self.triggered_sensor = triggered_sensor
        self.id = id
        self.set_expected()

    def set_expected(self):
        '''
        Return the expected float state with given inputs and current sensor states.
        '''
        if self.compression_sensor and self.tension_sensor:
            if self.compression_state == self.tension_state:
                self.expected = 0.
            elif self.compression_state and not self.tension_state:
                self.expected = 1.
            elif not self.compression_state and self.tension_state:
                self.expected = -1.
        elif self.compression_sensor:
            if self.compression_state:
                self.expected = 1.
            else:
                self.expected = -1.
        elif self.tension_sensor:
            if self.tension_state:
                self.expected = -1.
            else:
                self.expected = 1.
        else:
            self.expected = 0.

    def __str__(self):
        return "compression_sensor=%s, tension_sensor=%s, compression_state=%s, tension_state=%s, toggle_compression=%s, toggle_tension=%s, triggered_sensor=%s" % (
            self.compression_sensor, self.tension_sensor, self.compression_state, self.tension_state, self.toggle_compression, self.toggle_tension, self.triggered_sensor
        )

    def __repr__(self):
        return self.__str__()


class MmuTestCommand(BaseCommand):
    """
    Internal Happy Hare developer tests.

    Commands provided by this module:
      _MMU_TEST
    """

    CMD = "_MMU_TEST"

    HELP_BRIEF = "Internal Happy Hare developer tests"
    HELP_PARAMS = (
        f"{CMD}: {HELP_BRIEF}\n"
        + "HELP=1 Show this help\n"
        + "SYNC_STATE=['compression'|'tension'|'both'|'neutral'] Set the sync state ('loop' is disabled - it busy-waits and wedges the reactor)\n"
        + "SYNC_EVENT=[-1.0 ... 1.0] Generate sync feedback event\n"
        + "SEND_PRINTING_EVENT=[0|1] Send mmu:printing or mmu:not_printing event\n"
        + "ACTIVATE_FLOWGUARD=[0|1] Call the flowguard activation/deactivation hooks\n"
        + "WRAP_CURRENT=1 Test current wrapping and restore. Params; MOTOR=gear|extruder PERCENT=%\n"
        + "DUMP_UNICODE=1 Display special characters used in display\n"
        + "RUN_SEQUENCE=1 Run through the set of sequence macros tracking time. Params: ERROR=[0|1] FORCE_IN_PRINT=[0|1]\n"
        + "RUN_CHANGE_SEQUENCE=1 Run toolchange-style sequence. Params: PAUSE=[0|1] NEXT_POS=['last'|'next'] FORCE_IN_PRINT=[0|1]\n"
        + "GET_POS=1 Fetch the current filament position state\n"
        + "SET_POS={pos_state} Set the current filament position state\n"
        + "SET_RD={gear_rd} [GATE=] Update the specified gate's rotation distance\n"
        + "GET_POSITION=1 Fetch the current filament position\n"
        + "SET_POSITION={pos} Set the current filament position\n"
        + "GET_EXT_POSITION=1 Fetch the current extruder position\n"
        + "SET_ACTION={action} Set the current action state\n"
        + "SYNC_LOAD_TEST=1 Hammer stepper syncing and movement. Params: LOOP={n} ENDSTOP={name} SELECT=[0|1] WAIT=[0|1]\n"
        + "REALISTIC_SYNC_TEST=1 Load test normal stepper syncing and movement. Params: LOOP={n} ENDSTOP={name} SELECT=[0|1] SERVO=[0|1]\n"
        + "QUIESCE_TEST=1 Quick test of problematic sync changes\n"
        + "SEL_MOVE=1 Selector move. Params: MOVE={mm} SPEED={mm/s} ACCEL={mm/s^2} WAIT=[0|1] LOOP={n}\n"
        + "SEL_HOMING_MOVE=1 Selector homing move. Params: MOVE={mm} SPEED={mm/s} ACCEL={mm/s^2} LOOP={n} ENDSTOP={name}\n"
        + "SEL_LOAD_TEST=1 Load test selector movements. Params: LOOP={n} HOME=[0|1]\n"
        + "TTC_TEST=1 / TTC_TEST2=1 / TTC_TEST3=1 Provoke known TTC conditions. Params: LOOP={n} MIX=[0|1] DEBUG=[0|1] WAIT=[0|1]\n"
        + "STEPCOMPRESS_TEST=1 Provoke stepcompress error. Params: LOOP={n} MIX=[0|1] DEBUG=[0|1] WAIT=[0|1] SELECT=[0|1] MOTOR={name} STOP_ON_ENDSTOP=[-1|0|1]\n"
        + "NOTE_LOAD_TELEMETRY=1 Feed load telemetry to autotune. Params: GATE={n} LENGTH={mm} TRAVEL={mm} RATIO={f}\n"
        + "NOTE_UNLOAD_TELEMETRY=1 Feed unload telemetry to autotune. Params: GATE={n} LENGTH={mm} TRAVEL={mm} RATIO={f}\n"
        + "SYNC=[0|1|2|3|gear|gear+extruder|extruder|synced]\n"
        + "CALC_PURGE=1 Purge volume calculator quick tests\n"
        + "RUNOUT=[0|1] Enable/disable runout handling\n"
        + "SENSOR=1 Dump sensor path checks. Params: POS={n} GATE={n} LOADING=[0|1] LOOP=[0|1]\n"
        + "FILAMENT_POS={n} Set filament_pos state within sync wrapper\n"
        + "FILAMENT_DIR=[-1|0|1] Set filament_direction to unload|still|load\n"
        + "ADJUST_ENCODER={delta} Adjust the encoder distance reading by delta\n"
        + "SET_ENCODER={dist} Set the encoder distance reading to distance\n"
        + "DUMP_MCU_ENDSTOPS=1 Dump steppers registered on each MCU_endstop\n"
        + "DUMP_ACTIVE_SENSORS=1 Dump raw active sensors map\n"
        + "UPDATE_STATUS={dict} Force override (update) of mmu get_status() with supplied dict. 'OFF' to remove\n"
        + "NFC_READ=1 Simulate an NFC tag read. Params: UID={hex} DEEP=[0|1] GATE={n}(per-gate, else shared) UNIT={n} MATERIAL= BRAND= COLOR= DETAIL= MIN_TEMP= MAX_TEMP=\n"
        + "NFC_FIELD=1 Classify a tag UID against the gate map (no reader, no motion). Params: GATE={n} UID={hex}\n"
    )
    HELP_SUPPLEMENT = (
        ""
    )

    def __init__(self, mmu):
        super().__init__(mmu)
        self.register(
            name=self.CMD,
            handler=self._run,
            help_brief=self.HELP_BRIEF,
            help_params=self.HELP_PARAMS,
            help_supplement=self.HELP_SUPPLEMENT,
            category=CATEGORY_INTERNAL,
        )

    def _run(self, gcmd):
        mmu = self.mmu
        mmu_unit = mmu.mmu_unit()
        mmu_machine = mmu.mmu_machine

        if self.check_if_disabled():
            return

        def log(msg):
            mmu.log_info(msg)
            logging.info("MMU: %s" % msg)

        try:
            mmu._is_running_test = True
            have_run_test = False

            wrap_current = gcmd.get('WRAP_CURRENT', None)
            if wrap_current is not None:
                have_run_test = True
                motor = gcmd.get('MOTOR', "gear")
                percent = gcmd.get_int('PERCENT', 50)
                if motor == "extruder":
                    with mmu.wrap_extruder_current(percent=percent, reason="Development Test"):
                        mmu.log_always("LAYER1")
                        with mmu.wrap_extruder_current(percent=percent/2, reason="Development Test"):
                            mmu.log_always("LAYER2")
                else:
                    with mmu.wrap_gear_current(percent=percent, reason="Development Test"):
                        mmu.log_always("LAYER1")
                        with mmu.wrap_gear_current(percent=percent/2, reason="Development Test"):
                            mmu.log_always("LAYER2")

            sync_state = gcmd.get('SYNC_STATE', None)
            if sync_state is not None:
                have_run_test = True

                # REFUSE 'loop' rather than hang. wait_run() and wait_for_results() below are
                # `while <cond>: pass` busy-waits sitting inside a gcode handler, so they block
                # the single reactor greenlet - and the mmu:sync_feedback_finished events they
                # are waiting on are delivered by MmuSyncFeedback's settle TIMERS, which can
                # then never fire. It wedges the reactor, on a printer as much as in the test
                # harness. This used to be unreachable only because the setup below died first
                # on a stale lookup_object('mmu_sensors'); fixing that made it reachable, so
                # fail fast until the choreography is rewritten to yield.
                if sync_state == 'loop':
                    raise gcmd.error(
                        "SYNC_STATE=loop is not usable: its result-gathering is a busy-wait "
                        "that blocks the reactor, so the events it waits for never arrive. "
                        "Use SYNC_STATE=compression|tension|both|neutral instead."
                    )

                # The sync feedback sensors belong to the unit's BUFFER, not to MmuSensors
                # (unit/mmu_buffer.py:60-82), and both the object and its config section are
                # per-unit. Everything here used to go through a global "mmu_sensors" object
                # that no longer exists.
                mmu_unit = mmu.mmu_unit()
                buffer = getattr(mmu_unit, 'buffer', None)
                if buffer is None:
                    raise gcmd.error("Unit '%s' has no mmu_buffer, so there are no sync "
                                     "feedback sensors to drive" % mmu_unit.name)
                config = mmu.config.getsection('mmu_buffer %s' % buffer.name)
                factory = MmuSensorFactory(mmu.printer)
                sensors_to_remove = {}
                compression_sensor_filament_present = tension_sensor_filament_present = False

                # Create phony sensors for testing purposes (removed again after the test)
                def create_test_sensor(sensor_name, button_handler):
                    return factory.create_mmu_sensor(
                        config, sensor_name, None, 'test_' + sensor_name + '_pin',
                        event_delay=0, button_handler=button_handler
                    )

                def remove_test_sensors():
                    """
                    Unregister anything create_test_sensor() made.

                    Runs on EVERY exit path, not just the 'loop' one. It used to live inside
                    the loop branch, so a second plain SYNC_STATE call died with "mux command
                    QUERY_FILAMENT_SENSOR SENSOR filament_compression already registered".

                    Keyed off each sensor's OWN name - MmuSensor registers as
                    "filament_switch_sensor <name>" (mmu_sensor_utils.py:379) - rather than a
                    reconstructed "<x>_sensor", which stopped matching when that suffix was
                    dropped.
                    """
                    ppins = mmu.printer.lookup_object('pins')
                    for sensor, sensor_obj in sensors_to_remove.items():
                        object_name = "filament_switch_sensor %s" % sensor_obj.name
                        mmu.printer.objects.pop(object_name, None)
                        config.fileconfig.pop(object_name, None)

                        pin_params = ppins.parse_pin('test_' + sensor + '_pin')
                        ppins.active_pins.pop(
                            "%s:%s" % (pin_params['chip_name'], pin_params['pin']), None)

                        for cmd, (__, val) in mmu.gcode.mux_commands.items():
                            if sensor_obj.name in [k for k in [v for v in val.keys() if v]]:
                                mmu.gcode.mux_commands[cmd][1].pop(sensor_obj.name)
                    sensors_to_remove.clear()

                # Use the temporary sensors for the test if the real ones are not present or disabled
                compression_test_sensor = buffer.compression_sensor
                if compression_test_sensor is None or not compression_test_sensor.runout_helper.sensor_enabled:
                    compression_test_sensor = create_test_sensor(
                        SENSOR_COMPRESSION, buffer.sync_compression_callback)
                    sensors_to_remove[SENSOR_COMPRESSION] = compression_test_sensor

                tension_test_sensor = buffer.tension_sensor
                if tension_test_sensor is None or not tension_test_sensor.runout_helper.sensor_enabled:
                    tension_test_sensor = create_test_sensor(
                        SENSOR_TENSION, buffer.sync_tension_callback)
                    sensors_to_remove[SENSOR_TENSION] = tension_test_sensor

                if sync_state == 'loop':
                    nb_iterations = gcmd.get_int('LOOP', 1000, minval=1, maxval=10000000)
                    gathered_states = []
                    tests = []
                    global finished
                    finished = False
                    # save the sensor state
                    saved_compr = compression_test_sensor.runout_helper.sensor_enabled
                    saved_tens = tension_test_sensor.runout_helper.sensor_enabled

                    def gather_state(state):
                        mmu.log_trace(" -- Gathered state: %s" % len(gathered_states))
                        gathered_states.append(state)

                    def wait_for_results():
                        while len(gathered_states) < len(tests):
                            pass
                        mmu.log_trace(" -- All states were gathered : %s" % len(gathered_states))
                        display_results()
                        global finished
                        finished = True

                    def wait_run():
                        global finished
                        while not finished:
                            pass
                        finished = False

                    def display_results():
                        nb_tests_by_expected = {}
                        # For each configuration print the number of times it was run
                        mmu.log_debug("Configuration repartition")
                        nb_hits = {}
                        for comp in [None, True, False]:
                            for tens in [None, True, False]:
                                for t in tests:
                                    if (comp, tens) not in nb_hits:
                                        nb_hits.update({(comp, tens): 0})
                                    if (t.compression_state, t.tension_state) == (comp, tens):
                                        nb_hits[(comp, tens)] += 1
                        # Print the hits from most to least frequent
                        for key, value in sorted(nb_hits.items(), key=lambda item: item[1], reverse=True):
                            if value:
                                mmu.log_debug("   compression : %s - tension : %s -> %s" % (key[0], key[1], value))

                        # Group by expected result and print how many tests should result in that state
                        mmu.log_debug("Expected state repartition")
                        for expected in [1., 0., -1.]:
                            count = len([1 for t in tests if t.expected == expected])
                            mmu.log_debug("   Expected state %s -> %s" % (expected, count))
                            nb_tests_by_expected.update({expected: count})

                        mismatches = {}
                        for i, test in enumerate(tests):
                            if str(test) not in mismatches:
                                mismatches[str(test)] = {'test': test, 'count': 0}
                            if test.expected != gathered_states[i]:
                                mmu.log_debug(
                                    "MISMATCH on test id:%s (expected : %s) -> %s" %
                                    (str(test.id), test.expected, gathered_states[i])
                                )
                                mmu.log_debug("   Test : %s" % (str(test)))
                                mismatches[str(test)]['count'] += 1

                        # Display mismatches
                        nb_mismatches = sum([v['count'] for v in mismatches.values()])
                        mmu.log_info(
                            "Total Mismatches: " + str(nb_mismatches) + '/' + str(len(tests)) +
                            ' (' + str(round(nb_mismatches / len(tests) * 100, 2)) + ' %)'
                        )

                        if mismatches:
                            # Sort by most mismatches (highest first)
                            mismatches = dict(sorted(mismatches.items(), key=lambda item: item[1]['count'], reverse=True))
                            for test_str, info in mismatches.items():
                                if info['count']:
                                    mmu.log_debug(
                                        "MISMATCH: %s (expected : %s) -> %s" %
                                        (test_str, info['test'].expected, info['count'])
                                    )

                            # Summary: which expected state has which percentage of total errors
                            for expected in [1, 0, -1]:
                                if nb_tests_by_expected[expected]:
                                    nb_err_count = sum([
                                        info['count'] for __, info in mismatches.items()
                                        if info['test'].expected == expected
                                    ])
                                    mmu.log_debug(
                                        ">>>>>> Expected state " + str(expected) + " -> " +
                                        str(nb_err_count) + '/' + str(nb_tests_by_expected[expected]) +
                                        ' (' + str(round(nb_err_count / nb_tests_by_expected[expected] * 100, 2)) + ' %)'
                                    )
                                    mmu.log_debug("   Edge detection error repartition")
                                    # compression rising edge
                                    count = sum([
                                        info['count'] for __, info in mismatches.items()
                                        if info['test'].expected == expected and info['test'].toggle_compression == 'rising edge'
                                    ])
                                    if count:
                                        mmu.log_debug(
                                            "      " + str(count) + '/' + str(nb_err_count) + ' (' +
                                            str(round(((count / nb_err_count) if nb_err_count else 0) * 100, 2)) +
                                            ' %) ' + 'compression rising edge'
                                        )
                                    # compression falling edge
                                    count = sum([
                                        info['count'] for __, info in mismatches.items()
                                        if info['test'].expected == expected and info['test'].toggle_compression == 'falling edge'
                                    ])
                                    if count:
                                        mmu.log_debug(
                                            "      " + str(count) + '/' + str(nb_err_count) + ' (' +
                                            str(round(((count / nb_err_count) if nb_err_count else 0) * 100, 2)) +
                                            ' %) ' + 'compression falling edge'
                                        )
                                    # tension rising edge
                                    count = sum([
                                        info['count'] for __, info in mismatches.items()
                                        if info['test'].expected == expected and info['test'].toggle_tension == 'rising edge'
                                    ])
                                    if count:
                                        mmu.log_debug(
                                            "      " + str(count) + '/' + str(nb_err_count) + ' (' +
                                            str(round(((count / nb_err_count) if nb_err_count else 0) * 100, 2)) +
                                            ' %) ' + 'tension rising edge'
                                        )
                                    # tension falling edge
                                    count = sum([
                                        info['count'] for __, info in mismatches.items()
                                        if info['test'].expected == expected and info['test'].toggle_tension == 'falling edge'
                                    ])
                                    if count:
                                        mmu.log_debug(
                                            "      " + str(count) + '/' + str(nb_err_count) + ' (' +
                                            str(round(((count / nb_err_count) if nb_err_count else 0) * 100, 2)) +
                                            ' %) ' + 'tension falling edge'
                                        )
                        else:
                            mmu.log_info("No mismatches")

                    mmu.printer.register_event_handler("mmu:sync_feedback_finished", gather_state)
                    mmu.printer.register_event_handler("mmu:test_gen_finished", wait_for_results)

                    # randomly remove tension or compression sensor
                    for sensor_scenario in ['compression_only', 'tension_only', 'both', 'none']:
                        if sensor_scenario == 'compression_only':
                            compression_test_sensor.runout_helper.sensor_enabled = True
                            tension_test_sensor.runout_helper.sensor_enabled = False
                        elif sensor_scenario == 'tension_only':
                            compression_test_sensor.runout_helper.sensor_enabled = False
                            tension_test_sensor.runout_helper.sensor_enabled = True
                        elif sensor_scenario == 'both':
                            compression_test_sensor.runout_helper.sensor_enabled = True
                            tension_test_sensor.runout_helper.sensor_enabled = True
                        else:
                            compression_test_sensor.runout_helper.sensor_enabled = False
                            tension_test_sensor.runout_helper.sensor_enabled = False

                        mmu.log_info(">>>>>> Testing sensor configuration '%s'" % sensor_scenario)

                        while len(tests) < nb_iterations:
                            compression_sensor_filament_present = compression_test_sensor.runout_helper.filament_present
                            tension_sensor_filament_present = tension_test_sensor.runout_helper.filament_present
                            toggle_compression = "no change"
                            toggle_tension = "no change"

                            # generate a random sync state (only one sensor changes at a time)
                            if random.choice([True, False]):
                                compression_sensor_filament_present = random.choice([True, False])
                                if compression_sensor_filament_present != compression_test_sensor.runout_helper.filament_present:
                                    compression_test_sensor.runout_helper.note_filament_present(compression_sensor_filament_present)
                                    triggered_sensor = "compression"
                                    toggle_compression = "rising edge" if compression_sensor_filament_present else "falling edge"
                                    mmu.log_trace(" -- Generated test: %s" % len(tests))
                                    tests.append(SyncStateTest(
                                        compression_test_sensor, tension_test_sensor,
                                        compression_sensor_filament_present, tension_sensor_filament_present,
                                        toggle_compression, toggle_tension, triggered_sensor, len(tests)
                                    ))
                            else:
                                tension_sensor_filament_present = random.choice([True, False])
                                if tension_sensor_filament_present != tension_test_sensor.runout_helper.filament_present:
                                    tension_test_sensor.runout_helper.note_filament_present(tension_sensor_filament_present)
                                    triggered_sensor = "tension"
                                    toggle_tension = "rising edge" if tension_sensor_filament_present else "falling edge"
                                    mmu.log_trace(" -- Generated test: %s" % len(tests))
                                    tests.append(SyncStateTest(
                                        compression_test_sensor, tension_test_sensor,
                                        compression_sensor_filament_present, tension_sensor_filament_present,
                                        toggle_compression, toggle_tension, triggered_sensor, len(tests)
                                    ))

                        mmu.log_trace(" -- All %d were generated" % len(tests))
                        mmu.printer.send_event("mmu:test_gen_finished")
                        wait_run()
                        gathered_states = []
                        tests = []

                    # restore the original sensor state
                    compression_test_sensor.runout_helper.sensor_enabled = saved_compr
                    tension_test_sensor.runout_helper.sensor_enabled = saved_tens
                    mmu.log_info("See mmu.log for a more details")

                else:
                    if sync_state == 'compression':
                        if compression_test_sensor is not None:
                            mmu.log_info("Setting compression sensor to 'detected'")
                            compression_sensor_filament_present = True
                        if tension_test_sensor is not None:
                            mmu.log_info("Setting tension sensor to 'not detected'")
                            tension_sensor_filament_present = False
                    elif sync_state == 'tension':
                        if compression_test_sensor is not None:
                            mmu.log_info("Setting compression sensor to 'not detected'")
                            compression_sensor_filament_present = False
                        if tension_test_sensor is not None:
                            mmu.log_info("Setting tension sensor to 'detected'")
                            tension_sensor_filament_present = True
                    elif sync_state in ['both', 'neutral']:
                        if compression_test_sensor is not None:
                            mmu.log_info("Setting compression sensor to 'detected'")
                            compression_sensor_filament_present = True
                        if tension_test_sensor is not None:
                            mmu.log_info("Setting tension sensor to 'detected'")
                            tension_sensor_filament_present = True
                    else:
                        mmu.log_error("Invalid sync state: %s" % sync_state)

                    # Generate a tension or compression event
                    mmu.log_trace(">>>>>> sync test Testing configuration %s" % (sync_state.upper()))
                    if compression_test_sensor is not None:
                        compression_test_sensor.runout_helper.note_filament_present(compression_sensor_filament_present)
                    if tension_test_sensor is not None:
                        tension_test_sensor.runout_helper.note_filament_present(tension_sensor_filament_present)

                # Remove event handlers and any phony sensors, on both branches
                mmu.printer.event_handlers.pop("mmu:sync_feedback_finished", None)
                mmu.printer.event_handlers.pop("mmu:test_gen_finished", None)
                remove_test_sensors()
                return

            feedback = gcmd.get_float('SYNC_EVENT', None, minval=-1., maxval=1.)
            if feedback is not None:
                have_run_test = True
                mmu.log_info("Sending 'mmu:sync_feedback %.2f' event" % feedback)
                # Reactor time, like the real sensors - not print_time
                mmu.printer.send_event("mmu:sync_feedback", mmu.reactor.monotonic(), feedback)

            printing_event = gcmd.get_int('SEND_PRINTING_EVENT', None, minval=0, maxval=1)
            if printing_event is not None:
                have_run_test = True
                event_str = "mmu:printing" if printing_event else "mmu:not_printing"
                mmu.log_info(f"Sending '{event_str}' event")
                mmu.printer.send_event(event_str, mmu.toolhead.get_last_move_time())

            activate_flowguard = gcmd.get_int('ACTIVATE_FLOWGUARD', None, minval=0, maxval=1)
            if activate_flowguard is not None:
                have_run_test = True
                if activate_flowguard:
                    mmu_unit.sync_feedback.activate_flowguard(mmu.toolhead.get_last_move_time())
                else:
                    mmu_unit.sync_feedback.deactivate_flowguard(mmu.toolhead.get_last_move_time())

            if gcmd.get_int('DUMP_UNICODE', 0, minval=0, maxval=1):
                have_run_test = True
                mmu.log_info(
                    f"UI_SPACE={UI_SPACE}, UI_SEPARATOR={UI_SEPARATOR}, UI_DASH={UI_DASH}, "
                    f"UI_DEGREE={UI_DEGREE}, UI_BLOCK={UI_BLOCK}, UI_CASCADE={UI_CASCADE}"
                )
                mmu.log_info(f"UI_SQUARE={UI_SQUARE}, UI_CUBE={UI_CUBE}")
                mmu.log_info(
                    f"UI_SUPERSCRIPT_1={UI_SUPERSCRIPT_1}, "
                    f"UI_SUPERSCRIPT_2={UI_SUPERSCRIPT_2}, "
                    f"UI_SUPERSCRIPT_3={UI_SUPERSCRIPT_3}"
                )
                mmu.log_info(
                    f"UI_BULLET={UI_BULLET}, "
                    f"UI_SOLID_CIRCLE={UI_SOLID_CIRCLE}, "
                    f"UI_SOLID_SQUARE={UI_SOLID_SQUARE}, "
                    f"UI_SOLID_TRIANGLE={UI_SOLID_TRIANGLE}, "
                    f"UI_FISHEYE={UI_FISHEYE}"
                )

                mmu.log_info(f"{UI_BOX_TL}{UI_BOX_T}{UI_BOX_H}{UI_BOX_TR}")
                mmu.log_info(f"{UI_BOX_L}{UI_BOX_M}{UI_BOX_H}{UI_BOX_R}")
                mmu.log_info(f"{UI_BOX_V}{UI_BOX_V}{UI_SPACE}{UI_BOX_V}")
                mmu.log_info(f"{UI_BOX_BL}{UI_BOX_B}{UI_BOX_H}{UI_BOX_BR}")

                mmu.log_info(f"UI_EMOTICONS={UI_EMOTICONS}")

            if gcmd.get_int('RUN_SEQUENCE', 0, minval=0, maxval=1):
                have_run_test = True
                error = gcmd.get_int('ERROR', 0, minval=0, maxval=1)
                if gcmd.get_int('FORCE_IN_PRINT', 0, minval=0, maxval=1):
                    mmu.set_print_state("printing")
                with mmu._wrap_track_time('total'):
                    with mmu._wrap_track_time('unload'):
                        with mmu._wrap_track_time('pre_unload'):
                            mmu.wrap_gcode_command(mmu.p.pre_unload_macro, exception=False, wait=True)
                        mmu.wrap_gcode_command(mmu.p.post_form_tip_macro, exception=False, wait=True)
                        with mmu._wrap_track_time('post_unload'):
                            mmu.wrap_gcode_command(mmu.p.post_unload_macro, exception=False, wait=True)
                    with mmu._wrap_track_time('load'):
                        with mmu._wrap_track_time('pre_load'):
                            mmu.wrap_gcode_command(mmu.p.pre_load_macro, exception=False, wait=True)
                        with mmu._wrap_track_time('post_load'):
                            mmu.wrap_gcode_command(mmu.p.post_load_macro, exception=False, wait=False)
                            if error:
                                mmu.wrap_gcode_command("MMU_PAUSE")
                mmu.log_info("Statistics:%s" % mmu.last_statistics)
                mmu.set_print_state("idle")

            if gcmd.get_int('RUN_CHANGE_SEQUENCE', 0, minval=0, maxval=1):
                have_run_test = True
                pause = gcmd.get_int('PAUSE', 0, minval=0, maxval=1)
                next_pos = gcmd.get('NEXT_POS', "last")
                goto_pos = None
                if next_pos == 'next':
                    mmu.wrap_gcode_command(
                        "SET_GCODE_VARIABLE MACRO=_MMU_SEQUENCE_VARS VARIABLE=restore_xy_pos VALUE='\"%s\"'" % next_pos
                    )
                    goto_pos = [11, 11]
                    mmu._set_next_position(goto_pos)
                if gcmd.get_int('FORCE_IN_PRINT', 0, minval=0, maxval=1):
                    mmu.set_print_state("printing")
                mmu._save_toolhead_position_and_park('toolchange', next_pos=goto_pos)
                with mmu._wrap_track_time('total'):
                    try:
                        with mmu._wrap_track_time('unload'):
                            with mmu._wrap_track_time('pre_unload'):
                                mmu.wrap_gcode_command(mmu.p.pre_unload_macro, exception=False, wait=True)
                            mmu.wrap_gcode_command(mmu.p.post_form_tip_macro, exception=False, wait=True)
                            with mmu._wrap_track_time('post_unload'):
                                mmu.wrap_gcode_command(mmu.p.post_unload_macro, exception=False, wait=True)
                        with mmu._wrap_track_time('load'):
                            with mmu._wrap_track_time('pre_load'):
                                mmu.wrap_gcode_command(mmu.p.pre_load_macro, exception=False, wait=True)
                            if pause:
                                raise MmuError("TEST ERROR")
                            else:
                                with mmu._wrap_track_time('post_load'):
                                    mmu.wrap_gcode_command(mmu.p.post_load_macro, exception=False, wait=True)
                                mmu._restore_toolhead_position('toolchange')
                    except MmuError as ee:
                        mmu.handle_mmu_error(str(ee))
                mmu.log_info("Statistics:%s" % mmu.last_statistics)
                mmu.set_print_state("idle")

            sync = gcmd.get('SYNC', None)
            if sync is not None:
                have_run_test = True

                DRIVE_MODE_BY_NAME = {v.lower(): k for k, v in DRIVE_MODE_NAMES.items()}
                try:
                    mode = int(sync)
                except (TypeError, ValueError):
                    key = str(sync).lower()
                    mode = DRIVE_MODE_BY_NAME.get(key)
                    if mode is None:
                        valid = ", ".join(DRIVE_MODE_BY_NAME.keys())
                        raise gcmd.error(f"Invalid SYNC value: {sync}. Expected one of: {valid} or an integer.")

                mmu.drive().sync_mode(mode)

            pos = gcmd.get_int('SET_POS', -1, minval=0, maxval=10)
            if pos >= 0:
                have_run_test = True
                mmu.set_filament_pos_state(pos)

            gpos = gcmd.get_int('GET_POS', 0, minval=0, maxval=1)
            if gpos:
                have_run_test = True
                fil_pos_str = FILAMENT_POS_NAME_MAP.get(mmu.filament_pos, "INVALID")
                mmu.log_info("Filament pos state: %s (%s)" % (mmu.filament_pos, fil_pos_str))

            rd = gcmd.get_float('SET_RD', None, above=0)
            if rd is not None:
                have_run_test = True
                gate = gcmd.get_int('GATE', -1, minval=-2, maxval=mmu.num_gates)
                if gate >= 0:
                    # Calibration moved onto the per-unit calibrator; there is no longer a
                    # controller-level calibration_manager (unit/mmu_calibrator.py:375)
                    mmu.mmu_unit(gate).calibrator.update_gear_rd(rd, gate=gate, console_msg=True)

            position = gcmd.get_float('SET_POSITION', -1, minval=0)
            if position >= 0:
                have_run_test = True
                mmu.drive().set_filament_position(position)

            if gcmd.get_int('GET_POSITION', 0, minval=0, maxval=1):
                have_run_test = True
                mmu.log_info("Filament position: %s" % mmu.drive().get_filament_position())

            if gcmd.get_int('GET_EXT_POSITION', 0, minval=0, maxval=1):
                have_run_test = True
                mcu = mmu.printer.lookup_object('mcu')
                eventtime = mmu.reactor.monotonic()
                est_print_time = mcu.estimated_print_time(eventtime)
                pos = mmu.mmu_unit().extruder_stepper_obj().find_past_position(est_print_time)
                mmu.log_info("Extruder position: %s" % pos)

            action = gcmd.get_float('SET_ACTION', -1, minval=0)
            if action >= 0:
                have_run_test = True
                mmu.action = action

            if gcmd.get_int('QUIESCE_TEST', 0, minval=0, maxval=1):
                have_run_test = True
                mmu.log_warning(
                    "Setup:\n"
                    "toolhead sensor should be present or dummy ones created\n"
                    "Extruder should be hot (able to extrude)"
                )

                # Simple dispatcher so the sequence below stays clean and declarative
                def _exec(ops):
                    for i, (op, arg) in enumerate(ops, start=1):
                        if op == "g":
                            mmu.log_info("Step %d: %s" % (i, arg))
                            mmu.gcode.run_script_from_command(arg)
                        elif op == "sync":
                            mmu.log_info("Step %d: %s" % (i, arg))
                            mmu.drive().sync_mode(arg)
                        elif op == "unsync":
                            mmu.log_info("Step %d: unsync()" % i)
                            mmu.drive().sync_mode(DRIVE_UNSYNCED)
                        else:
                            mmu.log_warning("Step %d: unknown op %s" % (i, op))

                ops = [
                    ("unsync", None),
                    ("g", "G1 E-24 F6000"),
                    ("sync", DRIVE_GEAR_SYNCED_TO_EXTRUDER),
                    ("g", "G1 E8 F6000"),
                    ("unsync", None),
                    ("g", "G1 E2 F6000"),
                    ("g", "MMU_TEST_HOMING_MOVE MOTOR=gear MOVE=30 ENDSTOP=toolhead STOP_ON_ENDSTOP=1"),
                    ("g", "G1 E-24 F6000"),
                    ("sync", DRIVE_EXTRUDER_SYNCED_TO_GEAR),
                    ("g", "G1 E-2 F6000"),
                    ("g", "MMU_TEST_MOVE MOTOR=gear MOVE=30 WAIT=1"),
                    ("g", "MMU_TEST_HOMING_MOVE MOTOR=gear+extruder MOVE=30 ENDSTOP=toolhead STOP_ON_ENDSTOP=1"),
                    ("g", "MMU_TEST_MOVE MOTOR=gear+extruder MOVE=30"),
                    ("g", "G1 E8 F6000"),
                    ("unsync", None),
                    ("g", "G1 E-10 F6000"),
                    ("g", "G1 E8 F6000"),
                    ("g", "MMU_TEST_MOVE MOTOR=gear MOVE=30 WAIT=0"),
                    ("g", "G1 E-10 F6000"),
                    ("g", "G1 E8 F6000"),
                    ("g", "MMU_TEST_MOVE MOTOR=gear MOVE=30 WAIT=0"),
                    ("g", "G1 E-10 F6000"),
                    ("g", "G1 E8 F6000"),
                    ("g", "MMU_TEST_MOVE MOTOR=gear MOVE=30 WAIT=0"),
                    ("g", "MMU_TEST_MOVE MOTOR=gear MOVE=30 WAIT=0"),
                    ("g", "MMU_TEST_MOVE MOTOR=gear MOVE=30 WAIT=0"),
                    ("g", "MMU_TEST_MOVE MOTOR=gear MOVE=30 WAIT=0"),
                    ("g", "G1 E-10 F6000"),
                ]
                _exec(ops)

            # Test of all expected MMU and extruder movement (this must be bulletproof)
            # e.g. _MMU_TEST REALISTIC_SYNC_TEST=1 ENDSTOP=toolhead LOOP=100 SELECT=1 SERVO=1
            if gcmd.get_int('REALISTIC_SYNC_TEST', 0, minval=0, maxval=1):
                have_run_test = True
                mmu.log_warning(
                    "Setup:\n"
                    "toolhead sensor should be present or dummy ones created or use ENDSTOP=xxx\n"
                    "Extruder should be hot (able to extrude)\n"
                    "SELECT=1 turns on gate selection on type-B designs"
                )
                loop = gcmd.get_int('LOOP', 10, minval=1, maxval=1000)
                select = gcmd.get_int('SELECT', 0, minval=0, maxval=1)
                servo = gcmd.get_int('SERVO', 0, minval=0, maxval=1)
                endstop = gcmd.get('ENDSTOP', "toolhead")

                try:
                    if servo:
                        mmu._is_running_test = False  # Else servo won't move

                    for i in range(loop):
                        log("Loop: %d..." % i)

                        # Run a few randomized moves on the mmu toolhead to simulate load/unload logic (optional gate switch)
                        tracked = 0.
                        initial_pos = mmu.drive().get_filament_position()
                        for j in range(6):
                            move_type = random.randint(0, 10)  # 11 to enable tracking test
                            move = random.randint(0, 100) - 50
                            speed = random.uniform(50, 200)
                            accel = random.randint(50, 1000)
                            homing_move = random.randint(-1, 1)
                            motor = random.choice(["gear", "gear+extruder", "extruder"])
                            wait = random.randint(0, 1)
                            ed = random.randint(0, 4)
                            encoder_dwell = True if ed == 0 else None if ed == 1 else False

                            # Sometimes switch gate. This will test interleaved selector movement / gear rail reconfiguration
                            if select and random.randint(0, 3) == 0:
                                gate = random.randint(0, mmu.num_gates - 1)
                                log("Selecting gate: %d" % gate)
                                mmu.select_gate(gate)

                            # Sometimes inject servo movement for selectors with servo
                            if servo and random.randint(0, 4) == 0:
                                pos = "move" if random.randint(0, 1) else "down"
                                log("Moving servo to position: %s" % pos)
                                mmu.gcode.run_script_from_command("MMU_SERVO POS=%s" % pos)

                            log(
                                "> Internal mmu movement %d: move(%s, motor=%s, speed=%.2f, accel=%s, homing_move=%s, endstop_name=%s, encoder_dwell=%s, wait=%s)" %
                                (j, move, motor, speed, accel, homing_move, endstop, encoder_dwell, wait)
                            )
                            actual, _, _, _ = mmu.move_filament(
                                "REALISTIC_SYNC_TEST", move,
                                motor=motor, speed=speed, accel=accel,
                                homing_move=homing_move, endstop_name=endstop,
                                encoder_dwell=encoder_dwell, speed_override=False, wait=wait
                            )
                            tracked += actual

                        # Check MMU position is correct
                        final_pos = mmu.drive().get_filament_position()
                        expected = final_pos - initial_pos
                        if not math.isclose(expected, tracked):
                            raise MmuError(
                                "TEST ERROR: inital_pos=%.6f, final_pos=%.6f, tracked=%.6f (expected=%.6f)" %
                                (initial_pos, final_pos, tracked, expected)
                            )

                        # Run a few randomized moves on the printer toolhead to simulate user movement
                        # Sync state must either be unsynced or DRIVE_GEAR_SYNCED_TO_EXTRUDER.
                        # "Unsynced" is DRIVE_UNSYNCED, not None - sync_mode() rejects anything
                        # outside DRIVE_MODE_NAMES. This only failed intermittently because the
                        # validity check sits behind an `if mode == prev_mode: return` early
                        # out, so None got through whenever the previous mode was also None.
                        sync = DRIVE_UNSYNCED if random.randint(0, 1) else DRIVE_GEAR_SYNCED_TO_EXTRUDER
                        mmu.drive().sync_mode(sync)
                        log(">> Extruder movement (%s)..." % DRIVE_MODE_NAMES[sync])
                        for j in range(5):
                            move = random.randint(-10, 10)
                            mmu.gcode.run_script_from_command("G1 E%d F6000" % move)

                            # Simulate callback into _MMU_STEP_MOVE / _MMU_STEP_HOMING_MOVE
                            if random.randint(0, 4) == 0:
                                log(">>> Calling _MMU_STEP_** move")
                                if random.randint(0, 1):
                                    mmu.gcode.run_script_from_command("_MMU_STEP_MOVE MOVE=10")
                                else:
                                    mmu.gcode.run_script_from_command("_MMU_STEP_HOMING_MOVE MOVE=10 ENDSTOP=%s" % endstop)

                    log("TEST COMPLETE")

                except MmuError as ee:
                    log("TEST TERMINATED WITH MMU EXCEPTION: %s" % str(ee))

            if gcmd.get_int('SYNC_LOAD_TEST', 0, minval=0, maxval=1):
                have_run_test = True
                mmu.log_warning(
                    "Setup:\n"
                    "toolhead sensor should be present or dummy ones created or use ENDSTOP=xxx\n"
                    "Extruder should be hot (able to extrude)\n"
                    "SELECT=0 turns off gate selection on type-B designs\n"
                    "WAIT=[0|1] forces wait on movequeue condition after non-homing moves"
                )
                endstop = gcmd.get('ENDSTOP', 'toolhead')
                loop = gcmd.get_int('LOOP', 10, minval=1, maxval=1000)
                select = gcmd.get_int('SELECT', 1, minval=0, maxval=1)
                wait = gcmd.get_int('WAIT', None, minval=0, maxval=1)
                mmu.gcode.run_script_from_command("SAVE_GCODE_STATE NAME=mmu_test")
                mmu.initialize_filament_position()
                total = 0.

                for i in range(loop):
                    move_type = random.randint(0, 10)
                    move = random.randint(0, 100) - 50
                    speed = random.uniform(50, 200)
                    accel = random.randint(50, 1000)
                    motor = random.choice(["gear", "gear+extruder", "extruder"])
                    w = random.randint(0, 1) if wait is None else wait
                    if select and mmu_unit.multigear:
                        if random.randint(0, 1):
                            gate = random.randint(0, mmu.num_gates - 1)
                            log("Selecting gate: %d" % gate)
                            mmu.select_gate(gate)
                            total = 0.
                    if move_type in (0, 1):
                        log("Loop: %d - Synced extruder movement with G1 Ex: %.1fmm" % (i, move))
                        mmu.drive().sync_mode(DRIVE_GEAR_SYNCED_TO_EXTRUDER)
                        mmu.gcode.run_script_from_command("G1 E%.2f F%d" % (move, speed * 60))
                    elif move_type == 2:
                        log("Loop: %d - Unsynced extruder movement with G1 Ex: %.1fmm" % (i, move))
                        mmu.drive().sync_mode(DRIVE_UNSYNCED)
                        mmu.gcode.run_script_from_command("G1 E%.2f F%d" % (move, speed * 60))
                    elif move_type == 3:
                        log("Loop: %d - Regular mmu move: %.1fmm, MOTOR=%s" % (i, move, motor))
                        mmu.gcode.run_script_from_command("MMU_TEST_MOVE MOTOR=%s MOVE=%.2f SPEED=%d WAIT=%d" % (motor, move, speed, w))
                        total += move
                    elif move_type in (4, 5, 6):
                        log("Loop: %d - HOMING MOVE: %.1fmm, MOTOR=%s" % (i, move, motor))
                        mmu.gcode.run_script_from_command("MMU_TEST_HOMING_MOVE MOTOR=%s MOVE=%.2f SPEED=%d ENDSTOP=%s STOP_ON_ENDSTOP=1" % (motor, move, speed, endstop))
                        total += move
                    elif move_type == 7:
                        if random.randint(0, 1):
                            new_pos = random.uniform(0, 300)
                            log("Loop: %d - Set filament position" % i)
                            mmu.drive().set_filament_position(new_pos)
                            total = new_pos
                        else:
                            log("Loop: %d - Initialized filament position" % i)
                            mmu.initialize_filament_position()
                            total = 0.
                    elif move_type == 8:
                        log("Loop: %d - Save gcode state" % i)
                        mmu.gcode.run_script_from_command("SAVE_GCODE_STATE NAME=mmu_test")
                    elif move_type == 9:
                        log("Loop: %d - Restore gcode state" % i)
                        mmu.gcode.run_script_from_command("RESTORE_GCODE_STATE NAME=mmu_test")
                    elif move_type == 10:
                        log("Loop: %d - Synced extruder movement: %.1fmm" % (i, move))
                        mmu.gcode.run_script_from_command("MMU_TEST_MOVE MOTOR=synced MOVE=%.2f SPEED=%d WAIT=%d" % (move, speed, w))
                    else:
                        sync_mode = mmu.drive().get_status(0)['sync_mode']
                        sync = "---" if sync_mode == DRIVE_UNSYNCED else (
                            "E2G" if sync_mode == DRIVE_EXTRUDER_SYNCED_TO_GEAR else
                            "G2E" if sync_mode == DRIVE_GEAR_SYNCED_TO_EXTRUDER else "Ext"
                        )
                        mmu.movequeue_wait()
                        tracking = abs(mmu.drive().get_filament_position() - total) < 0.1
                        mmu.log_info(">>>>>> STATUS: sync: %s, pos=%.2f, total=%.2f" % (sync, mmu.drive().get_filament_position(), total))
                        if not tracking:
                            mmu.log_error(">>>>>> Position tracking error")
                            break

                # Dump status of current gear and extruder steppers
                mmu.gcode.run_script_from_command(f"MMU_STEPPER_STATUS STEPPER={mmu_unit.extruder_stepper_obj().get_name()}")
                mmu.gcode.run_script_from_command(f"MMU_STEPPER_STATUS STEPPER={mmu.drive().get_name()}")
                mmu.log_info("Aggregate move distance: %.1fmm, MmuDrive reports: %.1fmm" % (total, mmu.drive().get_filament_position()))
                mmu.drive().sync_mode(DRIVE_UNSYNCED)

            if gcmd.get_int('SEL_MOVE', 0, minval=0, maxval=1):
                have_run_test = True
                move = gcmd.get_float('MOVE', 10.)
                speed = gcmd.get_float('SPEED', None)
                accel = gcmd.get_float('ACCEL', None)
                wait = gcmd.get_int('WAIT', 1, minval=0, maxval=1)
                loop = gcmd.get_int('LOOP', 1, minval=1)
                for i in range(loop):
                    pos = mmu.selector().selector_stepper.commanded_pos
                    # move() returns (position, homed) - see LinearSelector._move_selector
                    actual, _ = mmu.selector().move("Test move", pos + move, speed=speed, accel=accel, wait=wait)
                    mmu.log_always("%d. Rail starting pos: %s, Selector moved to %.4fmm" % (i, pos, actual))
                    if actual != pos + move:
                        mmu.log_always("Off target position by: %.4f" % (actual - (pos + move)))

            if gcmd.get_int('SEL_HOMING_MOVE', 0, minval=0, maxval=1):
                have_run_test = True
                move = gcmd.get_float('MOVE', 10.)
                speed = gcmd.get_float('SPEED', None)
                accel = gcmd.get_float('ACCEL', None)
                loop = gcmd.get_int('LOOP', 1, minval=1)
                endstop = gcmd.get('ENDSTOP', SENSOR_SELECTOR_TOUCH if mmu.selector().use_touch_move() else SENSOR_SELECTOR_HOME)
                for i in range(loop):
                    pos = mmu.selector().selector_stepper.commanded_pos
                    mmu.log_always("Rail starting pos: %s" % pos)
                    actual, homed = mmu.selector().homing_move("Test homing move", pos + move, speed=speed, accel=accel, homing_move=1, endstop_name=endstop)
                    mmu.log_always("%d. Rail starting pos: %s, Selector moved to %.4fmm homing to %s (%s)" % (i, pos, actual, endstop, "homed" if homed else "DID NOT HOME"))
                    if actual != pos + move:
                        mmu.log_always("Off target position by: %.4f" % (actual - (pos + move)))

            if gcmd.get_int('SEL_LOAD_TEST', 0, minval=0, maxval=1):
                have_run_test = True
                loop = gcmd.get_int('LOOP', 10, minval=1, maxval=1000)
                if gcmd.get_int('HOME', 0, minval=0, maxval=1):
                    # MMU_HOME insists on a UNIT once more than one is configured
                    # (mmu_base_command.py:198), so always name the one we are driving
                    mmu.gcode.run_script_from_command(
                        "MMU_HOME UNIT=%d" % mmu.mmu_unit().unit_index)
                for i in range(loop):
                    move_type = random.randint(0, 2)
                    move = random.randint(10, 100)
                    speed = random.uniform(50, 200)
                    accel = random.randint(50, 2000)
                    w = random.randint(0, 1)
                    pos = mmu.selector().selector_stepper.commanded_pos
                    if move_type in (1, 2):
                        endstop = "mmu_sel_touch" if move_type == 2 else "mmu_sel_home"
                        actual, homed = mmu.selector().homing_move("Test homing move", move, speed=speed, accel=accel, homing_move=1, endstop_name=endstop)
                        mmu.log_always("%d. Homing move: Rail starting pos: %s, Selector moved to %.4fmm homing to %s (%s)" % (i, pos, actual, endstop, "homed" if homed else "DID NOT HOME"))
                    else:
                        actual, _ = mmu.selector().move("Test move", move, speed=speed, accel=accel, wait=w)
                        mmu.log_always("%d. Move: Rail starting pos: %s, Selector moved to %.4fmm" % (i, pos, actual))

            if gcmd.get_int('TTC_TEST', 0, minval=0, maxval=1):
                have_run_test = True
                loop = gcmd.get_int('LOOP', 10, minval=1, maxval=1000)
                debug = gcmd.get_int('DEBUG', 0, minval=0, maxval=1)
                mix = gcmd.get_int('MIX', 0, minval=0, maxval=1)
                wait = gcmd.get_int('WAIT', None, minval=0, maxval=1)
                for i in range(loop):
                    mmu.log_info("Loop: %d" % i)
                    w = random.randint(0, 1) if wait is None else wait
                    if mmu_unit.multigear:
                        mmu.select_gate(random.randint(0, mmu.num_gates - 1))
                    stop_on_endstop = random.choice([-1, 1])
                    motor = "gear+extruder" if random.randint(0, mix) else "extruder"
                    mmu.gcode.run_script_from_command(
                        "MMU_TEST_HOMING_MOVE MOTOR=%s MOVE=5 ENDSTOP=toolhead STOP_ON_ENDSTOP=%d DEBUG=%d" %
                        (motor, stop_on_endstop, debug)
                    )
                    if random.randint(0, 1):
                        mmu.gcode.run_script_from_command(
                            "MMU_TEST_MOVE MOTOR=%s MOVE=5 DEBUG=%d WAIT=%d" % (motor, debug, w)
                        )
                    if random.randint(0, 1):
                        mmu.toolhead.get_last_move_time()  # Try to provoke TTC

            if gcmd.get_int('TTC_TEST2', 0, minval=0, maxval=1):
                have_run_test = True
                loop = gcmd.get_int('LOOP', 10, minval=1, maxval=10000000)
                debug = gcmd.get_int('DEBUG', 0, minval=0, maxval=1)
                mix = gcmd.get_int('MIX', 0, minval=0, maxval=1)
                wait = gcmd.get_int('WAIT', None, minval=0, maxval=1)
                for i in range(loop):
                    stop_on_endstop = random.choice([-1, 0, 1])
                    w = random.randint(0, 1) if wait is None else wait
                    mmu.log_info("Loop: %d" % i)
                    motor = "gear+extruder" if random.randint(0, mix) else "extruder"
                    mmu.move_filament("test", 5, motor=motor, homing_move=stop_on_endstop, endstop_name="toolhead", wait=w)
                    if random.randint(0, 1):
                        mmu.gcode.run_script_from_command("M83")
                        mmu.gcode.run_script_from_command("G1 E5 F300")

            if gcmd.get_int('TTC_TEST3', 0, minval=0, maxval=1):
                have_run_test = True
                loop = gcmd.get_int('LOOP', 10, minval=1, maxval=1000)
                debug = gcmd.get_int('DEBUG', 0, minval=0, maxval=1)
                wait = gcmd.get_int('WAIT', None, minval=0, maxval=1)
                for i in range(loop):
                    mmu.log_info("Loop: %d" % i)
                    w = random.randint(0, 1) if wait is None else wait
                    if mmu_unit.multigear:
                        mmu.select_gate(random.randint(0, mmu.num_gates - 1))
                    stop_on_endstop = random.choice([-1, 1])
                    motor = "gear"
                    mmu.gcode.run_script_from_command(
                        "MMU_TEST_HOMING_MOVE MOTOR=%s MOVE=-70 SPEED=300 ACCEL=1000 ENDSTOP=toolhead STOP_ON_ENDSTOP=%d DEBUG=%d" %
                        (motor, stop_on_endstop, debug)
                    )
                    if random.randint(0, 1):
                        mmu.gcode.run_script_from_command(
                            "MMU_TEST_MOVE MOTOR=%s MOVE=5 DEBUG=%d WAIT=%d" % (motor, debug, w)
                        )
                    if random.randint(0, 1):
                        mmu.toolhead.get_last_move_time()  # Try to provoke TTC

            if gcmd.get_int('STEPCOMPRESS_TEST', 0, minval=0, maxval=1):
                have_run_test = True
                loop = gcmd.get_int('LOOP', 10, minval=10, maxval=1000)
                debug = gcmd.get_int('DEBUG', 0, minval=0, maxval=1)
                motor = gcmd.get('MOTOR', None)
                wait = gcmd.get_int('WAIT', None, minval=0, maxval=1)
                select = gcmd.get_int('SELECT', 1, minval=0, maxval=1)
                stop_on_endstop = gcmd.get_int('STOP_ON_ENDSTOP', None, minval=-1, maxval=1)
                for i in range(loop):
                    mmu.log_info("Loop: %d" % i)
                    w = random.randint(0, 1) if wait is None else wait
                    if mmu_unit.multigear and select:
                        mmu.select_gate(random.randint(0, mmu.num_gates - 1))
                    mmu.gcode.run_script_from_command("M83")
                    mmu.gcode.run_script_from_command("G1 E1 F300")
                    if motor is None:
                        motor = "gear+extruder" if random.randint(0, 1) else "extruder"
                    if stop_on_endstop is None:
                        stop_on_endstop = random.choice([-1, 0, 1])
                    if wait is None:
                        w = random.randint(0, 1)
                    with DebugStepperMovement(mmu, debug):
                        mmu.move_filament("test", 1, motor=motor, homing_move=stop_on_endstop, endstop_name="toolhead", wait=w)

            # Autotune, driven by hand. What used to be a single AUTO_CALIBRATE with a
            # DIRECTION parameter is now two calibrator methods, one per direction
            # (unit/mmu_calibrator.py:520-539). The real caller is
            # mmu_filament_movement.py:2155/2370 at the end of a full load/unload.
            for option, method in (('NOTE_LOAD_TELEMETRY', 'note_load_telemetry'),
                                   ('NOTE_UNLOAD_TELEMETRY', 'note_unload_telemetry')):
                if gcmd.get_int(option, 0, minval=0, maxval=1):
                    have_run_test = True
                    gate = gcmd.get_int('GATE', mmu.gate_selected, minval=0, maxval=mmu.num_gates - 1)
                    calibrator = mmu.mmu_unit(gate).calibrator
                    # LENGTH is what the machine currently believes; TRAVEL is what it would
                    # have measured. Autotune acts on the delta, so defaulting TRAVEL to
                    # LENGTH makes a bare call inert - name a TRAVEL to provoke a correction.
                    length = gcmd.get_float('LENGTH', calibrator.get_bowden_length(gate), minval=0)
                    travel = gcmd.get_float('TRAVEL', length, minval=0)
                    # None skips the encoder branch entirely, so it stays off unless asked for
                    ratio = gcmd.get_float('RATIO', None, minval=-1, maxval=2)
                    mmu.log_info("%s: gate %d, bowden length %.1fmm, travel %.1fmm, ratio %s"
                                 % (option, gate, length, travel, ratio))
                    getattr(calibrator, method)(gate, length, travel, ratio)

            if gcmd.get_int('CALC_PURGE', 0, minval=0, maxval=1):

                # Generate purge matrix based on filament colors (copied from mmu_calc_purge_volumes.py)
                def generate_purge_matrix(tool_colors, purge_min, purge_max, multiplier):
                    purge_vol_calc = PurgeVolCalculator(purge_min, purge_max, multiplier)

                    # Build purge volume map (x=to_tool, y=from_tool)
                    should_calc = lambda x,y: x < len(tool_colors) and y < len(tool_colors) and x != y
                    purge_volumes = [
                        [
                            purge_vol_calc.calc_purge_vol_by_hex(tool_colors[y], tool_colors[x]) if should_calc(x,y) else 0
                            for x in range(self.mmu.num_gates)
                        ]
                        for y in range(self.mmu.num_gates)
                    ]
                    return purge_volumes

                def format_purge_matrix(purge_volumes):
                    matrix_str = "\n".join(
                        f"|{UI_SPACE.join(f'{v:4d}' for v in row)} |"
                        for row in purge_volumes
                    )
                    return matrix_str


                have_run_test = True
                purge_vol_calc = PurgeVolCalculator(0, 800, 1.0)

                purge_vol = purge_vol_calc.calc_purge_vol_by_rgb(192, 192, 192, 247, 35, 35)
                mmu.log_always("The purge vol from RGB color 192, 192, 192 to 247, 35, 35 is: {}".format(purge_vol))

                purge_vol = purge_vol_calc.calc_purge_vol_by_hex("#C0C0C0", "#F72323")
                mmu.log_always("The purge vol from hex color #C0C0C0 to #F72323 is: {}".format(purge_vol))

                tool_colors = ["FFFF00", "80FFFF", "FFFFFF", "FF8000"]
                purge_volumes = generate_purge_matrix(tool_colors, 0, 800, 1.0)
                mmu.log_always("\ntool_colors={}\npurge_volumes={}".format(tool_colors, purge_volumes))
                matrix_str = format_purge_matrix(purge_volumes)
                mmu.log_always(f"\ntool_colors={tool_colors}\npurge_volumes=\n{matrix_str}")

                purge_volumes = generate_purge_matrix(tool_colors, 0, 800, 0.5)
                matrix_str = format_purge_matrix(purge_volumes)
                mmu.log_always(f"\ntool_colors={tool_colors}\npurge_volumes=\n{matrix_str}")

            runout = gcmd.get_int('RUNOUT', None, minval=0, maxval=1)
            if runout is not None:
                have_run_test = True
                # Runout arming lives on the sensor manager and is per-gate
                # (mmu_sensor_manager.py:490-496)
                gate = gcmd.get_int('GATE', mmu.gate_selected, minval=-2, maxval=mmu.num_gates)
                if runout == 1:
                    mmu.sensor_manager.enable_runout(gate)
                else:
                    mmu.sensor_manager.disable_runout(gate)

            if gcmd.get_int('SENSOR', 0, minval=0, maxval=1):
                have_run_test = True
                pos = gcmd.get_int('POS', 0, minval=-1)
                gate = gcmd.get_int('GATE', 0, minval=-2, maxval=8)
                loading = bool(gcmd.get_int('LOADING', 1, minval=0, maxval=1))
                loop = gcmd.get_int('LOOP', 0, minval=0, maxval=1)

                if not loop:
                    sensors = mmu.sensor_manager.get_sensors_before(pos, gate, loading=loading)
                    mmu.log_always("check_all_sensors_before(%s,%s)=%s" % (pos, gate, mmu.sensor_manager.check_all_sensors_before(pos, gate, loading=loading)))
                    mmu.log_always("sensors before=%s" % sensors)

                    sensors = mmu.sensor_manager.get_sensors_after(pos, gate, loading=loading)
                    mmu.log_always("check_all_sensors_after(%s,%s)=%s" % (pos, gate, mmu.sensor_manager.check_all_sensors_after(pos, gate, loading=loading)))
                    mmu.log_always("sensors after=%s" % sensors)
                else:
                    for pos_i in range(-1, 11):
                        mmu.log_always("check_all_sensors_before(%s,%s)=%s" % (pos_i, gate, mmu.sensor_manager.check_all_sensors_before(pos_i, gate, loading=loading)))
                    mmu.log_always("")
                    for pos_i in range(-1, 11):
                        mmu.log_always("check_all_sensors_after(%s,%s)=%s" % (pos_i, gate, mmu.sensor_manager.check_all_sensors_after(pos_i, gate, loading=loading)))

                mmu.log_always("check_any_sensors_in_path()=%s" % mmu.sensor_manager.check_any_sensors_in_path())
                mmu.log_always("check_for_runout()=%s" % mmu.sensor_manager.check_for_runout())


            fil_pos = gcmd.get_int('FILAMENT_POS', -2, minval=-1, maxval=10)
            if fil_pos != -2:
                have_run_test = True
                mmu._is_running_test = False  # Else servo won't move
                with mmu.wrap_sync_gear_to_extruder():
                    mmu.set_filament_pos_state(fil_pos)


            fil_dir = gcmd.get_int('FILAMENT_DIR', None, minval=-1, maxval=1)
            if fil_dir is not None:
                have_run_test = True
                mmu.set_filament_direction(fil_dir)


            adjust_encoder = gcmd.get_float('ADJUST_ENCODER', None)
            if adjust_encoder is not None:
                have_run_test = True
                mmu.log_always(f"Encoder distance before: {mmu.get_encoder_distance(dwell=None):.1f}mm")
                mmu.adjust_encoder_distance(adjust_encoder)
                mmu.log_always(f"Encoder distance after: {mmu.get_encoder_distance(dwell=None):.1f}mm")


            set_encoder = gcmd.get_float('SET_ENCODER', None)
            if set_encoder is not None:
                have_run_test = True
                mmu.set_encoder_distance(set_encoder)
                mmu.log_always(f"Encoder distance: {mmu.get_encoder_distance(dwell=None):.1f}mm")


            dump_mcus = gcmd.get_int('DUMP_MCU_ENDSTOPS', None)
            if dump_mcus is not None:
                have_run_test = True

                def get_mcu_endstops_sorted():
                    return sorted(
                        MmuGenericRail.mcu_endstop_tracking,
                        key=lambda es: (es.get_mcu().get_name(), es._pin)
                    )

                msg = ""
                for es, names in sorted(
                    MmuGenericRail.mcu_endstop_tracking.items(),
                    key=lambda item: (
                        item[0].get_mcu().get_name(),
                        item[0]._pin
                    )
                ):
                    for en in names:
                        s = f"{en}({es.get_mcu().get_name()},{es._pin},{id(es)})"
                        msg += (
                            f"{s:<55} Steppers: "
                            f"{', '.join(st.get_name(short=True).split()[-1] for st in es.get_steppers())}\n"
                        )

                mmu.log_always(msg)

            dump_sensors = gcmd.get_int('DUMP_ACTIVE_SENSORS', None)
            if dump_sensors is not None:
                have_run_test = True

                mmu.log_always(f"active_sensors={mmu.sensor_manager.get_status()}")

            # -----------

            update_status = gcmd.get('UPDATE_STATUS', None)
            if update_status is not None:
                have_run_test = True
                if update_status.upper().startswith("OFF"):
                    if hasattr(mmu, "developer_status_update"):
                        delattr(mmu, "developer_status_update")
                else:
                    try:
                        status = ast.literal_eval(update_status)
                        mmu.developer_status_update = status
                    except Exception as e:
                        mmu.log_error(f"Could not parse status string: {str(e)}")
                return

            nfc_read = gcmd.get_int('NFC_READ', None, minval=0, maxval=1)
            if nfc_read is not None:
                have_run_test = True
                # Simulate an NFC tag read with NO reader hardware attached. We inject at the
                # exact point the real reader hands off - the manager's _dispatch_lookup - so
                # every reader-level guard (has_gate_nfc_reader / is_enabled / is_active /
                # _reader_for / _read_reader / _want_metadata) is bypassed by construction.
                # The downstream *feature* gates (per-unit nfc_deep_read, spoolman_support)
                # are still honoured; we log when one will suppress part of the injection.
                uid = gcmd.get('UID', 'DEADBEEF').strip()
                deep = bool(gcmd.get_int('DEEP', 0, minval=0, maxval=1))
                gate = gcmd.get_int('GATE', -1, minval=-1, maxval=mmu.num_gates - 1)

                if gate >= 0: # Per-gate reader on this gate's unit
                    target_unit = mmu.mmu_unit(gate)
                    kind, tag_gate = "per-gate (gate %d)" % gate, gate
                else:         # Shared reader on the chosen (default: selected) unit
                    unit_index = gcmd.get_int('UNIT', mmu.unit_selected or 0, minval=0, maxval=mmu_machine.num_units - 1)
                    target_unit = mmu_machine.get_mmu_unit_by_index(unit_index)
                    kind, tag_gate = "shared (unit %d)" % unit_index, None

                metadata = None
                if deep: # Prepackaged tag metadata (override any field via params)
                    metadata = {
                        'material':        gcmd.get('MATERIAL', 'PLA'),
                        'brand':           gcmd.get('BRAND', 'TestVendor'),
                        'color_hex':       gcmd.get('COLOR', 'FF0000').lstrip('#'),
                        'material_detail': gcmd.get('DETAIL', 'PLA Basic'),
                        'min_temp':        gcmd.get_int('MIN_TEMP', 190),
                        'max_temp':        gcmd.get_int('MAX_TEMP', 220),
                    }
                    if not mmu.nfc_deep_read_enabled(target_unit):
                        log("NFC_READ: DEEP metadata supplied but nfc_deep_read is disabled on this unit "
                            "- metadata will NOT be applied and auto-create is off (the UID lookup still runs)")
                if mmu.p.spoolman_support == SPOOLMAN_OFF:
                    log("NFC_READ: spoolman_support is off - no UID->spool lookup dispatched "
                        "(only local deep-read metadata, if enabled, is applied)")

                log("NFC_READ: injecting %s tag UID=%s%s" % (kind, uid, " (deep)" if deep else ""))
                target_unit.nfc_manager._dispatch_lookup(uid, gate=tag_gate, metadata=metadata)
                return

            nfc_field = gcmd.get_int('NFC_FIELD', None, minval=0, maxval=1)
            if nfc_field is not None:
                have_run_test = True
                # Exercise MmuNfcFieldArbiter's "who is in my reader field?" ladder with NO
                # reader hardware and NO motion - _field_verdict is a pure function of
                # (gate, uid) against the gate map, so every rung is reachable just by
                # choosing a UID: one registered to GATE, one registered to a neighboring
                # gate, one registered to a gate on another unit, or one registered nowhere.
                gate = gcmd.get_int('GATE', max(0, mmu.gate_selected), minval=0, maxval=mmu.num_gates - 1)
                uid = gcmd.get('UID', '04A1B2C3D4E5').strip()

                arbiter = mmu.nfc_arbiter
                verdict, owner, diag = arbiter._field_verdict(gate, uid)
                log("NFC_FIELD: gate %d, uid %s -> %s (owner gate %s)"
                    % (gate, uid, NFC_FIELD_NAMES.get(verdict, verdict),
                       'none' if owner is None else owner))
                if diag:
                    log("NFC_FIELD: diagnostic: %s" % diag)

                # Arming and eligibility are config/machine-state, not part of the pure
                # ladder - reported separately so a caller can see both without any I/O.
                u = mmu.mmu_unit(gate)
                scan_armed = mmu._nfc_field_arm(
                    gate, clear_distance=u.p.nfc_gate_clear_distance) is not None
                preload_endstop = u.p.gate_preload_endstop or u.p.gate_homing_endstop
                preload_armed = mmu._nfc_field_arm(
                    gate, preload_endstop, u.p.nfc_preload_clear_distance) is not None
                log("NFC_FIELD: arbitration scan=%s, preload=%s (nfc_neighbor_check=%d, "
                    "nfc_neighbor_evict_distance=%.1f, nfc_gate_clear_distance=%.1f, "
                    "nfc_preload_clear_distance=%.1f, probe reads=%d)"
                    % ("ARMED" if scan_armed else "not armed",
                       "ARMED" if preload_armed else "not armed", u.p.nfc_neighbor_check,
                       u.p.nfc_neighbor_evict_distance, u.p.nfc_gate_clear_distance,
                       u.p.nfc_preload_clear_distance, u.p.nfc_field_probe_reads))

                # Show the identity information available to arbitration for this gate
                # and the two physical neighbors its RFIDS fallback can consult.
                gm = mmu.gate_maps
                for candidate in (gate - 1, gate, gate + 1):
                    if not u.owns_gate(candidate):
                        continue
                    log("NFC_FIELD: gate %d: spool_id=%d rfid=%s rfids=%s"
                        % (candidate, gm.gate_spool_id[candidate],
                           gm.gate_spool_rfid[candidate] or '(none)',
                           ','.join(gm.gate_spool_rfid_aliases[candidate]) or '(none)'))

                if verdict == NFC_FIELD_NEIGHBOR:
                    candidates = arbiter._neighbor_candidates(gate, owner)
                    log("NFC_FIELD: candidate order (identity first, then physical "
                        "neighbors): %s" % candidates)
                    for candidate in candidates:
                        reason = arbiter._evict_reject(gate, candidate)
                        log("NFC_FIELD: candidate gate %d is %s"
                            % (candidate, "evictable" if reason is None
                               else "NOT evictable: %s" % reason))
                    if owner is None:
                        log("NFC_FIELD: unregistered - with no motion budget this resolves "
                            "to MINE (optimistic default); with a motion budget it resolves "
                            "to PROVISIONAL and is only confirmed/rejected by the caller's "
                            "own natural motion (see clear_field)")
                    else:
                        log("NFC_FIELD: registered to a known neighbor - with no motion "
                            "budget, or if eviction fails, this resolves to FOREIGN "
                            "(fast-fail), never PROVISIONAL")
                return

            # -----------

            if not have_run_test:
                mmu.log_warning("Not a valid test. Use HELP=1 for tests")

        finally:
            mmu._is_running_test = False  # Restore non testing context
