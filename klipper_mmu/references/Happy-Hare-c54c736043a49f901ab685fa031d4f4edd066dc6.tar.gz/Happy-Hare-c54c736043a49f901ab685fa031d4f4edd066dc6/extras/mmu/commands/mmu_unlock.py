# Happy Hare MMU Software
#
# Copyright (C) 2022-2026  moggieuk#6538 (discord)
#                          moggieuk@hotmail.com
#
# Implements MMU_UNLOCK command
#
#
# (\_/)
# ( *,*)
# (")_(") Happy Hare Ready
#
# This file may be distributed under the terms of the GNU GPLv3 license.
#

# Happy Hare imports
from ..mmu_constants   import *
from ..mmu_utils       import MmuError
from .mmu_base_command import *


class MmuUnlockCommand(BaseCommand):

    CMD = "MMU_UNLOCK"

    HELP_BRIEF = "Wakeup the MMU prior to resume to restore temperatures and timeouts"
    HELP_PARAMS = (
        f"{CMD}: {HELP_BRIEF}\n"
        + "(no parameters)\n"
    )
    HELP_SUPPLEMENT = (
        "Examples:\n"
        + f"{CMD} ...Wake the MMU after an error/pause to restore heater temperatures and timeouts prior to resume\n"
    )

    def __init__(self, mmu):
        super().__init__(mmu)
        self.register(
            name=self.CMD,
            handler=self._run,
            help_brief=self.HELP_BRIEF,
            help_params=self.HELP_PARAMS,
            help_supplement=self.HELP_SUPPLEMENT,
            category=CATEGORY_GENERAL
        )

    def _run(self, gcmd):
        # Note: BaseCommand wrapper already logs commandline + handles HELP=1.
        mmu = self.mmu

        if self.check_if_disabled(): return

        mmu._clear_mmu_error_dialog()

        if mmu.is_mmu_paused_and_locked():
            mmu._mmu_unlock()
