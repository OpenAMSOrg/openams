# Happy Hare MMU Software
#
# Copyright (C) 2022-2026  moggieuk#6538 (discord)
#                          moggieuk@hotmail.com
#
# Implements MMU_LOG command
#
#
# (\_/)
# ( *,*)
# (")_(") Happy Hare Ready
#
# This file may be distributed under the terms of the GNU GPLv3 license.
#

# Happy Hare imports
from ..mmu_constants   import *
from ..mmu_utils       import MmuError
from .mmu_base_command import *


class MmuLogCommand(BaseCommand):

    CMD = "MMU_LOG"

    HELP_BRIEF = "Logs messages in MMU log"
    HELP_PARAMS = (
        f"{CMD}: {HELP_BRIEF}\n"
        + "MSG   = _text_\n"
        + "ERROR = [0|1]\n"
        + "DEBUG = [0|1]\n"
    )
    HELP_SUPPLEMENT = (
        "Examples:\n"
        + f'{CMD} MSG="Loading complete"         ...Write an informational message to console and mmu.log\n'
        + f'{CMD} MSG="Gate 3 is empty" ERROR=1  ...Write an error message\n'
        + f'{CMD} MSG="entering load sequence" DEBUG=1 ...Write a debug-level message (only shown when debugging enabled)\n'
    )

    def __init__(self, mmu):
        super().__init__(mmu)
        self.register(
            name=self.CMD,
            handler=self._run,
            help_brief=self.HELP_BRIEF,
            help_params=self.HELP_PARAMS,
            help_supplement=self.HELP_SUPPLEMENT,
            category=CATEGORY_GENERAL,
            log=False,
        )

    def _run(self, gcmd):
        # Note: BaseCommand wrapper already logs commandline + handles HELP=1.
        mmu = self.mmu

        msg = gcmd.get('MSG', "").replace("\\n", "\n").replace(" ", UI_SPACE)

        if gcmd.get_int('ERROR', 0, minval=0, maxval=1):
            mmu.log_error(msg)
        elif gcmd.get_int('DEBUG', 0, minval=0, maxval=1):
            mmu.log_debug(msg)
        else:
            mmu.log_info(msg)
