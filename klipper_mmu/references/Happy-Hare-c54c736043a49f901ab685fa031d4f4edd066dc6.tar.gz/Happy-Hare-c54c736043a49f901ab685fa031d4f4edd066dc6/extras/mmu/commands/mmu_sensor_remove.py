# Happy Hare MMU Software
#
# Copyright (C) 2022-2026  moggieuk#6538 (discord)
#                          moggieuk@hotmail.com
#
# Implements MMU_SENSOR_REMOVE command
#
#
# (\_/)
# ( *,*)
# (")_(") Happy Hare Ready
#
# This file may be distributed under the terms of the GNU GPLv3 license.
#

# Happy Hare imports
from ..mmu_constants   import *
from ..mmu_utils       import MmuError
from .mmu_base_command import *


class MmuSensorRemoveCommand(BaseCommand):
    """
    Callback to handle removal event from an MMU sensor (only mmu_entry for now).
    A removal event can happen both in and out of a print.

    Params:
        EVENTTIME will contain reactor time that the sensor triggered
                  and command was queued
        SENSOR    will contain sensor name
        GATE      will be set if specific mmu entry or mmu exit sensor
    """

    CMD = "__MMU_SENSOR_REMOVE"

    HELP_BRIEF = "Internal MMU filament removal handler"
    HELP_PARAMS = (
        f"{CMD}: {HELP_BRIEF}\n"
        + "EVENTTIME = #(float)\n"
        + "SENSOR    = _sensor_name_\n"
        + "GATE      = #(int)\n"
    )
    HELP_SUPPLEMENT = ""  # Internal callback command

    def __init__(self, mmu):
        super().__init__(mmu)
        self.register(
            name=self.CMD,
            handler=self._run,
            help_brief=self.HELP_BRIEF,
            help_params=self.HELP_PARAMS,
            help_supplement=self.HELP_SUPPLEMENT,
            category=CATEGORY_INTERNAL
        )

    def _run(self, gcmd):
        # BaseCommand wrapper already logs commandline + handles HELP=1.
        mmu = self.mmu

        if not mmu.is_enabled: return
        mmu.fix_started_state()

        eventtime = gcmd.get_float('EVENTTIME', mmu.reactor.monotonic())
        gate = gcmd.get_int('GATE', None)
        raw_sensor = gcmd.get('SENSOR', "")
        sensor = mmu.sensor_manager.get_unprefixed_sensor_name(raw_sensor)

        try:
            with mmu.wrap_sync_gear_to_extruder():

                # Removal callbacks are queued. Resolve the exact callback source
                # before dispatch so a bounced or now-unreadable sensor cannot mutate state.
                sensor_state = mmu.sensor_manager.check_event_sensor(raw_sensor, gate)
                if sensor_state is not False:
                    state = "still detects filament" if sensor_state is True else "cannot be read"
                    mmu.log_assertion(
                        "Remove handler suspects sensor malfunction on %s (%s). Ignored"
                        % (raw_sensor, state)
                    )
                    return

                if sensor.startswith(SENSOR_ENTRY_PREFIX) and gate is not None:
                    # A confirmed-clear entry sensor means this lane is empty regardless
                    # of print state. EndlessSpool's waste-eject path also resets the gate
                    # explicitly, so it needs no special exception here.
                    mmu.gate_maps.set_gate_status(gate, GATE_EMPTY)

                else:
                    mmu.log_assertion(
                        "Unexpected/unhandled sensor remove event on %s. Ignored"
                        % raw_sensor
                    )

        except MmuError as ee:
            mmu.handle_mmu_error(str(ee))
