# Happy Hare MMU Software
#
# Copyright (C) 2022-2026  moggieuk#6538 (discord)
#                          moggieuk@hotmail.com
#
# Implements MMU_UNLOAD command
#
#
# (\_/)
# ( *,*)
# (")_(") Happy Hare Ready
#
# This file may be distributed under the terms of the GNU GPLv3 license.
#

# Happy Hare imports
from ..mmu_constants     import *
from ..mmu_utils         import MmuError
from .mmu_base_command   import *
from .mmu_misc_mixins    import UnloadEjectMixin


class MmuUnloadCommand(UnloadEjectMixin, BaseCommand):

    CMD = "MMU_UNLOAD"

    HELP_BRIEF = "Unloads filament and parks it at the gate or optionally unloads just the extruder (EXTRUDER_ONLY=1)"
    HELP_PARAMS = (
        f"{CMD}: {HELP_BRIEF}\n"
        + "EXTRUDER_ONLY = [0|1] Act only on extruder (implied for bypass)\n"
        + "SKIP_TIP      = [0|1] Force skipping of tip forming / cutting\n"
        + "RESTORE       = [0|1] Set to 0 to disable restoring toolhead position after unload\n"
    )
    HELP_SUPPLEMENT = (
        "Examples:\n"
        + f"{CMD}            ...Unload filament from current gate\n"
        + f"{CMD} SKIP_TIP=1 ...Unload filament from current gate skipping purge macro\n"
    )

    def __init__(self, mmu):
        super().__init__(mmu)
        self.register(
            name=self.CMD,
            handler=self._run,
            help_brief=self.HELP_BRIEF,
            help_params=self.HELP_PARAMS,
            help_supplement=self.HELP_SUPPLEMENT,
            category=CATEGORY_GENERAL
        )

    def _run(self, gcmd):
        # Note: BaseCommand wrapper already logs commandline + handles HELP=1.
        mmu = self.mmu

        if self.check_if_disabled(): return
        if self.check_if_not_calibrated(CALIBRATED_ESSENTIAL, check_gates=[mmu.gate_selected]): return
        mmu.fix_started_state()

        if mmu.filament_pos == FILAMENT_POS_UNLOADED:
            mmu.log_always("Filament not loaded")
            return

        try:
            with mmu.wrap_sync_gear_to_extruder():
                with mmu.wrap_suspend_filament_monitoring(): # Don't want runout accidentally triggering during filament unload

                    self._handle_unload(gcmd)

        except MmuError as ee:
            mmu.handle_mmu_error("%s.\nOccurred when unloading tool" % str(ee))
