# Happy Hare MMU Software
#
# Copyright (C) 2022-2026  moggieuk#6538 (discord)
#                          moggieuk@hotmail.com
#
# Implements MMU_SPOOLMAN command
#
#
# (\_/)
# ( *,*)
# (")_(") Happy Hare Ready
#
# This file may be distributed under the terms of the GNU GPLv3 license.
#

# Happy Hare imports
from ..mmu_constants   import *
from ..mmu_utils       import MmuError
from .mmu_base_command import *


class MmuSpoolmanCommand(BaseCommand):
    """
    Manage spoolman gate/spool assignment and status. Tag/UID registration onto a
    spool record lives in MMU_SPOOLMAN_TAG instead.
    """

    CMD = "MMU_SPOOLMAN"

    HELP_BRIEF = "Manage spoolman status / gate-spool assignment"
    HELP_PARAMS = (
        f"{CMD}: {HELP_BRIEF}\n"
        + "QUIET     = [0|1] Suppress non-critical console output\n"
        + "SYNC      = 1 Sync the local and remote (spoolman) gate maps\n"
        + "CLEAR     = 1 Clear all gate/spool assignments for this printer in the spoolman db\n"
        + "REFRESH   = 1 Rebuild spoolman's cache of this printer's assignments, then sync (unless SYNC= is also given)\n"
        + "FIX       = 1 With REFRESH=, also unassign any inconsistent spool/gate pairs found (partial or duplicate assignments)\n"
        + "SPOOLID   = #(int) Spoolman spool id\n"
        + "GATE      = #(int) Gate number\n"
        + "PRINTER   = _name_ Show another printer's gate/spool assignments instead of this one\n"
        + "SPOOLINFO = [-1|spool_id] Display spoolman details for a spool (0 = the active spool)\n"
        + "(no parameters to show the current spoolman gate/spool assignments)\n"
    )
    HELP_SUPPLEMENT = (
        "Examples:\n"
        + f"{CMD}                   ...Show the current spoolman gate/spool assignments\n"
        + f"{CMD} REFRESH=1         ...Refresh the local gate map from the spoolman database\n"
        + f"{CMD} GATE=0 SPOOLID=45 ...Assign spoolman spool id 45 to gate 0\n"
        + f"{CMD} GATE=0            ...Unassign whichever spool is on gate 0\n"
        + f"{CMD} SPOOLID=45        ...Unassign spool id 45 from whichever gate it's on\n"
        + f"{CMD} SPOOLINFO=45      ...Display spoolman details for spool id 45\n"
        + f"{CMD} SPOOLINFO=-1      ...Display spoolman details for active spool\n"
        + "\nSee MMU_SPOOLMAN_TAG to register a tag/UID onto a spool record.\n"
    )

    def __init__(self, mmu):
        super().__init__(mmu)
        self.register(
            name=self.CMD,
            handler=self._run,
            help_brief=self.HELP_BRIEF,
            help_params=self.HELP_PARAMS,
            help_supplement=self.HELP_SUPPLEMENT,
            category=CATEGORY_GENERAL
        )

    def _run(self, gcmd):
        # BaseCommand wrapper already logs commandline + handles HELP=1.
        mmu = self.mmu

        if self.check_if_disabled(): return
        if self.check_if_spoolman_enabled(): return

        quiet = bool(gcmd.get_int('QUIET', 0, minval=0, maxval=1))
        sync = bool(gcmd.get_int('SYNC', 0, minval=0, maxval=1))
        clear = bool(gcmd.get_int('CLEAR', 0, minval=0, maxval=1))
        refresh = bool(gcmd.get_int('REFRESH', 0, minval=0, maxval=1))
        fix = bool(gcmd.get_int('FIX', 0, minval=0, maxval=1))
        spool_id = gcmd.get_int('SPOOLID', None, minval=1)
        gate = gcmd.get_int('GATE', None, minval=-1, maxval=mmu.num_gates - 1)
        printer = gcmd.get('PRINTER', None)  # Option to see other printers
        spoolinfo = gcmd.get_int('SPOOLINFO', None, minval=-1)  # -1 or 0 is active spool
        run = False

        if refresh:
            # Rebuild cache in moonraker and sync local and remote
            mmu._spoolman_refresh(fix, quiet=quiet)
            if not sync:
                mmu._spoolman_sync(quiet=quiet)
            run = True

        if clear:
            # Clear the gate allocation in spoolman db
            mmu._spoolman_clear_gate_map(
                sync=mmu.p.spoolman_support == SPOOLMAN_PULL,
                quiet=quiet
            )
            run = True

        if sync:
            # Sync local and remote gate maps
            mmu._spoolman_sync(quiet=quiet)
            run = True

        # Rest of the options are mutually exclusive
        if spoolinfo is not None:
            # Dump spool info for active spool or specified spool id
            mmu._spoolman_display_spool_info(
                spoolinfo if spoolinfo > 0 else None
            )

        elif spool_id is not None or gate is not None:
            # Update a record in spoolman db
            if spool_id is not None and gate is not None:
                mmu._spoolman_set_spool_gate(
                    spool_id,
                    gate,
                    sync=mmu.p.spoolman_support == SPOOLMAN_PULL,
                    quiet=quiet
                )
            elif spool_id is None and gate is not None:
                mmu._spoolman_unset_spool_gate(
                    gate=gate,
                    sync=mmu.p.spoolman_support == SPOOLMAN_PULL,
                    quiet=quiet
                )
            elif spool_id is not None and gate is None:
                mmu._spoolman_unset_spool_gate(
                    spool_id=spool_id,
                    sync=mmu.p.spoolman_support == SPOOLMAN_PULL,
                    quiet=quiet
                )

        elif not run:
            if mmu.p.spoolman_support in [SPOOLMAN_PULL, SPOOLMAN_PUSH]:
                # Display gate association table from spoolman db
                mmu._spoolman_display_spool_location(printer=printer)
            else:
                mmu.log_error(
                    "Spoolman gate map not available. Spoolman mode is: %s"
                    % mmu.p.spoolman_support
                )
