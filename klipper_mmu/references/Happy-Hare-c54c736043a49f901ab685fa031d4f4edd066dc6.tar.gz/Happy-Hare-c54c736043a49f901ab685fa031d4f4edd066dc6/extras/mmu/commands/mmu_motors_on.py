# Happy Hare MMU Software
#
# Copyright (C) 2022-2026  moggieuk#6538 (discord)
#                          moggieuk@hotmail.com
#
# Implements MMU_MOTORS_ON command
#
#
# (\_/)
# ( *,*)
# (")_(") Happy Hare Ready
#
# This file may be distributed under the terms of the GNU GPLv3 license.
#

# Happy Hare imports
from ..mmu_constants   import *
from ..mmu_utils       import MmuError
from .mmu_base_command import *


class MmuMotorsOnCommand(BaseCommand):
    """
    Turn on all MMU motors and servos.
    """

    CMD = "MMU_MOTORS_ON"

    HELP_BRIEF = "Turn on all MMU motors and servos"
    HELP_PARAMS = (
        f"{CMD}: {HELP_BRIEF}\n"
    )
    HELP_SUPPLEMENT = (
        "Examples:\n"
        + f"{CMD} ...Re-energize all MMU motors and servos\n"
    )

    def __init__(self, mmu):
        super().__init__(mmu)
        self.register(
            name=self.CMD,
            handler=self._run,
            help_brief=self.HELP_BRIEF,
            help_params=self.HELP_PARAMS,
            help_supplement=self.HELP_SUPPLEMENT,
            category=CATEGORY_GENERAL,
            per_unit=True
        )

    def _run(self, gcmd, mmu_unit):
        # BaseCommand wrapper already logs commandline + handles HELP=1.
        mmu = self.mmu

        if self.check_if_disabled():
            return

        mmu_unit.motors_onoff(on=True)
        # Re-establish sync state after powering up
        mmu.reset_sync_gear_to_extruder(force_grip=True)
