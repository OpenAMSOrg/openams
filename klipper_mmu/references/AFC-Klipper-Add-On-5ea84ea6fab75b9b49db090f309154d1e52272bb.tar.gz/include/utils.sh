#!/usr/bin/env bash
# Armored Turtle Automated Filament Changer
#
# Copyright (C) 2024-2026 Armored Turtle
#
# This file may be distributed under the terms of the GNU GPLv3 license.

pushd() {
  command pushd "$@" >/dev/null || exit
}

popd() {
  command popd >/dev/null || exit
}

function show_help() {
  echo "Usage: install-afc.sh [options]"
  echo ""
  echo "Options:"
  echo "  -a <moonraker address>      Specify the address of the Moonraker server (default: http://localhost)"
  echo "  -k <path>                   Specify the path to the Klipper directory"
  echo "  -m <moonraker config path>  Specify the path to the Moonraker config file (default: ~/printer_data/config/moonraker.conf)"
  echo "  -n <moonraker port>         Specify the port of the Moonraker server (default: 7125)"
  echo "  -s <klipper service name>   Specify the name of the Klipper service (default: klipper)"
  echo "  -p <printer config dir>     Specify the path to the printer config directory (default: ~/printer_data/config)"
  echo "  -b <branch>                 Specify the branch to use (default: main)"
  echo "  -y <klipper venv dir>       Specify the klipper python venv dir (default: ~/klippy-env/bin)"
  echo "  -h                          Display this help message"
  echo ""
  echo "Example:"
  echo " $0 [-a <moonraker address>] [-k <klipper_path>] [-s <klipper_service_name>] [-m <moonraker_config_path>] [-n <moonraker_port>] [-p <printer_config_dir>] [-p <printer_config_dir>] [-b <branch>] [-y <klipper venv dir>] [-h] "
}

safe_copy() {
  # Safe copy that prompts the user before overwriting existing files/directories.
  # Usage: safe_copy <source> <destination>
  # Drop-in replacement for cp / cp -R.
  # Returns: 0 on success (including skip), 1 on error.
  # Sets safe_copy_result: "copied" | "skipped" after each call.
  local src="$1"
  local dst="$2"
  local effective_dst="$dst"
  local is_dir_copy="false"
  safe_copy_result="copied"

  # Determine if source is a directory
  if [ -d "$src" ]; then
    is_dir_copy="true"
  fi

  # Resolve effective destination path
  # cp behaves the same for files and directories: when the destination is an
  # existing directory, the source is placed *inside* it.
  #   cp file dir/       -> dir/file
  #   cp -R src_dir dir/ -> dir/src_dir
  if [ -d "$dst" ]; then
    effective_dst="${dst%/}/$(basename "$src")"
  fi

  # If destination doesn't exist, just copy
  if [ ! -e "$effective_dst" ]; then
    if [ "$is_dir_copy" = "true" ]; then
      cp -R "$src" "$dst"
    else
      cp "$src" "$dst"
    fi
    return 0
  fi

  # Destination exists — prompt the user
  local choice
  print_msg WARNING "Destination already exists: ${effective_dst}"
  while true; do
    read -p "  (o)verwrite / (s)kip / (b)ackup and copy? [o/s/b]: " choice
    choice="${choice,,}"
    case "$choice" in
      o)
        # Remove existing destination first so directory copies don't
        # merge into stale content.
        rm -rf "$effective_dst"
        if [ "$is_dir_copy" = "true" ]; then
          cp -R "$src" "$dst"
        else
          cp "$src" "$dst"
        fi
        print_msg INFO "Overwritten: ${effective_dst}"
        return 0
        ;;
      s)
        print_msg INFO "Skipped: ${effective_dst}"
        safe_copy_result="skipped"
        return 0
        ;;
      b)
        mv "$effective_dst" "${effective_dst}.bak.${backup_date}"
        print_msg INFO "Backed up to: ${effective_dst}.bak.${backup_date}"
        if [ "$is_dir_copy" = "true" ]; then
          cp -R "$src" "$dst"
        else
          cp "$src" "$dst"
        fi
        return 0
        ;;
      *)
        echo "  Invalid choice. Please enter o, s, or b."
        ;;
    esac
  done
}

function copy_config() {
  mkdir -p "${afc_config_dir}"
  safe_copy "${afc_path}/config/AFC.cfg" "${afc_config_dir}/"
  safe_copy "${afc_path}/config/AFC_Macro_Vars.cfg" "${afc_config_dir}/"
  mkdir -p "${afc_config_dir}/mcu"
  safe_copy "${afc_path}/config/macros" "${afc_config_dir}/"
}

function copy_openams_config() {
  mkdir -p "${afc_config_dir}"
  safe_copy "${afc_path}/config/AFC.cfg" "${afc_config_dir}/"
  safe_copy "${afc_path}/config/AFC_Macro_Vars.cfg" "${afc_config_dir}/"
  mkdir -p "${afc_config_dir}/mcu"
  safe_copy "${afc_path}/config/macros" "${afc_config_dir}/"
}

function copy_snapmaker_config() {
    mkdir -p "${afc_config_dir}"
    safe_copy "${afc_path}/templates/u1_macros/AFC.cfg" "${afc_config_dir}/"
    safe_copy "${afc_path}/config/AFC_Macro_Vars.cfg" "${afc_config_dir}/"
    mkdir -p "${afc_config_dir}/mcu"
    mkdir -p "${afc_config_dir}/macros"
    safe_copy "${afc_path}/templates/u1_macros/Snapmaker_macros.cfg" "${afc_config_dir}/macros/"
    safe_copy "${afc_path}/config/macros/AFC_macros.cfg" "${afc_config_dir}/macros"
    safe_copy "${afc_path}/templates/AFC_Hardware_U1.cfg" "${afc_config_dir}/AFC_Hardware.cfg"
}

get_git_version() {
  local git_hash
  local afc_py_version
  cd "$afc_path" || exit
	git_hash=$(git -C . rev-parse --short HEAD)
	afc_py_version=$(grep "AFC_VERSION=" "${afc_path}/extras/AFC.py" | cut -d '=' -f2 | tr -d ' "')
	afc_version="${afc_py_version}-${git_hash}"
	cd - > /dev/null || exit
}

check_for_uncommitted_changes() {
  echo "→ Checking for uncommitted changes…"
    if ! git -C "${afc_path}" diff --quiet || \
       ! git -C "${afc_path}" diff --quiet --cached; then
      echo "❌ You have uncommitted changes in ${afc_path}."
      echo "   Please commit or stash them before running this script."
      echo ""
      echo "💡 To discard your changes and reset the branch:"
      echo "   cd \"${afc_path}\""
      echo "   git checkout ${branch}"
      echo "   git reset --hard origin/${branch}"
      echo "   git clean -fd"
      exit 1
    fi
}

clone_and_maybe_restart() {
  if [[ ! -d "${afc_path}/.git" ]]; then
    echo "→ Cloning ${branch} from ${gitrepo} into ${afc_path}…"
    git clone \
      --branch "${branch}" \
      --single-branch \
      --depth 1 \
      "${gitrepo}" \
      "${afc_path}"
    echo "✓ Clone complete."
  else
    echo "→ Switching to branch '${branch}'…"
    git -C "${afc_path}" checkout --quiet "${branch}"

    check_for_uncommitted_changes

    echo "→ Fetching updates in ${afc_path}…"
    git -C "${afc_path}" fetch --prune --quiet

    if git -C "${afc_path}" status --porcelain --branch | grep -q 'behind'; then
      echo "→ New commits detected; rebasing…"
      git -C "${afc_path}" pull --rebase --quiet
      echo "✓ Update applied. Restarting script…"
      exec "$0" "${original_args[@]}"
    else
      echo "✓ Already up to date."
    fi
  fi
}

backup_afc_config() {
  # Function to back up the existing AFC configuration.
  # Arguments:
  #   - AFC_CONFIG_PATH: The path to the AFC configuration directory.
  #   - PRINTER_CONFIG_PATH: The path to the printer configuration directory.

  if [ -d "${afc_config_dir}" ]; then
    pushd "${printer_config_dir}" || exit
    mv AFC AFC.backup."$backup_date"
    popd || exit
  fi
}

backup_afc_config_copy() {
  # Function to back up the existing AFC configuration.
  # Arguments:
  #   - AFC_CONFIG_PATH: The path to the AFC configuration directory.
  #   - PRINTER_CONFIG_PATH: The path to the printer configuration directory.

  if [ -d "${afc_config_dir}" ]; then
    pushd "${printer_config_dir}" || exit
    cp -R AFC AFC.backup."$backup_date"
    popd || exit
  fi
}

exclude_from_klipper_git() {
  local EXTRAS_DIR="${afc_path}/extras"
  local EXCLUDE_FILE="${klipper_dir}/.git/info/exclude"

  # Find all .py files in the extras directory and add them to the exclude file if they are not already present
  find "$EXTRAS_DIR" -type f -name "*.py" | while read -r file; do
    case $file in
      # Exclude adding __init__.py file to klippers exclude file
      *__init__.py) continue;;
      *)
        # Adjust the file path to the required format
        local relative_path="klippy/extras/$(basename "$file")"
        if ! grep -Fxq "$relative_path" "$EXCLUDE_FILE"; then
          echo "$relative_path" >> "$EXCLUDE_FILE"
        fi
        ;;
      esac
  done
}

restart_service() {
  # Function to restart a given service.
  # Arguments:
  #   $1 - The name of the service to restart.

  local service_name=$1
  if command -v systemctl &> /dev/null; then
    sudo systemctl restart "${service_name}"
  else
    sudo service "${service_name}" restart
  fi
}

restart_klipper() {
  if query_printer_status; then
    if [ "$is_snapmaker" == "True" ]; then
      u1_restart_klipper
    else
      restart_service klipper
    fi

  else
    if [ "$is_snapmaker" == "True" ]; then
      print_msg WARNING "Please manually restart klipper through <ip_address>/firmware-config panel, or fully power-cycle printer."
    else
      print_msg WARNING "Your printer is not idle/ready, or its status could not be confirmed. Automatic Klipper restart has been skipped; please restart the Klipper service manually once the printer is idle."
    fi
  fi
}

exit_afc_install() {
  if [ "$files_updated_or_installed" == "True" ]; then
    if [ "$test_mode" == "False" ]; then
      print_msg INFO "Restarting Klipper service to apply changes..."
      restart_klipper
    else
      print_msg INFO "Test mode enabled; skipping Klipper restart."
    fi
  fi
  remove_vars_tool_file
  exit 0
}

function auto_update() {
  check_and_append_prep "${afc_config_dir}/AFC.cfg"
  remove_t_macros
  # merge_configs "${AFC_CONFIG_PATH}/AFC_Hardware.cfg" "${AFC_PATH}/templates/AFC_Hardware-AFC.cfg" "${AFC_CONFIG_PATH}/AFC_Hardware-temp.cfg"
  # cleanup_blank_lines "${AFC_CONFIG_PATH}/AFC_Hardware-temp.cfg"
  # mv "${AFC_CONFIG_PATH}/AFC_Hardware-temp.cfg" "${AFC_CONFIG_PATH}/AFC_Hardware.cfg"
}


remove_vars_tool_file() {
  rm -f "${afc_config_dir}"/*.tool
}

stop_service() {
  # Function to restart a given service.
  # Arguments:
  #   $1 - The name of the service to restart.

  local service_name=$1
  if command -v systemctl &> /dev/null; then
    sudo systemctl stop "${service_name}"
  else
    sudo service "${service_name}" stop
  fi
}

start_service() {
  # Function to restart a given service.
  # Arguments:
  #   $1 - The name of the service to restart.

  local service_name=$1
  if command -v systemctl &> /dev/null; then
    sudo systemctl start "${service_name}"
  else
    sudo service "${service_name}" start
  fi
}

del_var_file() {
  local confirm
  # Function to remove the user's AFC.var.unit file in a simple fashion.
  echo "This is generally a troubleshooting step and should not be needed during normal operation."
  read -p "Do you want to proceed? (y/n): " confirm
  confirm="${confirm,,}"
  if [[ "$confirm" != "y" ]]; then
    unit_message="Operation cancelled by user.\n"
  else
    if [ -f "${afc_config_dir}/AFC.var.unit" ]; then
      rm "${afc_config_dir}/AFC.var.unit"
      unit_message="Removed old AFC.var.unit file.\n"
    else
      unit_message="No AFC.var.unit file found to remove.\n"
    fi
  fi
  export unit_message
}

check_for_k1() {
  if grep -Fqs "ID=buildroot" /etc/os-release; then
    is_k1_os="True"
    if grep -Fqs RK_BUILD_INFO=\"snapmaker /etc/os-release; then
      is_snapmaker="True"
      klipper_venv="/usr/bin"
    fi
  fi
}

check_for_zip_install() {
  if [ ! -d "${afc_path}/.git" ]; then
    export git_install="False"
    print_msg WARNING "AFC-Klipper-Add-On appears to have been installed via ZIP file."
    print_msg WARNING "Some features may not work as expected without a Git installation."
    print_msg WARNING "Any updates will require manual reinstallation via ZIP file."
    read -p "Press Enter to continue..."
  fi
}