# Armored Turtle Automated Filament Changer
#
# Copyright (C) 2024-2026 Armored Turtle
#
# This file may be distributed under the terms of the GNU GPLv3 license.
from __future__ import annotations

import math
import traceback

from contextlib import contextmanager
from configfile import error
from datetime import datetime
from enum import Enum

from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from configfile import ConfigWrapper
    from extras.AFC import afc
    from extras.AFC_extruder import AFCExtruder
    from extras.AFC_hub import afc_hub
    from extras.AFC_buffer import AFCBuffer
    from extras.AFC_stepper import AFCExtruderStepper
    from extras.AFC_unit import afcUnit
    from pins import PrinterPins
    from query_endstops import QueryEndstops

try: from extras.AFC_utils import ERROR_STR, add_filament_switch
except: raise error("Error when trying to import AFC_utils.ERROR_STR, add_filament_switch\n{trace}".format(trace=traceback.format_exc()))

try: from extras import AFC_assist
except: raise error(ERROR_STR.format(import_lib="AFC_assist", trace=traceback.format_exc()))

try: from extras.AFC_stats import AFCStats_var
except: raise error(ERROR_STR.format(import_lib="AFC_stats", trace=traceback.format_exc()))

# Unit types that only have load switch
ONLY_LOAD_TYPES = ["HTLF", "Claymore", "OpenAMS"]
EXCLUDE_TYPES = ONLY_LOAD_TYPES + [ "ViViD"]
# Class for holding different states so its clear what all valid states are

# Names to exclude from search when trying to find unit name in config file
# These are more for name that could be in config files
INVALID_UNIT_NAMES = ["AFC_buffer", "AFC_button", "AFC_extruder",
                      "AFC_hub", "AFC_lane", "AFC_led", "AFC_prep", "AFC_stepper"]

class AssistActive(Enum):
    YES = 1
    NO = 2
    DYNAMIC = 3
class SpeedMode(Enum):
    NONE = None
    LONG = 1
    SHORT = 2
    HUB = 3
    NIGHT = 4
    CALIBRATION = 5
    DIST_HUB = 6

class MoveDirection(float):
    POS = 1.
    NEG = -1.

class AFCLaneState:
    NONE             = "None"
    ERROR            = "Error"
    LOADED           = "Loaded"
    TOOLED           = "Tooled"
    TOOL_LOADED      = "Tool Loaded"
    TOOL_LOADING     = "Tool Loading"
    TOOL_UNLOADING   = "Tool Unloading"
    HUB_LOADING      = "HUB Loading"
    EJECTING         = "Ejecting"
    CALIBRATING      = "Calibrating"
    INFINITE_RUNOUT  = "Infinite Runout"

VALID_DIRECT_HUB = ['direct', 'direct_load']

class AFCHomingPoints(str):
    NONE        = None
    HUB         = "hub"
    LOAD        = "load"
    TOOL        = "tool"
    TOOL_START  = "tool_start"
    BUFFER      = "buffer"
    BUFFER_TRAIL= "buffer_trailing"
    SELECTOR    = "selector"
    PREP        = "prep"

class AFCMoveWarning(Enum):
    NONE = 0
    WARN = 1
    ERROR = 2

class AFCLane:
    UPDATE_WEIGHT_DELAY = 10.0
    def __init__(self, config: ConfigWrapper) -> None:
        self._config            = config
        self.printer            = config.get_printer()
        self.afc: afc           = self.printer.load_object(config, 'AFC')
        self.gcode              = self.printer.load_object(config, 'gcode')
        self.reactor            = self.printer.get_reactor()
        self.mutex              = self.reactor.mutex()
        self.extruder_stepper   = None
        self.logger             = self.afc.logger
        self.printer.register_event_handler("klippy:ready", self._handle_ready)
        self.printer.register_event_handler("afc:moonraker_connect", self.handle_moonraker_connect)
        self.cb_update_weight   = self.reactor.register_timer( self.update_weight_callback )

        self.unit_obj: afcUnit  = None
        self.hub_obj: Optional[afc_hub|None] = None
        self.buffer_obj: Optional[AFCBuffer|None] = None
        self.extruder_obj: AFCExtruder
        self.endstops = {}

        #stored status variables
        self.fullname: str      = config.get_name()
        self.name               = self.fullname.split()[-1]

        # TODO: Put these variables into a common class or something so they are easier to clear out
        # when lanes are unloaded
        self.tool_loaded        = False
        self.loaded_to_hub      = False
        self.spool_id           = None
        self.color: str         = ""
        self.multi_color: list  = []
        self.spool_vendor: str  = ""
        self.filament_name: str = ""
        self.weight: float      = 0.
        self.auto_switch_triggered = False
        self._material: str     = None
        self.extruder_temp      = None
        self.bed_temp           = None
        self.td1_data           = {}
        self.runout_lane        = None
        self.status             = AFCLaneState.NONE
        self.need_purge         = False
        self._afc_staged_spool_id: Optional[int] = None
        self._load_suppressed: bool = False
        # END TODO

        self.multi_hubs_found   = False
        self.drive_stepper: AFCExtruderStepper = None
        unit: str               = config.get('unit')                                    # Unit name(AFC_BoxTurtle/NightOwl/etc) that belongs to this stepper.
        # Overrides buffers set at the unit level
        self.hub: str           = config.get('hub',None)                                # Hub name(AFC_hub) that belongs to this stepper, overrides hub that is set in unit(AFC_BoxTurtle/NightOwl/etc) section.
        # Overrides buffers set at the unit and extruder level
        self.buffer_name: str   = config.get("buffer", None)                            # Buffer name(AFC_buffer) that belongs to this stepper, overrides buffer that is set in extruder(AFC_extruder) or unit(AFC_BoxTurtle/NightOwl/etc) sections.
        self.unit               = unit.split(':')[0]
        try:
            self.index              = int(unit.split(':')[1])
        except:
            self.index              = 0
            pass

        self.afc_extruder_name    = config.get('extruder', None)                          # Extruder name(AFC_extruder) that belongs to this stepper, overrides extruder that is set in unit(AFC_BoxTurtle/NightOwl/etc) section.
        self.standalone_lane      = config.getboolean("standalone", False)
        self.remember_spool :bool = config.getboolean('remember_spool', None)             # remember_spool that is set in AFC_Stepper section, overrides remember_spool that is set in unit(AFC_BoxTurtle/NightOwl/etc) section.
        self.map                = config.get('cmd', None)                               # Keeping this in so it does not break others config that may have used this, use map instead
        # Saving to self._map so that if a user has it defined it will be reset back to this when
        # the calling RESET_AFC_MAPPING macro.

        # LED SETTINGS
        # All variables use: (R,G,B,W) 0 = off, 1 = full brightness. Setting value here overrides values set in unit(AFC_BoxTurtle/NightOwl/etc) section
        self._map = self.map      = config.get('map', self.map)
        self.led_index            = config.get('led_index', None)                       # LED index of lane in chain of lane LEDs
        self.led_fault            = config.get('led_fault',None)                        # LED color to set when faults occur in lane
        self.led_ready            = config.get('led_ready',None)                        # LED color to set when lane is ready
        self.led_not_ready        = config.get('led_not_ready',None)                    # LED color to set when lane not ready
        self.led_loading          = config.get('led_loading',None)                      # LED color to set when lane is loading
        self.led_prep_loaded      = config.get('led_loading',None)                      # LED color to set when lane is loaded
        self.led_unloading        = config.get('led_unloading',None)                    # LED color to set when lane is unloading
        self.led_tool_loaded      = config.get('led_tool_loaded',None)                  # LED color to set when lane is loaded into tool
        self.led_tool_loaded_idle = config.get('led_tool_loaded_idle',None)             # LED color to set when lane is loaded into tool and idle
        self.led_tool_unloaded    = config.get('led_tool_unloaded', None)               # LED color to set when lanes extruder is unloaded
        self.led_spool_index      = config.get('led_spool_index', None)                 # LED index to illuminate under spool
        self.led_spool_illum      = config.get('led_spool_illuminate', None)            # LED color to illuminate under spool
        self.led_use_filament_color: bool = config.getboolean('led_use_filament_color', None)  # When True, uses filament color from color field for lane LEDs instead of configured LED colors

        self.long_moves_speed: float   = config.getfloat("long_moves_speed", None)             # Speed in mm/s to move filament when doing long moves. Setting value here overrides values set in unit(AFC_BoxTurtle/NightOwl/etc) section
        self.long_moves_accel: float   = config.getfloat("long_moves_accel", None)             # Acceleration in mm/s squared when doing long moves. Setting value here overrides values set in unit(AFC_BoxTurtle/NightOwl/etc) section
        self.short_moves_speed: float  = config.getfloat("short_moves_speed", None)            # Speed in mm/s to move filament when doing short moves. Setting value here overrides values set in unit(AFC_BoxTurtle/NightOwl/etc) section
        self.short_moves_accel: float  = config.getfloat("short_moves_accel", None)            # Acceleration in mm/s squared when doing short moves. Setting value here overrides values set in unit(AFC_BoxTurtle/NightOwl/etc) section
        self.short_move_dis: float     = config.getfloat("short_move_dis", None)               # Move distance in mm for failsafe moves. Setting value here overrides values set in unit(AFC_BoxTurtle/NightOwl/etc) section
        self.max_move_dis: float       = config.getfloat("max_move_dis", None)                 # Maximum distance to move filament. AFC breaks filament moves over this number into multiple moves. Useful to lower this number if running into timer too close errors when doing long filament moves. Setting value here overrides values set in unit(AFC_BoxTurtle/NightOwl/etc) section
        self.n20_break_delay_time: float = config.getfloat("n20_break_delay_time", None)        # Time to wait between breaking n20 motors(nSleep/FWD/RWD all 1) and then releasing the break to allow coasting. Setting value here overrides values set in unit(AFC_BoxTurtle/NightOwl/etc) section
        self.homing_overshoot: float   = config.getfloat("homing_overshoot", None)             # Amount to add to homing distance so that distance is long enough to actually hit endstop
        self.homing_delta: float       = config.getfloat("homing_delta", None)                 # Delta for which to warn if homing move delta is not within this amount from command move distance.
        self.load_then_home_var: bool  = config.getboolean("load_then_home", None)
        self.load_undershoot: float    = config.getfloat("load_undershoot", None)
        self.extruder_clear_dis: float = config.getfloat("extruder_clear_dis", None)
        self.tool_max_unload_attempts  = config.getint('tool_max_unload_attempts', None, minval=0) # Max number of attempts to unload filament from toolhead when using buffer as ramming sensor

        # Custom Load/unload Commands
        self.custom_load_cmd = config.get('custom_load_cmd', None)  # Custom command to run when loading lane, this will bypass the typical load sequence and run the command instead.
        self.custom_unload_cmd = config.get('custom_unload_cmd', None)  # Custom command to run when unloading lane, this will bypass the typical unload sequence and run the command instead.

        self.rev_long_moves_speed_factor: float = config.getfloat("rev_long_moves_speed_factor", None)     # scalar speed factor when reversing filamentalist

        self.dist_hub: float        = config.getfloat('dist_hub', 60)                       # Bowden distance between Box Turtle extruder and hub
        self.park_dist: float       = config.getfloat('park_dist', 10)                      # Currently unused

        self.load_to_hub: bool      = config.getboolean("load_to_hub", self.afc.load_to_hub) # Fast loads filament to hub when inserted, set to False to disable. Setting here overrides global setting in AFC.cfg
        self.enable_sensors_in_gui: bool = config.getboolean("enable_sensors_in_gui",    self.afc.enable_sensors_in_gui) # Set to True to show prep and load sensors switches as filament sensors in mainsail/fluidd gui, overrides value set in AFC.cfg
        self.debounce_delay: float  = config.getfloat("debounce_delay",             self.afc.debounce_delay)
        self.enable_runout: bool    = config.getboolean("enable_hub_runout",        self.afc.enable_hub_runout)
        self.sensor_to_show: str    = config.get("sensor_to_show", None)                # Set to prep to only show prep sensor, set to load to only show load sensor. Do not add if you want both prep and load sensors to show in web gui

        self.assisted_unload: bool = config.getboolean("assisted_unload", None) # If True, the unload retract is assisted to prevent loose windings, especially on full spools. This can prevent loops from slipping off the spool. Setting value here overrides values set in unit(AFC_BoxTurtle/NightOwl/etc) section
        self.td1_when_loaded: bool = config.getboolean("capture_td1_when_loaded", None)
        self.td1_device_id: str    = config.get("td1_device_id", None)
        self.td1_bowden_length  = config.getfloat("td1_bowden_length", None)
        self.calibrated_lane: bool = config.getboolean("calibrated_lane", False)

        self.post_prep_macro: str  = config.get("post_prep_macro", None)  # Macro to call after loading filament during prep callback

        self.printer.register_event_handler("AFC_unit_{}:connect".format(self.unit),self.handle_unit_connect)
        self.config_dist_hub = self.dist_hub
        self.only_lane = False

        # lane triggers
        buttons = self.printer.load_object(config, "buttons")
        self.prep = config.get('prep', None)                                    # MCU pin for prep trigger
        self.prep_state = False
        if self.prep is not None:
            buttons.register_buttons([self.prep], self.prep_callback)

        self.load = config.get('load', None)                                    # MCU pin load trigger
        self._load_state = False
        if self.load is not None:
            buttons.register_buttons([self.load], self.load_callback)
        else: self._load_state = True

        self.selector: str = config.get("selector", None)

        self.espooler = AFC_assist.Espooler(self.name, config)
        self.lane_load_count = None

        self.filament_diameter: float  = config.getfloat("filament_diameter", 1.75)    # Diameter of filament being used
        self.filament_density: float   = config.getfloat("filament_density", 1.24)     # Density of filament being used
        self.inner_diameter: float     = config.getfloat("spool_inner_diameter", 75, minval=1)   # Inner diameter in mm
        self.outer_diameter: float     = config.getfloat("spool_outer_diameter", 200, minval=100)  # Outer diameter in mm
        self.empty_spool_weight: float = config.getfloat("empty_spool_weight", 190, minval=1)    # Empty spool weight in g
        self.max_motor_rpm: float      = config.getfloat("assist_max_motor_rpm", 465)  # Max motor RPM
        self.rwd_speed_multi: float    = config.getfloat("rwd_speed_multiplier", 0.5)  # Multiplier to apply to rpm
        self.fwd_speed_multi: float    = config.getfloat("fwd_speed_multiplier", 0.5)  # Multiplier to apply to rpm
        self.diameter_range     = self.outer_diameter - self.inner_diameter     # Range for effective diameter
        self.past_extruder_position = -1
        self.save_counter       = -1

        query_endstops = self.printer.load_object( config, "query_endstops")
        ppins          = self.printer.lookup_object('pins')
        # Defaulting to false so that extruder motors to not move until PREP has been called
        self._afc_prep_done = False

        if self.prep is not None:
            show_sensor = True
            if not self.enable_sensors_in_gui or (self.sensor_to_show is not None and 'prep' not in self.sensor_to_show):
                show_sensor = False
            self.fila_prep, self.prep_debounce_button = add_filament_switch(f"{self.name}_prep", self.prep, self.printer,
                                                                            show_sensor, enable_runout=self.enable_runout,
                                                                            debounce_delay=self.debounce_delay )
            self.prep_debounce_button.button_action = self.handle_prep_runout
            self.prep_debounce_button.debounce_delay = 0 # Delay will be set once klipper is ready
            self._set_homing_endstop(query_endstops, ppins,
                                     self.prep, AFCHomingPoints.PREP)

        if self.load is not None:
            show_sensor = True
            if not self.enable_sensors_in_gui or (self.sensor_to_show is not None and 'load' not in self.sensor_to_show):
                show_sensor = False
            self.fila_load, self.load_debounce_button = add_filament_switch(f"{self.name}_load", self.load, self.printer,
                                                                            show_sensor, enable_runout=self.enable_runout,
                                                                            debounce_delay=self.debounce_delay )
            self.load_debounce_button.button_action = self.handle_load_runout
            self.load_debounce_button.debounce_delay = 0 # Delay will be set once klipper is ready
            self._set_homing_endstop(query_endstops, ppins,
                                     self.load, AFCHomingPoints.LOAD)

        self._selector_state: Optional[bool] = None
        self.selector_cal_dis: Optional[float] = None
        if self.selector is not None:
            self.selector_cal_dis = config.getfloat("selector_cal_distance", 0.0)
            show_sensor = True
            if not self.enable_sensors_in_gui or (self.sensor_to_show is not None and 'selector' not in self.sensor_to_show):
                show_sensor = False
            self.fila_selector, _ = add_filament_switch(f"{self.name}_selector", self.selector,
                                                        self.printer, show_sensor)
            self._set_homing_endstop(query_endstops, ppins,
                                     self.selector, AFCHomingPoints.SELECTOR)
            buttons.register_buttons([self.selector], self.selector_callback)

        if (self.hub
            and "direct" not in self.hub):
            self._get_hub_object()
            self._set_homing_endstop(query_endstops, ppins,
                                     self.hub_obj.switch_pin, AFCHomingPoints.HUB)
        if self.buffer_name:
            self._get_buffer_object()
            if self.buffer_obj.advance_pin is not None:
                self._set_homing_endstop(query_endstops, ppins,
                                         self.buffer_obj.advance_pin, AFCHomingPoints.BUFFER)

        if (self.afc_extruder_name
            and not self.standalone_lane): # Protects against standalone lanes
            self._get_extruder_object()
            pin = self.extruder_obj.tool_start
            if pin and "buffer" not in pin:
                self._set_homing_endstop(query_endstops, ppins,
                                         pin, AFCHomingPoints.TOOL)

        self.connect_done = False
        self.prep_active = False
        self.last_prep_time = 0

        self.show_macros = self.afc.show_macros
        self.function = self.printer.load_object(config, 'AFC_functions')
        self.function.register_mux_command(self.show_macros, 'SET_LANE_LOADED', 'LANE', self.name,
                                           self.cmd_SET_LANE_LOADED, self.cmd_SET_LANE_LOADED_help,
                                           self.cmd_SET_LANE_LOAD_options )
        self.function.register_mux_command(self.show_macros, 'AFC_RECOVER_LANE', 'LANE', self.name,
                                           self.cmd_AFC_RECOVER_LANE, self.cmd_AFC_RECOVER_LANE_help,
                                           self.cmd_AFC_RECOVER_LANE_options )

        if "AFC_stepper" in self.fullname:
            self.printer.register_event_handler("klippy:mcu_identify", self._handle_mcu_identify)
            return

        # Should only get this far for AFC_lane configs
        self._get_steppers(config)
        if (hasattr(self, "unit_obj")
            and getattr(self.unit_obj, "selector_stepper_obj", None)):
            # Register macro for units that have selectors
            self.function.register_mux_command(self.afc.show_macros, "AFC_SELECT_LANE",
                                               "LANE", self.name,
                                               self.unit_obj.cmd_AFC_SELECT_LANE,
                                               description=self.unit_obj.cmd_AFC_SELECT_LANE_help,
                                               options=self.unit_obj.cmd_AFC_SELECT_LANE_options)

    def __str__(self):
        return self.name

    @property
    def load_es(self) -> str:
        """
        Returns endstop name to use for homing.

        :return str: Returns 'load' if lane has stepper, returns unique lane load name if lane is
                     part of a selector based system.
        """
        if self.only_lane:
            return self.load_endstop_name
        else:
            return AFCHomingPoints.LOAD

    def _lookup_endstop(self, name: str) -> Optional[str]:
        """
        Helper method for looking up endstops from dictionary

        :param name: Endstop name to lookup
        :return: Returns name if its found, if name is not found returns name passed in
        """
        endstop_name = name
        if name in self.endstops:
            endstop_name = self.endstops[name]["endstop_name"]
        return endstop_name

    """
    The following properties lookup specific endstop name
    """
    @property
    def prep_endstop_name(self) -> str:
        return self._lookup_endstop(AFCHomingPoints.PREP)

    @property
    def load_endstop_name(self) -> str:
        return self._lookup_endstop(AFCHomingPoints.LOAD)

    @property
    def selector_endstop_name(self) -> str:
        return self._lookup_endstop(AFCHomingPoints.SELECTOR)

    @property
    def hub_endstop_name(self) -> str:
        return self._lookup_endstop(AFCHomingPoints.HUB)

    @property
    def buffer_endstop_name(self) -> str:
        return self._lookup_endstop(AFCHomingPoints.BUFFER)

    @property
    def tool_endstop_name(self) -> str:
        return self._lookup_endstop(AFCHomingPoints.TOOL)

    @property
    def material(self):
        """
        Returns lanes filament material type

        :return str: Current filament material type for the lane
        """
        return self._material

    @material.setter
    def material(self, value):
        """
        Sets filament material type and sets filament density based off material type.
        To use custom density, set density after setting material
        """
        self._material = value
        if not value:
            self.filament_density = 1.24 # Setting to a default value
            return

        for density in self.afc.common_density_values:
            v = density.split(":")
            if v[0] in value:
                self.filament_density = float(v[1])
                break

    @property
    def lane_index(self) -> str:
        """
        Strip's T from lane map and return integer as string.

        :returns str: Returns lane mapping index as string
        """
        if self.map is None:
            return ""

        return self.map.replace("T", "")

    @property
    def lane_extruder_index(self) -> int:
        """
        Finds lanes extruder integer number and returns as integer.

        :return int: Returns lanes extruder index as integer.
        """
        extruder_index = 0
        if not hasattr(self, "extruder_obj") or self.extruder_obj is None:
            return extruder_index

        th_extruder_name = self.extruder_obj.th_extruder_name

        if th_extruder_name == "extruder":
            return extruder_index

        try:
            return int(th_extruder_name.replace("extruder", ""))
        except ValueError:
            return extruder_index

    def _handle_mcu_identify(self):
        """
        Handles klippy:mcu_identify callback to register endstops for steppers
        """
        self._get_steppers(self._config)

    def _handle_ready(self):
        """
        Handles klippy:ready callback and verifies that steppers have units defined in their config
        """
        if self.unit_obj is None:
            raise error("Unit {unit} is not defined in your configuration file. Please defined unit ex. [AFC_BoxTurtle {unit}]".format(unit=self.unit))

        if self.led_index is not None:
            # Verify that LED config is found
            for led_name, index_str in self.afc.function.parse_led_groups(self.led_index):
                error_string, led = self.afc.function.verify_led_object(led_name)
                if led is None:
                    raise error(error_string)
        self.espooler.handle_ready()

        # Setting debounce delay after ready so that callback does not get triggered when initially loading
        if hasattr(self, "prep_debounce_button"):
            self.prep_debounce_button.debounce_delay = self.debounce_delay
        if hasattr(self, "load_debounce_button"):
            self.load_debounce_button.debounce_delay = self.debounce_delay

    def _get_hub_object(self):
        """
        Helper method to lookup lane/stepper hub object and assign object to hub_obj variable

        raises error if hub is not found
        """
        try:
            self.hub_obj = self.printer.load_object(self._config, "AFC_hub {}".format(self.hub))
        except:
            error_string = 'Error: No config found for hub: {hub} in [{stepper}]. Please make sure [AFC_hub {hub}] section exists in your config'.format(
            hub=self.hub, stepper=self.fullname )
            raise error(error_string)

    def _get_buffer_object(self):
        """
        Helper method to lookup lane/stepper buffer object and assigns object to buffer_obj variable

        raises error if buffer is not found
        """
        try:
            self.buffer_obj = self.printer.load_object(self._config, "AFC_buffer {}".format(self.buffer_name))
        except:
            error_string = 'Error: No config found for buffer: {buffer} in [{stepper}]. Please make sure [AFC_buffer {buffer}] section exists in your config'.format(
                buffer=self.buffer_name, stepper=self.fullname )
            raise error(error_string)

    def _get_extruder_object(self):
        """
        Helper method to lookup lane/stepper extruder object and assigns object to extruder_obj variable

        raises error if extruder is not found
        """
        try:
            self.extruder_obj = self.printer.load_object(self._config, 'AFC_extruder {}'.format(self.afc_extruder_name))
        except Exception as e:
            error_string = 'Error: No config found for extruder: {extruder} in [{stepper}]. Please make sure [AFC_extruder {extruder}] section exists in your config\nKlippy error: {e}'.format(
                extruder=self.afc_extruder_name, stepper=self.fullname, e=e )
            raise error(error_string)

    def _set_homing_endstop(self, query_endstops: QueryEndstops, ppins: PrinterPins,
                            pin: str, name: str):
        """
        Helper method for setting up pin as endstop for homing to and add to endstops dictionary.

        :param query_endstops: Klippers query endstops object
        :param ppins: Klipper pins object
        :param pin: MCU pin to setup as endstop
        :param name: Name of endstop to register
        """
        # Guarding against hub virtual pins
        if pin is not None and pin.strip().lower() == "virtual":
            return

        ppins.allow_multi_use_pin(pin.strip("!^"))
        ppins.parse_pin(pin, True, True)
        endstop = ppins.setup_pin('endstop', pin)
        endstop_name = f"{self.name}_{name}"
        try:
            query_endstops.register_endstop(endstop,
                                            endstop_name)
        except Exception as e:
            err_msg = f"Error trying to register {name} endstop for {self.name}.\n Error:{e}"
            raise error(err_msg)

        self.endstops.update({name: {"endstop": endstop, "endstop_name": endstop_name}})

    def handle_moonraker_connect(self):
        """
        Function that should be called at the beginning of PREP so that moonraker has
        enough time to start before AFC tries to connect. This fixes a race condition that can
        happen between klipper and moonraker when first starting up.
        """

        if (self.unit_obj.type not in EXCLUDE_TYPES
            or (self.unit_obj.type in EXCLUDE_TYPES and "AFC_lane" in self.fullname)):
            values = self.afc.moonraker.get_afc_stats()
            self.lane_load_count = AFCStats_var(self.name, "load_count", values, self.afc.moonraker)
            self.espooler.handle_moonraker_connect()

            # Update boolean and check to make sure a TD-1 device is detected
            self.td1_when_loaded = self.td1_when_loaded and self.afc.td1_defined

    def handle_unit_connect(self, unit_obj: afcUnit):
        """
        Callback from <unit_name>:connect to verify units/hub/buffer/extruder object. Errors out if user specified names and they do not exist in their configuration
        """
        # Saving reference to unit
        self.unit_obj: afcUnit = unit_obj
        self.buffer_obj = self.unit_obj.buffer_obj
        add_to_other_obj = False

        # Inherit remember_spool from unit unless explicitly set in lane config
        if self.remember_spool is None:
            self.remember_spool = bool(self.unit_obj.remember_spool)

        # Register all lanes if their type is not HTLF or only register lanes that are HTLF and have AFC_lane
        # in the name so that HTLF stepper names do not get added since they are not a lane for this unit type
        if (self.unit_obj.type not in EXCLUDE_TYPES
            or (self.unit_obj.type in EXCLUDE_TYPES and "AFC_lane" in self.fullname)):
            add_to_other_obj = True
            # Registering lane name in unit
            self.unit_obj.lanes[self.name] = self
            self.afc.lanes[self.name] = self


        if self.hub is None:
            self.hub_obj = self.unit_obj.hub_obj

        if not self.is_direct_hub():
            if self.hub is not None:
                self._get_hub_object()
            # Removing for now as this is probably not the best idea to default to a random hub
            # elif self.hub_obj is None:
            #     # Check to make sure at least 1 hub exists in config, if not error out with message
            #     if len(self.afc.hubs) == 0:
            #         error_string = "Error: AFC_hub not found in configuration please make sure there is a [AFC_hub <hub_name>] defined in your configuration"
            #         raise error(error_string)
            #     # Setting hub to first hub in AFC hubs dictionary
            #     if len(self.afc.hubs) > 0:
            #         self.hub_obj = next(iter(self.afc.hubs.values()))
            #     # Set flag to warn during prep that multiple hubs were found
            #     if len(self.afc.hubs) > 1:
            #         self.multi_hubs_found = True

            # Assigning hub name just in case stepper is using hub defined in units config
            if self.hub_obj:
                self.hub = self.hub_obj.name
                if add_to_other_obj:
                    self.hub_obj.lanes[self.name] = self
        else:
            self.hub_obj = lambda: None
            self.hub_obj.state = False
            self.hub_obj.move_dis = 75
            self.hub_obj.hub_clear_move_dis = 65

        self.extruder_obj = self.unit_obj.extruder_obj
        if self.afc_extruder_name is not None:
            self._get_extruder_object()
        elif self.extruder_obj is None:
            error_string = "Error: Extruder has not been configured for stepper {name}, please add extruder variable to either [AFC_stepper {name}] or [AFC_{unit_type} {unit_name}] in your config file".format(
                        name=self.name, unit_type=self.unit_obj.type.replace("_", ""), unit_name=self.unit_obj.name)
            raise error(error_string)

        # Assigning extruder name just in case stepper is using extruder defined in units config
        self.afc_extruder_name = self.extruder_obj.name
        if add_to_other_obj:
            self.extruder_obj.lanes[self.name] = self
            self.extruder_obj.check_lanes()

        # Use buffer defined in stepper and override buffers that maybe set at the UNIT or extruder levels
        self.buffer_obj = self.unit_obj.buffer_obj
        if self.buffer_name is not None:
            self._get_buffer_object()

        # Checking if buffer was defined in extruder if not defined in unit/stepper
        elif (self.buffer_obj is None
              and self.extruder_obj.tool_start == "buffer"
              and self.name != self.extruder_obj.name):
            if self.extruder_obj.buffer_name is not None:
                self.buffer_obj = self.printer.lookup_object("AFC_buffer {}".format(self.extruder_obj.buffer_name))
            else:
                error_string = 'Error: Buffer was defined as tool_start in [AFC_extruder {extruder}] config, but buffer variable has not been configured. Please add buffer variable to either [AFC_extruder {extruder}], [AFC_stepper {name}] or [AFC_{unit_type} {unit_name}] section in your config file'.format(
                    extruder=self.extruder_obj.name, name=self.name, unit_type=self.unit_obj.type.replace("_", ""), unit_name=self.unit_obj.name )
                raise error(error_string)

        # Valid to not have a buffer defined, check to make sure object exists before adding lane to buffer
        if self.buffer_obj is not None and add_to_other_obj:
            self.buffer_obj.lanes[self.name] = self
            # Assigning buffer name just in case stepper is using buffer defined in units/extruder config
            self.buffer_name = self.buffer_obj.name

        if self.led_fault            is None: self.led_fault            = self.unit_obj.led_fault
        if self.led_ready            is None: self.led_ready            = self.unit_obj.led_ready
        if self.led_not_ready        is None: self.led_not_ready        = self.unit_obj.led_not_ready
        if self.led_loading          is None: self.led_loading          = self.unit_obj.led_loading
        if self.led_prep_loaded      is None: self.led_prep_loaded      = self.unit_obj.led_prep_loaded
        if self.led_unloading        is None: self.led_unloading        = self.unit_obj.led_unloading
        if self.led_tool_loaded      is None: self.led_tool_loaded      = self.unit_obj.led_tool_loaded
        if self.led_tool_loaded_idle is None: self.led_tool_loaded_idle = self.unit_obj.led_tool_loaded_idle
        if self.led_tool_unloaded    is None: self.led_tool_unloaded    = self.unit_obj.led_tool_unloaded
        if self.led_spool_illum      is None: self.led_spool_illum      = self.unit_obj.led_spool_illum
        if self.led_use_filament_color is None: self.led_use_filament_color = self.unit_obj.led_use_filament_color

        if self.rev_long_moves_speed_factor is None: self.rev_long_moves_speed_factor  = self.unit_obj.rev_long_moves_speed_factor
        if self.long_moves_speed            is None: self.long_moves_speed  = self.unit_obj.long_moves_speed
        if self.long_moves_accel            is None: self.long_moves_accel  = self.unit_obj.long_moves_accel
        if self.short_moves_speed           is None: self.short_moves_speed = self.unit_obj.short_moves_speed
        if self.short_moves_accel           is None: self.short_moves_accel = self.unit_obj.short_moves_accel
        if self.short_move_dis              is None: self.short_move_dis    = self.unit_obj.short_move_dis
        if self.max_move_dis                is None: self.max_move_dis      = self.unit_obj.max_move_dis
        if self.homing_overshoot            is None: self.homing_overshoot  = self.unit_obj.homing_overshoot
        if self.homing_delta                is None: self.homing_delta      = self.unit_obj.homing_delta
        if self.load_then_home_var          is None: self.load_then_home_var= self.unit_obj.load_then_home_var
        if self.load_undershoot             is None: self.load_undershoot   = self.unit_obj.load_undershoot
        if self.td1_when_loaded             is None: self.td1_when_loaded   = self.unit_obj.td1_when_loaded
        if self.td1_device_id               is None: self.td1_device_id     = self.unit_obj.td1_device_id
        if self.extruder_clear_dis          is None: self.extruder_clear_dis= self.unit_obj.extruder_clear_dis
        if self.post_prep_macro             is None: self.post_prep_macro   = self.unit_obj.post_prep_macro
        if self.tool_max_unload_attempts    is None: self.tool_max_unload_attempts = self.unit_obj.tool_max_unload_attempts

        if self.td1_bowden_length           is None:
            if not self.is_direct_hub():
                self.td1_bowden_length = self.hub_obj.td1_bowden_length
        if self.rev_long_moves_speed_factor < 0.5: self.rev_long_moves_speed_factor = 0.5
        if self.rev_long_moves_speed_factor > 1.2: self.rev_long_moves_speed_factor = 1.2

        self.espooler.handle_connect(self)

        # Set hub loading speed depending on distance between extruder and hub
        self.dist_hub_move_speed = self.long_moves_speed if self.dist_hub >= 200 else self.short_moves_speed
        self.dist_hub_move_accel = self.long_moves_accel if self.dist_hub >= 200 else self.short_moves_accel

        # Register macros
        # TODO: add check so that HTLF stepper lanes do not get registered here
        self.afc.gcode.register_mux_command('SET_LONG_MOVE_SPEED',    "LANE", self.name, self.cmd_SET_LONG_MOVE_SPEED, desc=self.cmd_SET_LONG_MOVE_SPEED_help)
        self.afc.gcode.register_mux_command('SET_SPEED_MULTIPLIER',   "LANE", self.name, self.cmd_SET_SPEED_MULTIPLIER, desc=self.cmd_SET_SPEED_MULTIPLIER_help)
        self.afc.gcode.register_mux_command('SAVE_SPEED_MULTIPLIER',  "LANE", self.name, self.cmd_SAVE_SPEED_MULTIPLIER, desc=self.cmd_SAVE_SPEED_MULTIPLIER_help)
        self.afc.gcode.register_mux_command('SET_HUB_DIST',           "LANE", self.name, self.cmd_SET_HUB_DIST, desc=self.cmd_SET_HUB_DIST_help)
        self.afc.gcode.register_mux_command('SAVE_HUB_DIST',          "LANE", self.name, self.cmd_SAVE_HUB_DIST, desc=self.cmd_SAVE_HUB_DIST_help)
        self.afc.gcode.register_mux_command('AFC_SET_REMEMBER_SPOOL', "LANE", self.name, self.cmd_AFC_SET_REMEMBER_SPOOL, desc=self.cmd_AFC_SET_REMEMBER_SPOOL_help)

        if self.assisted_unload is None: self.assisted_unload = self.unit_obj.assisted_unload

        # Send out event so that macros and be registered properly with valid lane names
        self.printer.send_event("afc_stepper:register_macros", self)

        self.connect_done = True

    def _get_steppers(self, config: ConfigWrapper):
        """
        Helper function to get steppers for lane and setup for proper homing.

        :param config: Klipper config object for this lane
        """
        try:
            unit_cfg = next(
                config.getsection(s) for s in config.fileconfig.sections()
                if self.unit in s
                and s.startswith("AFC_")
                and not any(x in s for x in INVALID_UNIT_NAMES))
            self.unit_obj: afcUnit = self.printer.load_object(config, unit_cfg.get_name())

            if getattr(self.unit_obj, "stepperless_drive", False):
                return

            drive_stepper = self
            if not config.get("step_pin", None):
                self.only_lane = True
                if getattr(self.unit_obj, "drive_stepper_obj", None):
                    self.drive_stepper = self.unit_obj.drive_stepper_obj
                    drive_stepper = self.drive_stepper

            if drive_stepper:
                for es in self.endstops.values():
                    if AFCHomingPoints.SELECTOR in es["endstop_name"]:
                        continue
                    es["endstop"].add_stepper(drive_stepper.extruder_stepper.stepper)
                    drive_stepper._endstops[es["endstop_name"]] = (es["endstop"],
                                                                   es["endstop_name"])

        except Exception as e:
            self.logger.info(f"Couldn't find unit for {self.name} {e}")
            return

        if (self.unit_obj.type in EXCLUDE_TYPES
            and "AFC_lane" in self.fullname):
            self.drive_stepper      = self.unit_obj.drive_stepper_obj
            self.extruder_stepper   = self.drive_stepper.extruder_stepper
            if (self.selector
                and getattr(self.unit_obj, "selector_stepper_obj", None)):
                selector_stepper = self.unit_obj.selector_stepper_obj
                selector_endstop = self.endstops.get(AFCHomingPoints.SELECTOR)
                selector_endstop["endstop"].add_stepper(selector_stepper.extruder_stepper.stepper)
                selector_stepper._endstops[self.selector_endstop_name] = (selector_endstop["endstop"],
                                                                          selector_endstop["endstop_name"])

    def get_color(self):
        """
        Helper function for returning current color

        :return str: If TD-1 device is present, returns scanned color. If its not present, returns
                     manually entered or color from spoolman
        """
        color = self.color
        if "color" in self.td1_data:
            color = f"#{self.td1_data['color']}"
        return color

    @contextmanager
    def assist_move(self, speed, rewind, assist_active=True):
        """
        Starts an assist move and returns a context manager that turns off the assist move when it exist.
        :param speed:         The speed of the move
        :param rewind:        True for a rewind, False for a forward assist
        :param assist_active: Whether to assist
        :return:              the Context manager
        """
        if assist_active:
            if rewind:
                # Calculate Rewind Speed
                value = self.calculate_pwm_value(speed, True) * -1
            else:
                # Calculate Forward Assist Speed
                value = self.calculate_pwm_value(speed)

            # Clamp value to a maximum of 1
            if value > 1:
                value = 1

            self.espooler.assist(value)
        try:
            yield
        finally:
            if assist_active:
                self.espooler.assist(0)

    def move_auto_speed(self, distance):
        """
        Helper function for determining speed and accel from passed in distance

        :param distance: Distance to move filament
        """
        dist_hub_move_speed, dist_hub_move_accel, assist_active = self.get_speed_accel(mode=SpeedMode.NONE,
                                                                                       distance=distance)
        self.move(distance, dist_hub_move_speed, dist_hub_move_accel, assist_active)

    def get_speed_accel(self, mode: SpeedMode, distance=None) -> float:
        """
        Helper function to allow selecting the right speed and acceleration of movements
        mode (Enum SpeedMode): Identifies which speed to use.
        """
        if distance is not None and mode is SpeedMode.NONE:
            if abs(distance) > 200:
                return self.long_moves_speed, self.long_moves_accel, True
            else:
                return self.short_moves_speed, self.long_moves_accel, False
        else:
            if self.afc._get_quiet_mode() == True:
                return self.afc.quiet_moves_speed, self.short_moves_accel
            elif mode == SpeedMode.LONG:
                return self.long_moves_speed, self.long_moves_accel
            elif (mode == SpeedMode.SHORT
                  or mode == SpeedMode.CALIBRATION
                  or mode == SpeedMode.HUB):
                return self.short_moves_speed, self.short_moves_accel
            elif (mode == SpeedMode.DIST_HUB):
                return self.dist_hub_move_speed, self.dist_hub_move_accel
            else:
                return self.short_moves_speed, self.short_moves_accel

    def get_active_assist(self, distance, assist_active:AssistActive) -> bool:
        """
        Helper method to return boolean based off `AssistActive` enum and distance

        :param distance: Distance to move stepper, used to determine assist if using Dynamic assist mode
        :param assist_active: `AssistActive` enum to determine if assist will be active or not
        :return bool: Returns True if `AssistActive.YES` or `AssistActive.DYNAMIC` and distance > 200
        """
        assist = False
        if assist_active == AssistActive.YES:
            assist = True
        elif assist_active == AssistActive.DYNAMIC:
            assist = abs(distance) > 200
        return assist

    def is_direct_hub(self):
        """
        Helper function to see if hub for lane is 'direct' or 'direct_load' hub.

        :return boolean: True if hub for lane is 'direct' or 'direct_load'
        """
        return self.hub in VALID_DIRECT_HUB

    def is_direct_dist(self):
        """
        Helper method that returns True when dist_hub value should be used when loading to toolhead.

        :return boolean: True when lane is setup as "direct hub" or lanes hub has "use_dist_hub"
                         variable set to True
        """
        return (self.is_direct_hub()
                or (self.hub_obj and getattr(self.hub_obj, "use_dist_hub", False) ))

    def select_lane(self):
        """
        Helper function to select lane, calls unit lane selection function.
        """
        self.unit_obj.select_lane( self )

    def move(self, distance, speed, accel, assist_active=False):
        """
        Move the specified lane a given distance with specified speed and acceleration.
        This function calculates the movement parameters and commands the stepper motor
        to move the lane accordingly.
        Parameters:
        distance (float): The distance to move.
        speed (float): The speed of the movement.
        accel (float): The acceleration of the movement.
        """
        self.unit_obj.select_lane( self )
        with self.assist_move( speed, distance < 0, assist_active):
            if self.drive_stepper is not None:
                self.drive_stepper.move(distance, speed, accel, assist_active)

    def move_to(self, distance: float, speed_mode: SpeedMode,
                endstop:AFCHomingPoints=AFCHomingPoints.NONE,
                assist_active=AssistActive.NO, use_homing=True) -> tuple[bool, float|int, AFCMoveWarning]:
        """
        Helper method for calling stepper move_advance or home_to functions based
        off use_homing parameter

        :param distance: Distance to move stepper
        :param speed_mode: SpeedMode type to use when moving stepper
        :param endstop: When homing is enabled, used to specify which endstop to home to
        :param assist_active: AssistActive type to enable/disable espoolers when moving stepper
        :param use_homing: When enabled home_to logic is used, else move_advance logic is used
        :return tuple[bool, float|int, AFCMoveWarning]: A tuple containing:

            - Returns True if move was successful
            - Total distance moved
            - AFCMoveWarning.WARN set if movement moved is not within 300mm of total distance,
                  AFCMoveWarning.ERROR when error is detected during homing, AFCMoveWarning.NONE
                  when no error or not full movement detected. When homing is disabled, always returns
                  True, 0, AFCMoveWarning.NONE.
        """
        warn = AFCMoveWarning.NONE
        extruder_stepper = getattr(self, "extruder_stepper", None)
        drive_stepper_assist = None
        if (self.drive_stepper
            or extruder_stepper):
            if use_homing:
                if self.drive_stepper:
                    home_to = self.drive_stepper.home_to
                    # Capturing driver stepper assist_move method and replacing with lanes
                    # assist move so spooler motors are driven when using drive/stepper based units
                    drive_stepper_assist= self.drive_stepper.assist_move
                    self.drive_stepper.assist_move = self.assist_move
                else:
                    home_to = self.home_to
                # Add extra distance to homing move to guarantee that endstop is hit
                new_distance = distance + self.homing_overshoot
                if distance < 0:
                    new_distance = distance - self.homing_overshoot
                self.unit_obj.select_lane(self)
                speed, accel = self.get_speed_accel(speed_mode)
                try:
                    homed, mov_dis, error = home_to(endstop, new_distance, speed, accel,
                            distance > 0, assist_active=self.get_active_assist(distance,
                                                                               assist_active)
                    )
                finally:
                    # Restoring drive stepper assist move method
                    if drive_stepper_assist:
                        self.drive_stepper.assist_move = drive_stepper_assist
                if error:
                    warn = AFCMoveWarning.ERROR
                elif (abs(distance) - mov_dis) > self.homing_delta:
                    warn = AFCMoveWarning.WARN

                return homed, mov_dis, warn
            else:
                self.move_advanced(distance, speed_mode, assist_active )
                return True, 0, warn
        else:
            if self.extruder_obj.is_standalone():
                return True, 0, AFCMoveWarning.NONE
            else:
                return False, 0, AFCMoveWarning.ERROR


    def move_advanced(self, distance, speed_mode: SpeedMode, assist_active: AssistActive = AssistActive.NO):
        """
        Wrapper for move function and is used to compute several arguments
        to move the lane accordingly.

        :param distance: The distance to move.
        :param speed_mode: Identifies which speed to use.
        :param assist_active: Determines to force assist or to dynamically determine.
        """
        # Stepperless units have no drive stepper, so the move below would
        # silently no-op. Delegate to the unit's firmware-driven lane_move
        # instead when it provides one.
        unit_obj = getattr(self, 'unit_obj', None)
        if (unit_obj is not None
            and getattr(unit_obj, 'stepperless_drive', False)
            and hasattr(unit_obj, 'lane_move')):
            unit_obj.lane_move(self, distance, speed_mode)
            return

        speed, accel = self.get_speed_accel(speed_mode)

        assist = self.get_active_assist(distance, assist_active)

        self.move(distance, speed, accel, assist)

    def set_afc_prep_done(self):
        """
        set_afc_prep_done function should only be called once AFC PREP function is done. Once this
            function is called it sets afc_prep_done to True. Once this is done the prep_callback function will
            now load once filament is inserted.
        """
        self._afc_prep_done = True

    def _perform_infinite_runout(self):
        """
        Common function for infinite spool runout
            - Unloads current lane and loads the next lane as specified by runout variable.
            - Swaps mapping between current lane and runout lane so correct lane is loaded with T(n) macro
            - Once changeover is successful print is automatically resumed
        """
        self.status = AFCLaneState.NONE
        self.unit_obj.lane_not_ready(self)
        self.logger.info("Infinite Spool triggered for {}".format(self.name))
        empty_lane = self.afc.lanes.get(self.afc.current)

        if not empty_lane:
            self.afc.error.AFC_error(f"Error when looking up current lane:{self.afc.current}")
            return

        change_lane = self.afc.lanes.get(self.runout_lane)
        # Verifying lanes are valid before continuing
        if not change_lane:
            self.afc.error.AFC_error(f"Error when looking up runout lane:{self.runout_lane} for lane:{self.name}")
            return

        change_lane.status = AFCLaneState.INFINITE_RUNOUT
        # Pause printer with manual command
        self.afc.error.pause_resume.send_pause_command()
        # Saving position after printer is paused
        self.afc.save_pos()


        # Position will be restored after new lane loaded so that nozzle does not sit
        # on print while lane is unloading
        self.afc.CHANGE_TOOL(change_lane, restore_pos=False)

        # Only continue if a error did not happen
        if not self.afc.error_state:
            # Change Mapping
            self.gcode.run_script_from_command('SET_MAP LANE={} MAP={}'.format(change_lane.name, empty_lane.map))

            # Turn off runout extruder LEDs and turn on other extruder LEDs if extruders are
            # different
            if empty_lane.extruder_obj != change_lane.extruder_obj:
                empty_lane.extruder_obj.set_print_leds(0, quiet=True)
                change_lane.extruder_obj.set_print_leds(1, quiet=True)
                change_lane.unit_obj.lane_tool_loaded(change_lane)

            # Resume pos
            self.afc.restore_pos()
            # Resume with manual issued command
            self.afc.error.pause_resume.send_resume_command()
            # Set LED to not ready
            self.unit_obj.lane_not_ready(self)

    def _handle_auto_spool_switch(self):
        """
        Handle automatic spool switch triggered by weight threshold.
        Called via reactor.register_callback from update_weight_callback.
        """
        if self.afc.error_state or not self.afc.function.is_printing():
            return

        if self.runout_lane is not None:
            self._perform_infinite_runout()
        else:
            self._perform_pause_runout()

    def _perform_pause_runout(self):
        """
        Common function to pause print when runout occurs, fully unloads and ejects spool if specified by user
        """
        # Unload if user has set AFC to unload on runout
        if self.unit_obj.unload_on_runout:
            # Pause printer
            self.afc.error.pause_resume.send_pause_command()
            self.afc.save_pos()
            # self.gcode.run_script_from_command('PAUSE')
            self.afc.TOOL_UNLOAD(self)
            if not self.afc.error_state:
                self.afc.LANE_UNLOAD(self)
        # Pause print
        self.status = AFCLaneState.NONE
        if self.auto_switch_triggered:
            runout_method = "Minimum weight threshold reached"
        else:
            runout_method = "Runout triggered"
        msg = "{} for lane {} and runout lane is not setup to switch to another lane.".format(runout_method, self.name)
        msg += "\nPlease manually load next spool into toolhead and then hit resume to continue."
        self.unit_obj.lane_not_ready(self)
        self.afc.error.AFC_error(msg)

    def _prep_capture_td1(self):
        """
        Common function to grab TD-1 data once user inserts filament into a lane. Only happens if user has specified
        this by setting `capture_td1_when_loaded: True` and if hub is clear and toolhead is not loaded.
        """
        if self.td1_when_loaded:
            # Stepperless units capture TD-1 through their own feed path
            # (prep_post_load) rather than the stepper path below — let the
            # unit intercept here; a non-None return means it handled it.
            # Units without this hook (e.g. BoxTurtle) fall through unchanged.
            hook = getattr(self.unit_obj, 'prep_capture_td1', None)
            if hook is not None and hook(self) is not None:
                return
            if not self.hub_obj.state and self.afc.function.get_current_lane_obj() is None:
                self.get_td1_data()
            else:
                self.logger.info(f"Cannot get TD-1 data for {self.name}, either toolhead is loaded or hub shows filament in path")

    @property
    def load_state(self) -> bool:
        if (self.hub_obj is not None
            and hasattr(self.hub_obj, 'is_virtual_pin')
            and self.hub_obj.is_virtual_pin()):
            return self.loaded_to_hub
        else:
            return bool(self._load_state)

    @property
    def raw_load_state(self) -> bool:
        return bool(self._load_state)

    def selector_callback(self, eventtime: float, state):
        self._selector_state = state

    def load_callback(self, eventtime, state):
        self._load_state = state
        if (self.printer.state_message == 'Printer is ready'
            and self.unit_obj.type in ONLY_LOAD_TYPES):
            self.prep_state = state

    def handle_load_runout(self, eventtime, load_state):
        """
        Callback function for load switch runout/loading for HTLF, this is different than `load_callback`
        function as this function can be delayed and is called from filament_switch_sensor class when it detects a runout event.

        Before exiting `min_event_systime` is updated as this mimics how its done in `_exec_gcode` function in RunoutHelper class
        as AFC overrides `_runout_event_handler` function with this function callback. If `min_event_systime` does not get
        updated then future switch changes will not be detected.

        :param eventtime: Event time from the button press
        :param load_state: True if filament is present at the load switch, False otherwise
        """
        button = getattr(self, "load_debounce_button", None)
        if button:
            # Call filament sensor callback so that state is registered
            try:
                self.load_debounce_button._old_note_filament_present(is_filament_present=load_state)
            except:
                self.load_debounce_button._old_note_filament_present(eventtime, load_state)

        if (self.printer.state_message == 'Printer is ready'
            and self.unit_obj.type in ONLY_LOAD_TYPES
            and True == self._afc_prep_done):
            if load_state:
                # Stash any externally-staged spool (scanner -> next_spool_id)
                # before set_loaded() consumes it via _set_values, so a unit's
                # on_filament_insert (e.g. ACE, which clear_values()) can tell a
                # fresh scan apart from a stale/remembered id and keep it.
                self._afc_staged_spool_id = self.afc.spool.next_spool_id

                # TODO: maybe set_loaded can happen after the on_filament_insert call so next spool id
                # does not have to be stored into _afc_staged_spool_id. need to understand ACE logic better once impementing ACE
                self.set_loaded()
                # on_filament_insert only when this wasn't a suppressed
                # (operation-driven) state change.
                if not self._load_suppressed:
                    if hasattr(self.unit_obj, 'on_filament_insert'):
                        self.unit_obj.on_filament_insert(self)
                self._load_suppressed = False

                # Check if user wants to get TD-1 data when loading
                if (self.td1_device_id
                    and not self.tool_loaded):
                    self._prep_capture_td1()

                if self.hub == 'direct_load': # TODO: change to is_direct_hub
                    # Check to see if the printer is printing or moving, as trying to load while printer is doing something will crash klipper
                    if self.afc.function.is_printing(check_movement=True):
                        self.afc.error.AFC_error("Cannot load spool to toolhead while printer is actively moving or homing", False)
                    else:
                        self.afc.TOOL_LOAD(self)

                self._post_prep_user_macro()
            else:
                self.unit_obj.on_filament_remove(self)
                # Don't run if user disabled sensor in gui
                fila_load = getattr(self, 'fila_load', None)
                if (fila_load
                    and not fila_load.runout_helper.sensor_enabled
                    and self.afc.function.is_printing()):
                    self.logger.warning("Load runout has been detected, but pause and runout "
                                        "detection has been disabled")
                elif self.unit_obj.check_runout(self):
                    # Let the unit handle runout if it provides custom logic.
                    # handle_runout() returns True when it fully handled the
                    # runout itself, or False to defer to AFC's generic
                    # infinite-spool / pause behavior below.
                    handle_runout = getattr(self.unit_obj, "handle_runout", None)
                    handled = handle_runout(self) if handle_runout else False
                    if not handled:
                        # Checking to make sure runout_lane is set
                        if self.runout_lane is not None:
                            self._perform_infinite_runout()
                        else:
                            self._perform_pause_runout()
                elif self.status != "calibrating":
                    self.set_unloaded()

        self.afc.save_vars()

    def prep_callback(self, eventtime, state):
        self.prep_state = state

        delta_time = eventtime - self.last_prep_time
        self.last_prep_time = eventtime


        if self.prep_active:
            return

        if (self.printer.state_message == 'Printer is ready' and
            True == self._afc_prep_done and
            "direct_load" in self.hub and
            not self.afc.auto_home and
            not self.afc.function.is_homed()):
            self.afc.error.AFC_error("Please home printer before directly loading to toolhead", False)
            return False

        self.prep_active = True

        # Checking to make sure printer is ready and making sure PREP has been called before trying to load anything
        for i in range(1):
            # Hacky way for do{}while(0) loop, DO NOT return from this for loop, use break instead so that self.prep_state variable gets sets correctly
            #  before exiting function
            with self.mutex:
                if self.printer.state_message == 'Printer is ready' and self._afc_prep_done and self.status != AFCLaneState.TOOL_UNLOADING:
                    # Only try to load when load state trigger is false
                    if self.prep_state and not self.raw_load_state:
                        self.logger.debug(f"Prep: callback triggered {self.name}")
                        # Checking to make sure last time prep switch was activated was less than 1 second, returning to keep is printing message from spamming
                        # the console since it takes klipper some time to transition to idle when idle_resume=printing
                        if delta_time < 1.0:
                            break

                        # Check to see if the printer is printing or moving, as trying to load while printer is doing something will crash klipper
                        if self.afc.function.is_printing(check_movement=True):
                            self.afc.error.AFC_error(f"Cannot load {self.name} spool while printer is actively moving or homing", False)
                            self.prep_active = False
                            return

                        # Calling common load function
                        self.unit_obj.prep_load(self)

                        self.status = AFCLaneState.NONE
                        self.logger.debug(f"Prep: Load Done-{self.name}")

                        # Verify that load state is still true as this would still trigger if prep sensor was triggered and then filament was removed
                        #   This is only really a issue when using direct_load and still using load sensor
                        if self.hub == 'direct_load' and self.prep_state:
                            self.logger.debug(f"Prep: direct load logic-{self.name}-{self.hub}")
                            self.afc.TOOL_LOAD(self)
                            self.afc.spool._set_values(self)
                            self.logger.debug(f"Prep: direct load logic done-{self.name}-{self.hub}")
                            break

                        self.unit_obj.prep_post_load(self)

                        self.do_enable(False)
                        if (self.load_state
                            and self.prep_state):
                            self.set_loaded()
                            self._post_prep_user_macro()
                            # Check if user wants to get TD-1 data when loading
                            # TODO: When implementing multi-extruder this could still happen if a lane is loaded for a
                            # different extruder/hub
                            if self.td1_device_id:
                                self._prep_capture_td1()

                    elif (self.prep_state == True
                        and self.raw_load_state == True
                        and not self.afc.function.is_printing()):
                        message = 'Cannot load {} load sensor is triggered.'.format(self.name)
                        message += '\n    Make sure filament is not stuck in load sensor or check to make sure load sensor is not stuck triggered.'
                        if self.unit_obj.type == "ViViD":
                            message += f'\n    If filament is not stuck in sensor run AFC_RECOVER_LANE LANE={self.name}'
                            message += " to reset internal AFC state."
                        message += '\n    Once cleared try loading again'
                        self.afc.error.AFC_error(message, pause=False)
        self.prep_active = False
        self.afc.save_vars()

    def handle_prep_runout(self, eventtime, prep_state):
        """
        Callback function for prep switch runout, this is different than `prep_callback`
        function as this function can be delayed and is called from filament_switch_sensor class when it detects a runout event.

        Before exiting `min_event_systime` is updated as this mimics how its done in `_exec_gcode` function in RunoutHelper class
        as AFC overrides `_runout_event_handler` function with this function callback. If `min_event_systime` does not get
        updated then future switch changes will not be detected.

        :param eventtime: Event time from the button press
        """
        # Call filament sensor callback so that state is registered
        try:
            self.prep_debounce_button._old_note_filament_present(is_filament_present=prep_state)
        except:
            self.prep_debounce_button._old_note_filament_present(eventtime, prep_state)

        if (self.printer.state_message == 'Printer is ready'
            and True == self._afc_prep_done
            and self.status != AFCLaneState.TOOL_UNLOADING):
            if (prep_state == False
                and self.name == self.afc.current
                and self.afc.function.is_printing()
                and self.raw_load_state
                and self.status != AFCLaneState.EJECTING):
                # Don't run if user disabled sensor in gui
                if not self.fila_prep.runout_helper.sensor_enabled:
                    self.logger.warning("Prep runout has been detected, but pause and runout detection has been disabled")
                # Checking to make sure runout_lane is set
                elif self.runout_lane is not None:
                    self._perform_infinite_runout()
                else:
                    self._perform_pause_runout()
            elif not prep_state:
                # Filament is unloaded
                self.set_unloaded()

        self.afc.save_vars()

    def _post_prep_user_macro(self):
        """
        Function to call macro once filament has successfully been loaded during prep callback
        """
        if self.afc.function.check_macro_present(self.post_prep_macro):
            cmd = f"{self.post_prep_macro} LANE={self.name}"
            self.gcode.run_script_from_command(cmd)

    def do_enable(self, enable):
        if self.drive_stepper is not None:
            self.drive_stepper.do_enable(enable)

    def sync_print_time(self):
        return

    def sync_to_extruder(self, update_current=True):
        """
        Helper function to sync lane to extruder and set print current if specified.

        :param update_current: Sets current to specified print current when True
        """
        if self.drive_stepper is not None:
            self.drive_stepper.sync_to_extruder(update_current,
                                                th_extruder_name=self.extruder_obj.th_extruder_name)

    def unsync_to_extruder(self, update_current=True):
        """
        Helper function to un-sync lane to extruder and set load current if specified.

        :param update_current: Sets current to specified load current when True
        """
        if self.drive_stepper is not None:
            self.drive_stepper.unsync_to_extruder(update_current)

    def _set_current(self, current):
        return

    def set_load_current(self):
        """
        Helper function to update TMC current to use run current value
        """
        if self.drive_stepper is not None:
            self.drive_stepper.set_load_current()

    def set_print_current(self):
        """
        Helper function to update TMC current to use print current value
        """
        if self.drive_stepper is not None:
            self.drive_stepper.set_print_current()

    def update_rotation_distance(self, multiplier):
        if self.drive_stepper is not None:
            self.drive_stepper.update_rotation_distance( multiplier )

    def calculate_effective_diameter(self, weight_g, spool_width_mm=60):

        # Calculate the cross-sectional area of the filament
        density_g_mm3 = self.filament_density / 1000.0
        filament_volume_mm3 = weight_g / density_g_mm3
        package_corrected_volume_mm3 = filament_volume_mm3 / 0.785
        filament_area_mm2 = package_corrected_volume_mm3 / spool_width_mm
        spool_outer_diameter_mm2 = (4 * filament_area_mm2 / 3.14159) + self.inner_diameter ** 2
        spool_outer_diameter_mm = spool_outer_diameter_mm2 ** 0.5

        return spool_outer_diameter_mm

    def calculate_rpm(self, feed_rate):
        """
        Calculate the RPM for the assist motor based on the filament feed rate.

        :param feed_rate: Filament feed rate in mm/s
        :return: Calculated RPM for the assist motor
        """
        # Figure in weight of empty spool
        weight = self.weight + self.empty_spool_weight

        # Calculate the effective diameter
        effective_diameter = self.calculate_effective_diameter(weight)

        # Calculate RPM
        rpm = (feed_rate * 60) / (math.pi * effective_diameter)
        return min(rpm, self.max_motor_rpm)  # Clamp to max motor RPM

    def calculate_pwm_value(self, feed_rate, rewind=False):
        """
        Calculate the PWM value for the assist motor based on the feed rate.

        :param feed_rate: Filament feed rate in mm/s
        :return: PWM value between 0 and 1
        """
        rpm = self.calculate_rpm(feed_rate)
        if not rewind:
            pwm_value = rpm / (self.max_motor_rpm / (1 + 9 * self.fwd_speed_multi))
        else:
            pwm_value = rpm / (self.max_motor_rpm / (15 + 15 * self.rwd_speed_multi))
        return max(0.0, min(pwm_value, 1.0))  # Clamp the value between 0 and 1

    def enable_weight_timer(self):
        """
        Helper function to enable weight callback timer, should be called once a lane is loaded
        to extruder or extruder is switched for multi-toolhead setups.
        """
        self.past_extruder_position = self.afc.function.get_extruder_pos(
            None, self.past_extruder_position, self.extruder_obj.toolhead_extruder
        )
        self.reactor.update_timer( self.cb_update_weight, self.reactor.monotonic() + self.UPDATE_WEIGHT_DELAY)

    def disable_weight_timer(self):
        """
        Helper function to disable weight callback timer for lane and save variables
        to file. Should only be called when lane is unloaded from extruder or when
        swapping extruders for multi-toolhead setups.
        """
        self.update_weight_callback( None ) # get final movement before disabling timer
        self.reactor.update_timer( self.cb_update_weight, self.reactor.NEVER)
        self.past_extruder_position = -1
        self.save_counter = -1
        self.afc.save_vars()

    def update_weight_callback(self, eventtime):
        """
        Callback function for updating weight based on how much filament has been extruded

        :param eventtime: Current eventtime for timer callback
        :return int: Next time to call timer callback. Current time + UPDATE_WEIGHT_DELAY
        """
        extruder_pos = self.afc.function.get_extruder_pos(
            eventtime, self.past_extruder_position, self.extruder_obj.toolhead_extruder
        )
        delta_length = extruder_pos - self.past_extruder_position

        if -1 == self.past_extruder_position:
            self.past_extruder_position = extruder_pos

        self.save_counter += 1
        if extruder_pos > self.past_extruder_position:
            self.update_remaining_weight(delta_length)
            self.past_extruder_position = extruder_pos

            # Check if weight-based auto spool switch should trigger
            if (self.afc.auto_spool_switch
                and not self.auto_switch_triggered
                and self.weight > 0
                and self.weight <= self.afc.auto_spool_switch_threshold
                and self.name == self.afc.current
                and self.afc.function.is_printing()
                and not self.afc.error_state):
                self.auto_switch_triggered = True
                self.logger.info(
                    "Auto spool switch: {} weight ({:.1f}g) at or below "
                    "threshold ({:.1f}g), triggering switch".format(
                        self.name, self.weight, self.afc.auto_spool_switch_threshold))
                self.reactor.register_callback(
                    lambda et: self._handle_auto_spool_switch())

            # self.logger.debug(f"{self.name} Weight Timer Callback: New weight {self.weight}")

            # Save vars every 2 minutes
            if self.save_counter > 120/self.UPDATE_WEIGHT_DELAY:
                self.afc.save_vars()
                self.save_counter = 0

        return self.reactor.monotonic() + self.UPDATE_WEIGHT_DELAY

    def update_remaining_weight(self, distance_moved):
        """
        Update the remaining filament weight based on the filament distance moved.

        :param distance_moved: Distance of filament moved in mm.
        """
        filament_volume_mm3 = math.pi * (self.filament_diameter / 2) ** 2 * distance_moved
        filament_weight_change = filament_volume_mm3 * self.filament_density / 1000  # Convert mm cubed to g
        self.weight -= filament_weight_change

        # Weight cannot be negative, force back to zero if it's below zero
        if self.weight < 0:
            self.weight = 0

    def set_loaded(self):
        """
        Helper function for setting multiple variables when filament in loaded into lane
        """
        self.status = AFCLaneState.LOADED
        self.unit_obj.lane_loaded(self)
        self.afc.spool._set_values(self)

    def set_unloaded(self):
        """
        Helper function for setting multiple variables when filament is unloaded from lane
        """
        self.tool_loaded = False
        self.status = AFCLaneState.NONE
        self.loaded_to_hub = False
        self.td1_data = {}
        if not self.remember_spool:
            self.afc.spool.clear_values(self)
        self.unit_obj.lane_unloaded(self)

    def set_tool_loaded(self, normal_toolchange: bool=False):
        """
        Helper function for setting multiple variables when lane is loaded into toolhead

        :param normal_toolchange: Set to True when calling this function within the normal toolchange
          flow. When this is set to true AFC current_loading variable is updated and active spool id
          is set.
        """
        self.tool_loaded = True
        self.extruder_obj.lane_loaded = self.name
        self.status = AFCLaneState.TOOLED

        if normal_toolchange:
            self.afc.current_loading = None
            self.afc.spool.set_active_spool(self.spool_id)
        self.afc.spool.set_snapmaker_filament_params(self)

        self.unit_obj.lane_tool_loaded(self)

    def set_tool_unloaded(self, normal_toolchange: bool=False):
        """
        Helper function for setting multiple variables when lane is unloaded from toolhead

        :param normal_toolchange: Set to True when calling this function within the normal toolchange
          flow. When this is set to true AFC current_loading variable is updated and active spool id
          is unset.
        """
        self.tool_loaded = False
        self.extruder_obj.lane_loaded = None
        self.status = AFCLaneState.NONE

        if normal_toolchange:
            self.afc.current_loading = None
            self.afc.spool.set_active_spool(None)

        self.unit_obj.lane_tool_unloaded(self)

    def enable_buffer(self, disable_fault: bool=False):
        """
        Enable the buffer if `buffer_name` is set.
        Retrieves the buffer object and calls its `enable_buffer()` method to activate it.

        :param disable_fault: Set to True to disable fault detection when enabling buffer
        """
        if self.buffer_obj is not None:
            if disable_fault: self.buffer_obj.disable_fault_sensitivity()
            self.buffer_obj.enable_buffer(self)
        self.espooler.enable_timer()
        self.enable_weight_timer()

    def enable_fault_detection(self):
        """
        Helper function to restore fault sensitivity and enables buffer to reactivate
        fault timer and multiplier.
        """
        if self.buffer_obj is not None:
            self.buffer_obj.restore_fault_sensitivity()
            self.buffer_obj.enable_buffer(self)

    def disable_buffer(self):
        """
        Disable the buffer if `buffer_name` is set.
        Calls the buffer's `disable_buffer()` method to deactivate it.
        """
        if self.buffer_obj is not None:
            self.buffer_obj.disable_buffer()
        self.espooler.disable_timer()
        self.disable_weight_timer()

    def buffer_status(self):
        """
        Retrieve the current status of the buffer.
        If `buffer_name` is set, returns the buffer's status using `buffer_status()`.
        Otherwise, returns None.
        """
        if self.buffer_obj is not None:
            return self.buffer_obj.buffer_status()

        else: return None

    def get_toolhead_pre_sensor_state(self):
        """
        Helper function that returns current state of toolhead pre sensor or buffer if user has extruder setup for ramming

        returns Status of toolhead pre sensor or the current buffer advance state
        """
        if self.extruder_obj.tool_start == "buffer":
            return self.buffer_obj.advance_state
        else:
            return self.extruder_obj.tool_start_state

    def get_toolhead_endstop(self) -> str:
        """
        Helper method to lookup endstop type based on users config.

        :return AFCHomingPoints: Returns buffer endstop name if users tool_start is set to buffer
            else returns tool start endstop name
        """
        if self.extruder_obj.tool_start == "buffer":
            return self.buffer_endstop_name
        else:
            return self.tool_endstop_name

    def get_trailing(self):
        """
        Helper function to get trailing status, returns none if buffer is not defined
        """
        if self.buffer_obj is not None:
            return self.buffer_obj.trailing_state
        else: return None

    def activate_toolhead_extruder(self):
        if self.afc.toolhead.get_extruder() is self.extruder_obj.toolhead_extruder:
            # self.afc.gcode.respond_info("Extruder already active") #TODO remove before pushing to dev/main
            return
        else:
            # self.afc.gcode.respond_info("Activating extruder")
            # Code below is pulled exactly from klippy/kinematics/extruder.py file without the prints
            self.afc.toolhead.flush_step_generation()
            self.afc.toolhead.set_extruder( self.extruder_obj.toolhead_extruder, 0.)
            self.printer.send_event("extruder:activate_extruder")


    def _is_normal_printing_state(self):
        """
        Returns True if the lane is in a normal printing state (TOOLED or LOADED).
        Prevents runout logic from triggering during transitions or maintenance.
        """
        if self.afc.in_toolchange:
            return False
        return self.status in (AFCLaneState.TOOLED, AFCLaneState.LOADED)

    def handle_toolhead_runout(self, sensor=None):
        """
        Handles runout detection at the toolhead sensor.
        If all upstream sensors (prep, load, hub) still detect filament, this indicates a break or jam at the toolhead.
        Otherwise, triggers normal runout handling logic. Only triggers during normal printing states and when printing.
        :param sensor: Optional name of the triggering sensor for user notification.
        """
        # Only trigger runout logic if in a normal printing state, printer is actively printing
        # and toolhead is on shuttle for toolchangers
        if (not (self._is_normal_printing_state()
                and self.afc.function.is_printing()
                and self.extruder_obj.on_shuttle())):
            return

        # Check upstream sensors: prep, load, hub
        prep_ok = self.prep_state
        load_ok = self.raw_load_state
        hub_ok = True
        if self.hub_obj is not None:
            hub_ok = self.hub_obj.state

        # If all upstream sensors are still True, this is a break/jam at the toolhead
        if (prep_ok and load_ok and hub_ok
            and not self.extruder_obj.is_standalone()):
            msg = (
                f"Toolhead runout detected by {sensor} sensor, but upstream sensors still detect filament.\n"
                "Possible filament break or jam at the toolhead. Please clear the jam and reload filament manually, then resume the print."
            )
            self.afc.error.pause_resume.send_pause_command()
            self.afc.save_pos()
            self.afc.error.AFC_error(msg)
        else:
            # Don't run if user disabled sensor in gui
            sensor_obj = self.extruder_obj.fila_tool_start if sensor == "tool_start" else self.extruder_obj.fila_tool_end
            sensor_name = sensor if sensor else "toolhead"
            if not sensor_obj.runout_helper.sensor_enabled:
                self.logger.warning(f"{sensor_name} runout has been detected, but pause and runout detection has been disabled")
            elif (self.runout_lane is not None
                  and self.extruder_obj.is_standalone()):
                # TODO: For now this only works for standalone toolheads, more reboust toolhead
                # infinite runout can be added when resolving Issue #729. So for now if a toolhead
                # runsout and its not a standalone lane AFC will pause.
                self._perform_infinite_runout()
                # TODO: set tool unloaded here
            else:
                self._perform_pause_runout()

                if self.extruder_obj.is_standalone():
                    self.set_tool_unloaded()
                    self.set_unloaded()
                    self.afc.save_vars()

    def handle_hub_runout(self, sensor=None):
        """
        Handles runout detection at the hub sensor.
        If both upstream sensors (prep, load) still detect filament but hub does not, this indicates a break or jam at the hub.
        Otherwise, triggers normal runout handling logic. Only triggers during normal printing states and when printing.
        :param sensor: Optional name of the triggering sensor for user notification.
        """
        # Only trigger runout logic if in a normal printing state AND printer is actively printing
        if not (self._is_normal_printing_state() and self.afc.function.is_printing()):
            return

        # Check upstream sensors: prep, load
        prep_ok = self.prep_state
        load_ok = self.raw_load_state
        hub_ok = self.hub_obj.state if self.hub_obj is not None else False

        # If both upstream sensors are still True, but hub is not, this is a break/jam at the hub
        if prep_ok and load_ok and not hub_ok:
            msg = (
                f"Hub runout detected by {sensor or 'hub'} sensor, but upstream sensors still detect filament.\n"
                "Possible filament break or jam at the hub. Please clear the jam and reload filament manually, then resume the print."
            )
            self.afc.error.pause_resume.send_pause_command()
            self.afc.save_pos()
            self.afc.error.AFC_error(msg)
        # No else: do not trigger infinite runout or pause runout here

    # Toolchanger functions
    def tool_swap(self):
        """
        Helper function for calling extruder's tool_swap function
        """
        if self.extruder_obj.tc_unit_obj is not None:
            self.extruder_obj.tc_unit_obj.tool_swap(self, set_start_time=False)


    def send_lane_data(self):
        """
        Sends lane data to moonrakers `machine/set_lane_data` endpoint
        """
        if self.map is not None and "T" in self.map:
            scan_time = self.td1_data['scan_time'] if 'scan_time' in self.td1_data else ""
            td        = self.td1_data['td']        if 'td'        in self.td1_data else ""

            lane_data = {
                "namespace": "lane_data",
                "key": self.name,
                "value": {
                    "color"          : self.color,
                    "material"       : self.material,
                    "bed_temp"       : self.bed_temp,
                    "nozzle_temp"    : self.extruder_temp,
                    "scan_time"      : scan_time,
                    "td"             : td,
                    "lane"           : self.lane_index,
                    "extruder_index" : self.lane_extruder_index,
                    "spool_id"       : self.spool_id,
                    "weight"         : self.weight
                }
            }
            self.afc.moonraker.send_lane_data(lane_data)

    def clear_lane_data(self):
        """
        Clears lane data that is currently stored at moonrakers `machine/set_lane_data` endpoint
        """
        if self.map is not None and "T" in self.map:
            lane_data = {
                "namespace": "lane_data",
                "key": self.name,
                "value": {
                    "color"          : "",
                    "material"       : "",
                    "bed_temp"       : "",
                    "nozzle_temp"    : "",
                    "scan_time"      : "",
                    "td"             : "",
                    "lane"           : self.lane_index,
                    "extruder_index" : self.lane_extruder_index,
                    "spool_id"       : None
                }
            }
            self.afc.moonraker.send_lane_data(lane_data)

    def get_td1_data_load(self):
        """
        Captures TD-1 data for a lane after being loaded into toolhead. When capturing
        data scan time is ignored as its assumed its scanned when loaded into toolhead.
        """
        if self.afc.td1_present:
            valid = False
            if self.td1_device_id:
                valid, _ = self.afc.function.check_for_td1_id(self.td1_device_id)

            if valid:
                self.unit_obj.get_td1_data(self, datetime.now(), ignore_time=True)

    def get_td1_data(self):
        """
        Captures TD-1 data for lane. Has error checking to verify that lane is loaded, hub is not blocked
        and that TD-1 device is still detected before trying to capture data.

        :return tuple: (status, msg) where status is True if data was captured successfully
        """
        # Stepperless units can't use the stepper moves below — they feed to
        # the TD-1 device, read, then retract via their own protocol instead.
        # Delegate via capture_td1_data when present; a non-None (success, msg)
        # return means it handled it. Units without this hook (e.g. BoxTurtle)
        # fall through unchanged.
        hook = getattr(self.unit_obj, 'capture_td1_data', None)
        if hook is not None:
            result = hook(self)
            if result is not None:
                return result

        max_move_tries = 0
        status = True
        msg = ""

        if self.td1_device_id is None:
            msg = f"Cannot grab TD-1 data for {self.name}, td1_device_id is a required "
            msg += "field in AFC_hub or per AFC_lane"
            self.afc.error.AFC_error(msg, pause=False)
            return False, msg

        if self.td1_bowden_length is None:
            msg = f"td1_bowden_length is not set for {self.name}. "
            msg += "Please run AFC_CALIBRATION to calibrate TD1 length for "
            msg += "lane before trying to capture TD1 data."
            self.afc.error.AFC_error(msg, pause=False)
            return False, msg

        if not self.load_state and not self.prep_state:
            msg = f"{self.name} not loaded, cannot capture TD-1 data for lane"
            self.afc.error.AFC_error(msg, pause=False)
            return False, msg

        if self.hub_obj.state:
            msg = f"Hub for {self.name} detects filament, cannot capture TD-1 data for lane"
            self.afc.error.AFC_error(msg, pause=False)
            return False, msg

        if (self.is_direct_hub()
            and self.tool_loaded):
            msg = f"{self.name} loaded to toolhead, unload from toolhead before trying "
            msg += "to capture TD1 data."
            self.afc.error.AFC_error(msg, pause=False)
            return False, msg

        # Verify TD-1 is still connected before trying to get data
        valid, msg = self.afc.function.check_for_td1_id(self.td1_device_id)
        if not valid:
            self.afc.error.AFC_error(msg, pause=False)
            return False, msg
        else:
            error, msg = self.afc.function.check_for_td1_error()
            if error:
                return False, msg

        if not self.hub_obj.state:
            if not self.is_direct_hub():
                if not self.loaded_to_hub:
                    move_dis = self.dist_hub
                    if self.afc.homing_enabled:
                        move_dis += self.hub_obj.move_dis
                    self.unit_obj.move_to_hub(self, move_dis, MoveDirection.POS,
                                              self.afc.homing_enabled)
                    self.loaded_to_hub = True

                while not self.hub_obj.state:
                    if max_move_tries >= self.afc.max_move_tries:
                        fail_message = f"Failed to trigger hub {self.hub_obj.name} for {self.name}\n"
                        fail_message += "Cannot capture TD-1 data, verify that hub switch is properly working before continuing"
                        self.afc.error.AFC_error(fail_message, pause=False)
                        self.do_enable(False)
                        return False, fail_message

                    if max_move_tries == 0:
                        self.move_auto_speed(self.hub_obj.move_dis)
                    else:
                        self.move_auto_speed(self.short_move_dis)
                    max_move_tries += 1

            compare_time = datetime.now()
            self.move_auto_speed(self.td1_bowden_length)
            self.afc.reactor.pause(self.afc.reactor.monotonic() + 5)

            success = self.unit_obj.get_td1_data(self, compare_time)
            if not success:
                msg = f"Not able to gather TD-1 data after moving {self.td1_bowden_length}mm"
                self.afc.error.AFC_error(msg, pause=False)
                status = False

            self.unit_obj.move_to_hub(self, self.hub_obj.td1_bowden_length,
                                      MoveDirection.NEG,
                                      self.afc.homing_enabled,
                                      speed_mode=SpeedMode.LONG)
            if success:
                self.send_lane_data()

            if not self.is_direct_hub():
                max_move_tries = 0
                while( self.hub_obj.state ):
                    if max_move_tries >= self.afc.max_move_tries:
                        fail_message = f"Failed to un-trigger hub {self.hub_obj.name} for {self.name}\n"
                        fail_message += "Verify that hub switch is properly working before continuing"
                        self.afc.error.AFC_error(fail_message, pause=False)
                        self.do_enable(False)
                        return False, fail_message

                    self.move_auto_speed(self.short_move_dis * -1)
                    max_move_tries += 1

                self.move_auto_speed(self.hub_obj.hub_clear_move_dis * -1)
            self.unit_obj.return_to_home()
            self.do_enable(False)

        else:
            msg = "Cannot gather TD-1 data, hub sensor not clear. Please clear hub and try again."
            self.afc.error.AFC_error(msg, pause=False)
            status = False
        return status, msg

    cmd_SET_LANE_LOADED_help = "Sets current lane as loaded to toolhead, useful when manually loading lanes during prints if AFC detects an error when trying to unload/load a lane"
    cmd_SET_LANE_LOAD_options = {"LANE": {"type": "string", "default": "lane1"}}
    def cmd_SET_LANE_LOADED(self, gcmd):
        """
        This macro handles manually setting a lane loaded into the toolhead. This is useful when manually loading lanes
        during prints after AFC detects an error when loading/unloading and pauses.

        If there is a lane already loaded this macro will also desync that lane extruder from the toolhead extruder
        and set its values and led appropriately.

        Retrieves the lane specified by the 'LANE' parameter and sets the appropriate values in AFC to continue using the lane.

        Usage
        -----
        `SET_LANE_LOADED LANE=<lane>`

        Example
        -------
        ```
        SET_LANE_LOADED LANE=lane1
        ```
        """
        if not self.load_state:
            self.afc.error.AFC_error("Lane:{} is not loaded, ensure that the LOAD switch is properly configured and filament is detected.".format(self.name), pause=False)
            return

        # Do not set lane as loaded if virtual bypass or normal bypass is triggered
        if self.afc.get_bypass_state():
            disable_msg = ""
            detected_msg = " detects filament"
            msg = f"Cannot set {self.name} as loaded, "

            if 'virtual' in self.afc.bypass.name:
                msg += "virtual "
                detected_msg = " is enabled"
                disable_msg = " and disable"
            msg += f"bypass{detected_msg}.\nPlease unload{disable_msg} before trying to set lanes as loaded."
            self.logger.error(msg)
            return

        self.afc.function.unset_lane_loaded()

        self.afc.function.handle_activate_extruder()
        self.set_tool_loaded(normal_toolchange=True)
        self.sync_to_extruder()
        self.afc.save_vars()
        self.unit_obj.select_lane(self)
        self.logger.info("Manually set {} loaded to toolhead".format(self.name))

    cmd_SET_LONG_MOVE_SPEED_help = "Gives ability to set long_moves_speed or rev_long_moves_speed_factor values without having to update config and restart"
    def cmd_SET_LONG_MOVE_SPEED(self, gcmd):
        """
        Macro call to update long_moves_speed or rev_long_moves_speed_factor values without having to set in config and restart klipper. This macro allows adjusting
        these values while printing. Multiplier values must be between 0.5 - 1.2

        Use `FWD_SPEED` variable to set forward speed in mm/sec, use `RWD_FACTOR` to set reverse multiplier

        Usage
        -----
        `SET_LONG_MOVE_SPEED LANE=<lane_name> FWD_SPEED=<fwd_speed> RWD_FACTOR=<rwd_multiplier> SAVE=<0 or 1>`

        Example
        -----
        ```
        SET_LONG_MOVE_SPEED LANE=lane1 RWD_FACTOR=0.9 SAVE=1
        ```
        """
        update = gcmd.get_int("SAVE", 0, minval=0, maxval=2)
        old_long_moves_speed = self.long_moves_speed
        old_rev_long_moves_speed_factor= self.rev_long_moves_speed_factor

        self.long_moves_speed = gcmd.get_float("FWD_SPEED", self.long_moves_speed, minval=50, maxval=500)
        self.rev_long_moves_speed_factor = gcmd.get_float("RWD_FACTOR", self.rev_long_moves_speed_factor, minval=0.0, maxval=1.2)

        if self.rev_long_moves_speed_factor < 0.5: self.rev_long_moves_speed_factor = 0.5
        if self.rev_long_moves_speed_factor > 1.2: self.rev_long_moves_speed_factor = 1.2

        if self.long_moves_speed != old_long_moves_speed:
            self.logger.info("{name} forward speed set, New: {new}, Old: {old}".format(name=self.name, new=self.long_moves_speed, old=old_long_moves_speed))
        else:
            self.logger.info("{name} forward speed currently set to {new}".format(name=self.name, new=self.long_moves_speed))


        if self.rev_long_moves_speed_factor != old_rev_long_moves_speed_factor:
            self.logger.info("{name} reverse speed multiplier set, New: {new}, Old: {old}".format(name=self.name, new=self.rev_long_moves_speed_factor, old=old_rev_long_moves_speed_factor))
        else:
            self.logger.info("{name} reverse speed multiplier currently set to {new}".format(name=self.name, new=self.rev_long_moves_speed_factor))

        if update == 1:
            self.afc.function.ConfigRewrite(self.fullname, 'long_moves_speed',  self.long_moves_speed, '')
            self.afc.function.ConfigRewrite(self.fullname, 'rev_long_moves_speed_factor',  self.rev_long_moves_speed_factor, '')


    cmd_SET_SPEED_MULTIPLIER_help = "Gives ability to set fwd_speed_multiplier or rwd_speed_multiplier values without having to update config and restart"
    def cmd_SET_SPEED_MULTIPLIER(self, gcmd):
        """
        Macro call to update fwd_speed_multiplier or rwd_speed_multiplier values without having to set in config and restart klipper. This macro allows adjusting
        these values while printing.

        Use `FWD` variable to set forward multiplier, use `RWD` to set reverse multiplier

        After running this command run `SAVE_SPEED_MULTIPLIER LANE=<lane_name>` to save value to config file

        Usage
        -----
        `SET_SPEED_MULTIPLIER LANE=<lane_name> FWD=<fwd_multiplier> RWD=<rwd_multiplier>`

        Example
        -----
        ```
        SET_SPEED_MULTIPLIER LANE=lane1 RWD=0.9
        ```
        """
        updated = False
        old_fwd_value = self.fwd_speed_multi
        old_rwd_value = self.rwd_speed_multi

        self.fwd_speed_multi = gcmd.get_float("FWD", self.fwd_speed_multi, minval=0.0)
        self.rwd_speed_multi = gcmd.get_float("RWD", self.rwd_speed_multi, minval=0.0)

        if self.fwd_speed_multi != old_fwd_value:
            self.logger.info("{name} forward speed multiplier set, New: {new}, Old: {old}".format(name=self.name, new=self.fwd_speed_multi, old=old_fwd_value))
            updated = True

        if self.rwd_speed_multi != old_rwd_value:
            self.logger.info("{name} reverse speed multiplier set, New: {new}, Old: {old}".format(name=self.name, new=self.rwd_speed_multi, old=old_rwd_value))
            updated = True

        if updated:
            self.logger.info("Run SAVE_SPEED_MULTIPLIER LANE={} to save values to config file".format(self.name))

    cmd_SAVE_SPEED_MULTIPLIER_help = "Saves fwd_speed_multiplier and rwd_speed_multiplier values to config file "
    def cmd_SAVE_SPEED_MULTIPLIER(self, gcmd):
        """
        Macro call to write fwd_speed_multiplier and rwd_speed_multiplier variables to config file for specified lane.

        Usage
        -----
        `SAVE_SPEED_MULTIPLIER LANE=<lane_name>`

        Example
        -----
        ```
        SAVE_SPEED_MULTIPLIER LANE=lane1
        ```
        """
        self.afc.function.ConfigRewrite(self.fullname, 'fwd_speed_multiplier', self.fwd_speed_multi, '')
        self.afc.function.ConfigRewrite(self.fullname, 'rwd_speed_multiplier', self.rwd_speed_multi, '')

    cmd_SET_HUB_DIST_help = "Helper to dynamically set distance between a lanes extruder and hub"
    def cmd_SET_HUB_DIST(self, gcmd):
        """
        This function adjusts the distance between a lanes extruder and hub. Adding +/- in front of the length will
        increase/decrease length by that amount. To reset length back to config value, pass in `reset` for length to
        reset to value in config file.

        Usage
        -----
        `SET_HUB_DIST LANE=<lane_name> LENGTH=+/-<fwd_multiplier>`

        Example
        -----
        ```
        SET_HUB_DIST LANE=lane1 LENGTH=+100
        ```
        """
        old_dist_hub = self.dist_hub

        length = gcmd.get("LENGTH", self.dist_hub)

        if length != old_dist_hub:
            self.dist_hub = self.afc.function._calc_length(self.config_dist_hub, self.dist_hub, length)
        msg =  "//{} dist_hub:\n".format(self.name)
        msg += '//   Config Length:   {}\n'.format(self.config_dist_hub)
        msg += '//   Previous Length: {}\n'.format(old_dist_hub)
        msg += '//   New Length:      {}\n'.format(self.dist_hub)
        self.logger.raw(msg)
        self.logger.info("Run SAVE_HUB_DIST LANE={} to save value to config file".format(self.name))

    cmd_SAVE_HUB_DIST_help = "Saves dist_hub value to config file "
    def cmd_SAVE_HUB_DIST(self, gcmd):
        """
        Macro call to write dist_hub variable to config file for specified lane.

        Usage
        -----
        `SAVE_HUB_DIST LANE=<lane_name>`

        Example
        -----
        ```
        SAVE_HUB_DIST LANE=lane1
        ```
        """
        self.afc.function.ConfigRewrite(self.fullname, 'dist_hub', self.dist_hub, '')

    cmd_AFC_SET_REMEMBER_SPOOL_help = "Set lane to remember ejected spool"
    def cmd_AFC_SET_REMEMBER_SPOOL(self, gcmd):
        """
        This function handles enabling/disabling the functionality to remember latest spool info after ejecting spool for a specified lane.
        The lane from 'LANE' parameter has its remember_spool updated to the value provided by the 'REMEMBER_SPOOL' parameter.

        Usage
        -----
        `AFC_SET_REMEMBER_SPOOL LANE=<lane> REMEMBER_SPOOL=<0|1>`

        Example
        -----
        ```
        AFC_SET_REMEMBER_SPOOL LANE=lane1 REMEMBER_SPOOL=1
        ```
        """
        old_remember_spool = bool(self.remember_spool)
        default_int = 1 if old_remember_spool else 0
        new_remember_spool = bool(gcmd.get_int("REMEMBER_SPOOL", default_int, minval=0, maxval=1))

        if new_remember_spool == old_remember_spool:
            self.logger.info(f"{self.name} remember_spool already set to {new_remember_spool}")
            return
        self.remember_spool = new_remember_spool

        # prevents issue where values are retained on next load when remember_me is set to false while lane is unloaded
        if not self.remember_spool and self.status == AFCLaneState.NONE:
            self.afc.spool.set_spoolID(self, None)

        try:
            self.afc.function.ConfigRewrite(self.fullname, "remember_spool", self.remember_spool, "")
            self.logger.info(
                f"{self.name} remember_spool changed: {old_remember_spool} -> {self.remember_spool}"
            )
        except Exception as e:
            self.logger.error(f"{self.name} failed to save remember_spool to config: {e}")

    cmd_AFC_RECOVER_LANE_help = "Command to help recover a lane without manually editing files when" \
                                " filament was removed when power was removed. This should only be called" \
                                " as last resort."
    cmd_AFC_RECOVER_LANE_options = {"LANE": {"type":"string", "default":"lane1"}}
    def cmd_AFC_RECOVER_LANE(self, gcmd):
        """
        Command to help recover a lane without manually editing files when filament was removed when
        power was removed. This should only be called as last resort.

        Usage
        -----
        `AFC_RECOVER_LANE LANE=<lane>`

        Example
        -----
        ```
        AFC_RECOVER_LANE LANE=lane1
        ```
        """
        # This will move to common function call once merged with multi_extruder branch
        self.tool_loaded = False
        self.status = AFCLaneState.NONE
        self.loaded_to_hub = False
        self.td1_data = {}
        if not self.remember_spool:
            self.afc.spool.clear_values(self)
        self.unit_obj.lane_unloaded(self)
        self.logger.info(f"{self.name} reset")
        self.afc.save_vars()

    def get_status(self, eventtime=None, save_to_file=False):
        response = {}
        if not self.connect_done: return response
        response['name'] = self.name
        response['unit'] = self.unit
        response['hub'] = self.hub
        response['extruder'] = self.afc_extruder_name
        response['buffer'] = self.buffer_name
        response['buffer_status'] = self.buffer_status()
        response['lane'] = self.index
        response['map'] = self.map
        response['load'] = self.load_state
        response["prep"] =bool(self.prep_state)
        if self._selector_state is not None:
            response["selector"] = bool(self._selector_state)
        response["tool_loaded"] = self.tool_loaded
        response["loaded_to_hub"] = self.loaded_to_hub
        response["material"]=self.material
        if save_to_file:
            response["density"]=self.filament_density
            response["diameter"]=self.filament_diameter
            response["empty_spool_weight"]=self.empty_spool_weight
            response["need_purge"] = self.need_purge

        response["remember_spool"]= bool(self.remember_spool)
        response["spool_id"]= int(self.spool_id) if self.spool_id else None
        response["color"]=self.color
        if not save_to_file:
            response["filament_name"] = self.filament_name
            response["multi_color_hexes"] = self.multi_color
            response["initial_weight"] = self.espooler.espooler_values.full_weight

        response["weight"]=self.weight
        response["extruder_temp"] = self.extruder_temp
        response["bed_temp"] = self.bed_temp
        response["runout_lane"]=self.runout_lane
        filament_stat=self.afc.function.get_filament_status(self).split(':')
        response['filament_status'] = filament_stat[0]
        response['filament_status_led'] = filament_stat[1]
        response['status']          = self.status
        response['dist_hub']        = self.dist_hub

        if save_to_file:
            response['td1_data']        = self.td1_data
        else:
            response['td1_td']          = self.td1_data['td'] if "td" in self.td1_data else ''
            response['td1_color']       = self.td1_data['color'] if "color" in self.td1_data else ''
            response['td1_scan_time']   = self.td1_data['scan_time'] if "scan_time" in self.td1_data else ''

        if hasattr(self, "_endstops"):
            response["endstops"] = ",".join(self._endstops.keys())

        return response

class AFCU1Lane(AFCLane):
    def __init__(self, config: ConfigWrapper):
        """
        Initializes lane and, for standalone U1 lanes with no AFC prep/load
        switch, configures the external-feeder prep/load source and subscribes to
        its presence events.

        :param config: Klipper config object for this lane's config section
        """
        super().__init__(config)

        # Standalone lanes (e.g. U1) have no AFC prep/load switch; an external
        # feeder module ([filament_feed left|right]) reports filament presence
        # per channel instead. feed_module/feed_channel point at that channel,
        # and this lane mirrors the feeder's presence into prep_state/_load_state.

        # 'left' or 'right'
        self.feed_module  = config.get('feed_module', None)
        # AFC extruder name ('e1') or raw feeder key ('extruder1')
        self.feed_channel = config.get('feed_channel', None)
        self._feed_obj = None
        self._feed_ch_index = None       # int channel index the feeder event carries
        self._feed_staged_last = None
        if (self.feed_module
            and self.feed_channel):
            self._load_state = False    # driven by the feeder, not a load switch
            # Register event call back
            self.printer.register_event_handler("filament_feed:port", self._feed_port_event)

    def _handle_ready(self):
        """
        Klippy ready callback. Runs base AFCLane setup, then resolves the
        configured feeder module/channel and seeds prep/load state from its
        current status.

        raises error if feed_module/feed_channel are set but the
        [filament_feed <feed_module>] object is not found
        """
        super()._handle_ready()
        if (self.feed_module
            and self.feed_channel):
            self._feed_obj = self.printer.lookup_object(f"filament_feed {self.feed_module}", None)
            if self._feed_obj is None:
                error_str = (f"Lane {self.name}: [filament_feed {self.feed_module}] not found for "
                            "feed_module")
                raise error(error_str)
            # feed_channel may name an AFC_extruder (e.g. 'e2'); resolve it to the
            # feeder's channel key 'extruder<index>' (e0 -> 'extruder0'). A raw
            # feeder key is used as-is.
            ext_obj = self.printer.lookup_object(f"AFC_extruder {self.feed_channel}", None)
            if ext_obj is not None:
                kext = getattr(ext_obj, 'toolhead_extruder', None)
                idx = getattr(kext, 'extruder_index', None)
                if idx is None:
                    suffix = getattr(ext_obj, 'th_extruder_name', 'extruder')[len('extruder'):]
                    idx = int(suffix) if suffix.isdigit() else 0
                self.feed_channel = f"extruder{idx}"
            suffix = self.feed_channel[len('extruder'):]
            self._feed_ch_index = int(suffix) if suffix.isdigit() else None
            self._feed_reevaluate()    # seed from current feeder state at startup

    def _feed_channel_present(self):
        """
        Checks whether the feeder currently reports filament present in this
        lane's channel.

        :return bool: True when the feeder reports filament present, False if
                      absent, not found, or the feeder can't be queried
        """
        try:
            ch = self._feed_obj.get_status(self.reactor.monotonic()).get(self.feed_channel, {})
        except Exception:
            return False
        return ch.get('filament_detected') is True

    def _feed_port_event(self, channel_index:int, detected: bool):
        """
        Callback for the feeder's "filament_feed:port" presence-change event.

        :param channel_index: Feeder channel index the event fired for
        :param detected: Presence flag from the event; unused, since presence
                         is always re-read from the feeder's current status
        """
        if (self._feed_ch_index is not None
            and channel_index != self._feed_ch_index):
            return

        self.afc.logger.debug(f"AFCU1Lane: feed_port_event: {self.name} {detected}")
        self._apply_staged(detected)

    def _feed_reevaluate(self):
        """
        Re-reads the feeder's current channel state and mirrors it into
        prep_state/_load_state.
        """
        self._apply_staged(self._feed_channel_present())

    def _apply_staged(self, staged: bool):
        """
        Mirrors feeder presence into prep_state/_load_state, persisting the
        change only when it differs from the last-applied state.

        :param staged: True if the feeder channel currently has filament
                       present, False if not
        """
        if staged != self._feed_staged_last:
            self._feed_staged_last = staged
            self.prep_state = staged
            self._load_state = staged
            self.afc.save_vars()

def load_config_prefix(config: ConfigWrapper):
    return AFCLane(config)
