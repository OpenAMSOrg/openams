# Armored Turtle Automated Filament Control
#
# Copyright (C) 2024-2026 Armored Turtle
#
# This file may be distributed under the terms of the GNU GPLv3 license.
from __future__ import annotations

import traceback

from configparser import Error as error
from datetime import datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from extras.AFC_lane import AFCLane, MoveDirection
    from extras.AFC_stepper import AFCExtruderStepper

try: from extras.AFC_utils import ERROR_STR
except: raise error("Error when trying to import AFC_utils.ERROR_STR\n{trace}".format(trace=traceback.format_exc()))

try: from extras.AFC_lane import (
    AFCLaneState, SpeedMode, AssistActive, MoveDirection, AFCMoveWarning
)
except: raise error(ERROR_STR.format(import_lib="AFC_lane", trace=traceback.format_exc()))

try: from extras.AFC_unit import afcUnit
except: raise error(ERROR_STR.format(import_lib="AFC_unit", trace=traceback.format_exc()))

class afcBoxTurtle(afcUnit):
    MAX_NUM_MOVES = 40
    def __init__(self, config):
        super().__init__(config)
        self.type = config.get('type', 'Box_Turtle')

    def handle_connect(self):
        """
        Handle the connection event.
        This function is called when the printer connects. It looks up AFC info
        and assigns it to the instance variable `self.afc`.
        """
        super().handle_connect()

        firstLeg = '<span class=warning--text>|</span><span class=error--text>_</span>'
        secondLeg = firstLeg + '<span class=warning--text>|</span>'
        self.logo ='<span class=success--text>R  _____     ____\n'
        self.logo+='E /      \\  |  </span><span class=info--text>o</span><span class=success--text> | \n'
        self.logo+='A |       |/ ___/ \n'
        self.logo+='D |_________/     \n'
        self.logo+='Y {first}{second} {first}{second}\n'.format(first=firstLeg, second=secondLeg)
        self.logo+= '  ' + self.name + '\n'

        self.logo_error ='<span class=error--text>E  _ _   _ _\n'
        self.logo_error+='R |_|_|_|_|_|\n'
        self.logo_error+='R |         \\____\n'
        self.logo_error+='O |              \\ \n'
        self.logo_error+='R |          |\\ <span class=secondary--text>X</span> |\n'
        self.logo_error+='! \\_________/ |___|</span>\n'
        self.logo_error+= '  ' + self.name + '\n'

    def _move_lane(self, lane: AFCLane|AFCExtruderStepper, delay: float,
                   enable_movement: bool=True) -> bool:
        """
        Helper method to move BoxTurtle's lane forward then backward

        :param lane: Lane to move and check if filament is present.
        :param delay: Delay amount to wait between the forward then backward movements.
        :param enable_movement: When True movement is enabled, if False movement is disabled and
                                a delay happens instead.
        :return: Returns current lanes load state
        """
        if enable_movement:
            lane.move(5, self.afc.short_moves_speed, self.afc.short_moves_accel, True)
            self.afc.reactor.pause(self.afc.reactor.monotonic() + delay)
            lane.move(-5, self.afc.short_moves_speed, self.afc.short_moves_accel, True)
        else:
            self.afc.reactor.pause(self.afc.reactor.monotonic() + 0.7)
        return lane.load_state

    def system_Test(self, cur_lane: AFCLane|AFCExtruderStepper, delay, assignTcmd, enable_movement):
        msg = ''
        succeeded = True

        # Run test reverse/forward on each lane
        cur_lane.unsync_to_extruder(False)
        loaded = self._move_lane(cur_lane, delay, enable_movement)

        if not cur_lane.prep_state:
            if not loaded:
                self.afc.function.afc_led(cur_lane.led_not_ready, cur_lane.led_index)
                msg += 'EMPTY READY FOR SPOOL'
            else:
                self.lane_fault(cur_lane)
                msg +="<span class=error--text> NOT READY</span>"
                cur_lane.do_enable(False)
                msg = '<span class=error--text>CHECK FILAMENT Prep: False - Load: True</span>'
                succeeded = False

        else:
            self.lane_loaded(cur_lane)
            msg +="<span class=success--text>LOCKED</span>"
            if not loaded:
                msg +="<span class=error--text> NOT LOADED</span>"
                self.lane_not_ready(cur_lane)
                succeeded = False
            else:
                cur_lane.status = AFCLaneState.LOADED
                msg +="<span class=success--text> AND LOADED</span>"
                self.lane_illuminate_spool(cur_lane)

                if (cur_lane.tool_loaded
                    and cur_lane.extruder_obj.lane_loaded == cur_lane.name):
                    ramming_loaded = False
                    if cur_lane.extruder_obj.tool_start == "buffer":
                        ramming_loaded = self._buffer_toolhead_load_check(cur_lane)
                    if (cur_lane.get_toolhead_pre_sensor_state() == True
                        or ramming_loaded
                        or cur_lane.extruder_obj.tool_end_state):
                        if cur_lane.extruder_obj.lane_loaded == cur_lane.name:
                            cur_lane.sync_to_extruder()

                            msg += cur_lane.extruder_obj.prep_on_shuttle_check(cur_lane)

                            if (cur_lane.extruder_obj.tool_start == "buffer"
                                and (not self.afc.homing_enabled
                                     or not cur_lane.unit_obj.enable_buffer_tool_check)):
                                msg += "<span class=warning--text>\n Ram sensor enabled, confirm tool is loaded</span>"

                            if self.afc.current == cur_lane.name:
                                self.afc.spool.set_active_spool(cur_lane.spool_id)
                                self.lane_tool_loaded(cur_lane)
                                cur_lane.status = AFCLaneState.TOOLED
                            else:
                                self.lane_tool_loaded_idle(cur_lane)

                            cur_lane.enable_buffer()
                        else:
                            if cur_lane.get_toolhead_pre_sensor_state() == True or cur_lane.extruder_obj.tool_end_state:
                                msg +="<span class=error--text> error in ToolHead. \nLane identified as loaded \n but not identified as loaded in extruder</span>"
                                succeeded = False
                    else:
                        lane_check=self.afc.error.fix('toolhead', cur_lane)  #send to error handling
                        if not lane_check:
                            return False

        if assignTcmd: self.afc.function.TcmdAssign(cur_lane)

        # Now that a T command is assigned, send lane data to moonraker
        cur_lane.send_lane_data()

        cur_lane.do_enable(False)
        self.logger.info( '{lane_name} tool cmd: {tcmd:3} {msg}'.format(lane_name=cur_lane.name, tcmd=cur_lane.map, msg=msg))
        cur_lane.set_afc_prep_done()

        return succeeded

    def calibrate_bowden(self, cur_lane, dis, tol):
        cur_extruder = cur_lane.extruder_obj
        cur_hub = cur_lane.hub_obj
        if cur_lane.is_direct_hub():
            self.logger.raw(f'Calibrating dist_hub Length for {cur_lane.name}')
        else:
            self.logger.raw(f'Calibrating Bowden Length with {cur_lane.name}')

        # Store variable locally so check only happens once
        is_direct_dist = cur_lane.is_direct_dist()

        checkpoint = "Moving to hub"
        if not is_direct_dist:
            # move to hub and retrieve that distance, the checkpoint returned and if successful

            if not self.afc.homing_enabled:
                hub_pos, checkpoint, success = self.move_until_state(cur_lane, lambda: cur_hub.state,
                                                                     cur_hub.move_dis, tol,
                                                                     cur_lane.short_move_dis,
                                                                     0, cur_lane.dist_hub + 200,
                                                                     checkpoint)
            else:
                success, hub_pos, _ = cur_lane.unit_obj.move_to_hub(cur_lane, cur_lane.dist_hub+200,
                                                                    MoveDirection.POS,
                                                                    self.afc.homing_enabled,
                                                                    speed_mode=SpeedMode.CALIBRATION)
            bowden_length = cur_hub.afc_bowden_length
            variable_name = "afc_bowden_length"
            fullname = cur_hub.fullname
            fault_dis = bowden_length + 500
        else:
            checkpoint = "retract to extruder"
            if not self.afc.homing_enabled:
                hub_pos, checkpoint, success = self.calc_position(cur_lane,
                                                                  lambda: cur_lane.raw_load_state, 0,
                                                                  cur_lane.short_move_dis,
                                                                  tol, cur_lane.dist_hub + 100,
                                                                  checkpoint)
            else:
                success, hub_pos, _ = cur_lane.unit_obj.move_to_load(cur_lane, cur_lane.dist_hub+100,
                                                                     MoveDirection.NEG,
                                                                     self.afc.homing_enabled,
                                                                     speed_mode=SpeedMode.CALIBRATION)

            bowden_length = cur_lane.dist_hub
            variable_name = "dist_hub"
            fullname = cur_lane.fullname
            fault_dis = bowden_length + 500

        if not success:
            # if movement does not succeed fault and return values to calibration macro
            msg = 'Failed {} after {}mm'.format(checkpoint, hub_pos)
            return False, msg, hub_pos

        bow_pos = 0
        if cur_extruder.tool_start:
            # if tool_start is defined move and confirm distance
            while not cur_lane.get_toolhead_pre_sensor_state():
                if self.afc.homing_enabled:
                    dis = fault_dis
                homed, distance, warn = cur_lane.move_to(distance=dis,
                                                         speed_mode=SpeedMode.CALIBRATION,
                                                         endstop=cur_lane.get_toolhead_endstop(),
                                                         use_homing=self.afc.homing_enabled)
                # Check for error and return, if error state is set then AFC tried pausing
                # during the homing
                if warn == AFCMoveWarning.ERROR:
                    return False, "Error occurred when trying to move lane", fault_dis
                bow_pos += distance
                self.afc.reactor.pause(self.afc.reactor.monotonic() + 0.1)
                if bow_pos >= fault_dis:
                    # fault if move to bowden length does not reach toolhead sensor return to calibration macro
                    msg = 'while moving to toolhead. Failed after {}mm, '.format(bow_pos)
                    msg += 'if filament stopped short of the toolhead sensor/ramming during calibration'
                    msg += 'use the following command to increase bowden length'
                    if not is_direct_dist:
                        msg += '\n SET_BOWDEN_LENGTH HUB={} LENGTH=+(distance the filament was short from the toolhead)'.format(cur_hub.name)
                    else:
                        msg += '\n SET_HUB_DIST LANE={} LENGTH=+(distance the filament was short from the toolhead)'.format(cur_lane.name)
                    return False, msg, bow_pos

            if (cur_extruder.tool_start != 'buffer'
                and not self.afc.homing_enabled):
                # is using ramming, only use first trigger of sensor
                bow_pos, checkpoint, success = self.calc_position(cur_lane, lambda: cur_lane.get_toolhead_pre_sensor_state(), bow_pos,
                                                                  cur_lane.short_move_dis, tol, 100, "retract from toolhead sensor")

            if not success:
                # fault if check is not successful
                msg = 'Failed {} after {}mm'.format(checkpoint, bow_pos)
                return False, msg, bow_pos

            if not is_direct_dist:
                success, _, _ = cur_lane.unit_obj.move_to_hub(cur_lane, bow_pos, MoveDirection.NEG,
                                                              self.afc.homing_enabled,
                                                              speed_mode=SpeedMode.LONG)
            else:
                success, _, _ = cur_lane.unit_obj.move_to_load(cur_lane, bow_pos, MoveDirection.NEG,
                                                               self.afc.homing_enabled)
            if not success:
                return False, "Failed to home filament back to hub", fault_dis

            if (not self.afc.homing_enabled
                and not is_direct_dist):
                success, message, hub_dis = self.calibrate_hub(cur_lane, tol)

                if not success:
                    return False, message, hub_dis

            if not cur_lane.is_direct_hub():
                cur_lane.move(cur_hub.hub_clear_move_dis * -1, cur_lane.short_moves_speed,
                              cur_lane.short_moves_accel, True)
            else:
                # When direct lane move forwards so that load sensor is still triggered
                cur_lane.move(cur_lane.short_move_dis*4, cur_lane.short_moves_speed,
                              cur_lane.short_moves_accel, True)

            bowden_dist = round(bow_pos, 2)
            if not self.afc.homing_enabled:
                if cur_extruder.tool_start == 'buffer':
                    bowden_dist = round(bow_pos - (cur_lane.short_move_dis * 2), 2)
                else:
                    bowden_dist = round(bow_pos - cur_lane.short_move_dis, 2)

            unload_cal_msg = ''
            cal_msg = f'\n {variable_name}: New: {bowden_dist} Old: {bowden_length}'
            if not is_direct_dist:
                unload_cal_msg = f'\n afc_unload_bowden_length: New: {bowden_dist} Old: {cur_lane.hub_obj.afc_unload_bowden_length}'
                cur_lane.hub_obj.afc_unload_bowden_length = cur_lane.hub_obj.afc_bowden_length = bowden_dist
            else:
                cur_lane.dist_hub = bowden_dist

            if bowden_dist < 0:
                self.afc.error.AFC_error(
                    "'{}' is not a valid length. Please check your setup and re-run calibration.".format(bowden_dist),
                    pause=False)
                return False, "Invalid bowden length", bowden_dist
            self.afc.function.ConfigRewrite(fullname, variable_name, bowden_dist, cal_msg)
            if not is_direct_dist:
                self.afc.function.ConfigRewrite(fullname, "afc_unload_bowden_length", cur_lane.hub_obj.afc_unload_bowden_length, unload_cal_msg)
                cur_lane.loaded_to_hub  = True

            cur_lane.do_enable(False)
            cur_lane.unit_obj.return_to_home()
            self.afc.save_vars()
            return True, f"{variable_name} successful", bowden_dist
        else:
            self.logger.info('CALIBRATE_AFC is not currently supported without tool start sensor')
            return False, "CALIBRATE_AFC is not currently supported without tool start sensor", 0

    def calibrate_td1(self, cur_lane, dis, tol):
        """
        Calibration function for automatically determining td1_bowden_length

        :param cur_lane: Lane to use for calibration
        :param dis: Distance step to move when calibrating
        :param tol: Tolerance for fine adjustments during calibration, only used when moving filament to hub

        :return success,message,length: Returns tuple, when successful returns True,message, and length of bowden to TD-1
                                        When error occurs, returns False,message, and length of current bowden before error occurred
        """
        bow_pos = 0
        cur_hub = cur_lane.hub_obj

        if cur_lane.td1_device_id is None:
            msg = f"Cannot calibrate TD-1 for {cur_lane.name}, td1_device_id is a required "
            msg += "field in AFC_hub or per AFC_lane"
            return False, msg, 0

        # Store variable locally so check only happens once
        is_direct_dist = cur_lane.is_direct_dist()

        # Verify TD-1 is still connected before trying to get data
        valid, msg = self.afc.function.check_for_td1_id(cur_lane.td1_device_id)
        if not valid:
            msg = f"TD-1 device(SN: {cur_lane.td1_device_id}) not detected anymore, "
            msg += "please check before continuing to calibrate TD-1 bowden length"
            return valid, msg, 0

        self.logger.raw(f"Calibrating bowden length to TD-1 device with {cur_lane.name}")
        if not cur_lane.is_direct_hub():
            fault_dis = cur_lane.dist_hub + cur_lane.hub_obj.move_dis + 200
            hub_pos, checkpoint, success = self.move_until_state(cur_lane, lambda: cur_hub.state,
                                                                 cur_hub.move_dis, tol,
                                                                 cur_lane.short_move_dis, 0,
                                                                 fault_dis,
                                                                 "Moving to hub")

            if not success:
                # if movement does not succeed fault and return values to calibration macro
                msg = 'Failed {} after {}mm'.format(checkpoint, hub_pos)
                cur_lane.do_enable(False)
                return False, msg, hub_pos

        compare_time = datetime.now()
        max_bowden_length = 0
        if is_direct_dist:
            max_bowden_length = cur_lane.dist_hub
        else:
            max_bowden_length = cur_hub.afc_bowden_length
        while not self.get_td1_data(cur_lane, compare_time):
            if bow_pos > max_bowden_length:
                # fault if move to TD-1 is not detected
                msg = 'TD-1 failed to detect filament after moving {}mm'.format(bow_pos)
                cur_lane.do_enable(False)
                return False, msg, bow_pos

            compare_time = datetime.now()
            bow_pos += dis

            cur_lane.move(dis, self.short_moves_speed, self.short_moves_accel)
            self.afc.reactor.pause(self.afc.reactor.monotonic() + 5)
        if not is_direct_dist:
            success, _, _ = cur_lane.unit_obj.move_to_hub(cur_lane, bow_pos,
                                                          MoveDirection.NEG,
                                                          self.afc.homing_enabled,
                                                          speed_mode=SpeedMode.LONG)
        else:
            success, _, _ = cur_lane.unit_obj.move_to_load(cur_lane, bow_pos,
                                                           MoveDirection.NEG,
                                                           self.afc.homing_enabled)

        if (not self.afc.homing_enabled
            and not is_direct_dist):
            # Reset to hub
            self.calc_position(cur_lane, lambda: cur_lane.hub_obj.state, 0,
                                 cur_lane.short_move_dis, tol, 200, checkpoint)

        if not cur_lane.is_direct_hub():
            cur_lane.move(cur_hub.hub_clear_move_dis * -1, cur_lane.short_moves_speed, cur_lane.short_moves_accel, True)
        else:
            # When direct lane move forwards so that load sensor is still triggered
            cur_lane.move(cur_lane.short_move_dis*4, cur_lane.short_moves_speed,
                            cur_lane.short_moves_accel, True)

        cal_msg = f"\n td1_bowden_length: New: {bow_pos} Old: {cur_lane.td1_bowden_length}"

        if is_direct_dist:
            cur_lane.td1_bowden_length = bow_pos
            fullname = cur_lane.fullname
        else:
            cur_hub.td1_bowden_length = bow_pos
            fullname = cur_hub.fullname

        self.afc.function.ConfigRewrite(fullname, "td1_bowden_length", bow_pos, cal_msg)
        cur_lane.do_enable(False)
        cur_lane.unit_obj.return_to_home()
        self.afc.save_vars()
        return True, "td1_bowden_length calibration successful", bow_pos

    # Helper functions for movement and calibration
    def calibrate_hub(self, cur_lane, tol):
        hub_pos = 0
        msg = ''
        hub_fault_dis = cur_lane.dist_hub + 150
        checkpoint = 'hub calibration {}'.format(cur_lane.name)
        # move until hub sensor is triggered and get information
        hub_pos, checkpoint, success = self.move_until_state(cur_lane, lambda: cur_lane.hub_obj.state,
                                                             cur_lane.hub_obj.move_dis, tol,
                                                             cur_lane.short_move_dis, hub_pos,
                                                             hub_fault_dis, checkpoint)

        if not success:
            # fault if check is not successful
            msg = f'Failed to calibrate dist_hub for {cur_lane.name} after moving {hub_pos}mm. '
            msg += 'If filament stopped short of the hub during calibration use the following command to increase dist_hub value.'
            msg += f' SET_HUB_DIST LANE={cur_lane.name} LENGTH=+(distance the filament was short from the hub)'
            return False, msg, hub_pos

        hub_dist = cur_lane.dist_hub + 500
        # verify hub distance
        tuned_hub_pos, checkpoint, success = self.calc_position(cur_lane, lambda: cur_lane.hub_obj.state,
                                                                hub_pos, cur_lane.short_move_dis,
                                                                tol, hub_dist, checkpoint)

        if not success:
            # fault if check is not successful
            msg = 'failed {} after {}mm'.format(checkpoint, tuned_hub_pos)
            return False, msg, tuned_hub_pos

        # when successful return values to calibration macro
        return True, msg, tuned_hub_pos

    def move_until_state(self, cur_lane, state, move_dis, tolerance, short_move, pos=0, fault_dis=250, checkpoint=None):
        # moves filament until specified sensor, returns values for further calibration
        while not state():
            cur_lane.move(move_dis, cur_lane.short_moves_speed, cur_lane.short_moves_accel)
            pos += move_dis
            if pos >= fault_dis:
                # return if pos exceeds fault_dis
                return fault_dis, checkpoint, False
        self.afc.reactor.pause(self.afc.reactor.monotonic() + 0.1)

        state_retracts = 0
        while state():
            # retract off of sensor
            state_retracts =+ 1
            cur_lane.move(short_move * -1, cur_lane.short_moves_speed, cur_lane.short_moves_accel, True)
            pos -= short_move
            check_p = '{} switch did not go false, reset lane and check switch'.format(checkpoint)
            if state_retracts >= 4:
                # fault if it takes more than 4 attempts
                f_dis = short_move * 4
                return f_dis, check_p, False
        self.afc.reactor.pause(self.afc.reactor.monotonic() + 0.1)

        tol_checks = 0
        while not state():
            # move back to sensor in short steps
            tol_checks += 1
            cur_lane.move(tolerance, cur_lane.short_moves_speed, cur_lane.short_moves_accel)
            pos += tolerance
            check_p = '{} switch failed to become true during tolerance check, reset lane and check switch'.format(checkpoint)
            if tol_checks >= 15:
                # fault if tol_checks exceed 15
                return fault_dis, check_p, False

        return pos, checkpoint, True

    def calc_position(self, cur_lane, state, pos, short_move, tolerance, fault_dis=250, checkpoint=None):
        # move off and back on to sensor to calculate end position of calibration
        check_pos = 0
        while state():
            # retract from sensor
            cur_lane.move(short_move * -1, cur_lane.short_moves_speed, cur_lane.short_moves_accel, True)
            pos -= short_move
            check_pos -= short_move
            if abs(check_pos) >= fault_dis:
                # fault if absolute value you check_pos exceeds fault_dis
                return fault_dis, checkpoint, False
        self.afc.reactor.pause(self.afc.reactor.monotonic() + 0.1)

        checkpoint += ', tolerance check,'
        tol_checks = 0
        while not state():
            #move back to sensor to confirm distance
            tol_checks += 1
            cur_lane.move(tolerance, cur_lane.short_moves_speed, cur_lane.short_moves_accel)
            pos += tolerance

            if tol_checks >= 15:
                # fault if tol_checks exceeds 15
                return pos, checkpoint, False

        return pos, checkpoint, True

    def calibrate_lane(self, cur_lane, tol):
        # function to calibrate distance from secondary extruder to hub
        cur_hub = cur_lane.hub_obj
        if cur_hub.state:
            msg = 'Hub is not clear, check before calibration'
            return False, msg, 0
        if not cur_lane.load_state:
            msg = '{} not loaded, load before calibration'.format(cur_lane.name)
            return False, msg, 0
        if not cur_lane.prep_state:
            msg = '{} is loaded but not prepped, check prep before calibration'.format(cur_lane.name)
            return False, msg, 0

        self.logger.info('Calibrating {}'.format(cur_lane.name))
        cur_lane.status = AFCLaneState.CALIBRATING
        # reset to extruder
        move_dis = cur_lane.dist_hub+100
        if self.afc.homing_enabled:
            checkpoint = "retract to extruder"
            success, pos, warn = cur_lane.move_to(distance=move_dis*-1,
                                                  speed_mode=SpeedMode.CALIBRATION,
                                                  endstop=cur_lane.load_es,
                                                  assist_active=AssistActive.YES)
            # Check for error and return, if error state is set then AFC tried pausing
            # during the homing
            if warn == AFCMoveWarning.ERROR:
                return False, "Error occurred when trying to move lane", 0
        else:
            pos, checkpoint, success = self.calc_position(cur_lane,
                                                          lambda: cur_lane.raw_load_state, 0,
                                                          cur_lane.short_move_dis,
                                                          tol, move_dis,
                                                          "retract to extruder")

        if not success:
            if checkpoint == "retract to extruder":
                msg = f"\n{cur_lane.name} failed during calibration after {round(pos,2)}mm. Check position of filament and " \
                      "reset filament using BT_LANE_MOVE macro if necessary. If filament is between " \
                      "the extruder and the hub, and is moving smoothly, you may need to increase the " \
                      "dist_hub value. Once adjusted, please try again.\nThis can be adjusted by " \
                      f"using the SET_HUB_DIST LANE={cur_lane.name} LENGTH=+/-distance macro. Once you are " \
                      f"satisfied, you can save the values with SAVE_HUB_DIST LANE={cur_lane.name} macro."
            else:
                msg = 'Lane failed to calibrate {} after {}mm'.format(checkpoint, pos)
            cur_lane.status = AFCLaneState.NONE
            cur_lane.unit_obj.return_to_home()
            return False, msg, 0

        else:
            if self.afc.homing_enabled:
                success, hub_pos, _ = cur_lane.unit_obj.move_to_hub(cur_lane, move_dis,
                                                                    MoveDirection.POS,
                                                                    speed_mode=SpeedMode.CALIBRATION,
                                                                    assist_active=AssistActive.NO)
                message = f'\nFailed to calibrate dist_hub for {cur_lane.name} after moving {hub_pos}mm. '
                message += 'If filament stopped short of the hub during calibration use the following command to increase dist_hub value'
                message += f' SET_HUB_DIST LANE={cur_lane.name} LENGTH=+(distance the filament was short from the hub)'
            else:
                success, message, hub_pos = self.calibrate_hub(cur_lane, tol)

            if not success:
                cur_lane.status = AFCLaneState.NONE
                cur_lane.unit_obj.return_to_home()
                return False, message, hub_pos

            # Always run hub clear
            cur_lane.move(cur_hub.hub_clear_move_dis * -1, cur_lane.short_moves_speed, cur_lane.short_moves_accel, True)

            cal_dist = round(hub_pos - cur_hub.hub_clear_move_dis, 2)
            cal_msg = "\n{} dist_hub: New: {} Old: {}".format(cur_lane.name, cal_dist, cur_lane.dist_hub)
            cur_lane.loaded_to_hub  = True
            cur_lane.do_enable(False)
            cur_lane.dist_hub = cal_dist
            self.afc.function.ConfigRewrite(cur_lane.fullname, "dist_hub", cal_dist, cal_msg)
            cur_lane.status = AFCLaneState.NONE
            cur_lane.unit_obj.return_to_home()
            return True, cal_msg, cal_dist

    def prep_load(self, lane: AFCLane):
        """
        Helper method for initially loading spools when prep sensor is triggered.

        Upon first load if homing is enabled, stepper motor will be activated for a move of 400mm
        or until load sensor is triggered.

        If load sensor is not triggered and prep is still triggered small moves of short_move_dis in
        mm will happen until a total of short_move_dis*40mm is reached. This is also the same
        movement that happens if homing is not enabled.

        :param lane: AFCLane object for which to activate and load filament to load sensor
        """
        if self.afc.homing_enabled:
            lane.move_to(self.short_move_dis*self.MAX_NUM_MOVES, SpeedMode.SHORT,
                         assist_active=AssistActive.NO, endstop=lane.load_es,
                         use_homing=True)
        x = 0
        while (not lane.raw_load_state
               and lane.prep_state
               and lane.load is not None):
            x += 1
            lane.move(self.short_move_dis,500,400)
            self.reactor.pause(self.reactor.monotonic() + 0.1)
            if x> self.MAX_NUM_MOVES:
                msg = ' FAILED TO LOAD, CHECK FILAMENT AT TRIGGER\n||==>--||----||------||\nTRG   LOAD   HUB    TOOL'
                self.afc.error.AFC_error(msg, False)
                self.afc.function.afc_led(self.afc.led_fault, lane.led_index)
                lane.status = AFCLaneState.NONE
                break

    def prep_post_load(self, lane: AFCLane):
        """
        Helper method to run after prep_load has been successful.

        Check to see if boolean is set to load to hub only if lane is not already loaded to hub as
        long as load and prep states are still triggered. If this check is satisfied then filament
        is moved to hub with length specified by dist_hub parameter.

        :param lane: AFCLane object for which to perform prep_post_load action on
        """
        # Checking if loaded to hub(it should not be since filament was just inserted), if false load to hub. Does a fast load if hub distance is over 200mm
        if (not lane.is_direct_hub()
            and lane.load_to_hub
            and not lane.loaded_to_hub
            and lane.load_state
            and lane.prep_state):
            lane.move(lane.dist_hub, lane.dist_hub_move_speed, lane.dist_hub_move_accel, lane.dist_hub > 200)
            lane.loaded_to_hub = True

    def eject_lane(self, lane: AFCLane):
        """
        Method to eject spool from lane.

        :param lane: AFCLane object for which to perform eject action on
        """
        try:
            if lane.loaded_to_hub:
                lane.move_to(lane.dist_hub * -1, SpeedMode.DIST_HUB,
                             endstop=lane.load_es, assist_active=AssistActive.DYNAMIC,
                             use_homing=self.afc.homing_enabled)
            max_tries = 0
            while lane.load_state:
                max_tries += 1
                lane.move_advanced(lane.hub_obj.move_dis * -1, SpeedMode.SHORT,
                                   assist_active = AssistActive.YES)
                if max_tries >= self.MAX_NUM_MOVES:
                    msg = f' Failed to eject {lane.name}'
                    self.afc.error.AFC_error(msg, False)
                    break
            lane.move_advanced(lane.extruder_clear_dis * -1, SpeedMode.SHORT)
        finally:
            lane.do_enable(False)

def load_config_prefix(config):
    return afcBoxTurtle(config)